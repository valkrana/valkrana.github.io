--///////////////////////////////////////////////////////
-- Valkrana (Ravenloft) / Defines
--///////////////////////////////////////////////////////
DELETE FROM CivilizationLeaders WHERE CivilizationType = 'CIVILIZATION_RUSSIA' AND LeaderType = 'LEADER_SAILOR_VALKRANA';
INSERT INTO CivilizationLeaders	(CivilizationType, LeaderType, CapitalName)
VALUES	('CIVILIZATION_JGP_RAVENLOFT', 'LEADER_SAILOR_VALKRANA', 'LOC_CITY_NAME_SAILOR_CITADEL_CAVITIUS');

INSERT INTO AiFavoredItems	
		(ListType,							Favored,	Item,										Value)
VALUES	('SAILOR_VALKRANA_Improvements',	1,			'IMPROVEMENT_JGP_RAVENLOFT_VISTANI_CAMP',	1),
		('SAILOR_VALKRANA_Units',			1,			'UNIT_JGP_RAVENLOFT_VAMPIRE_SPAWN',			1);