--///////////////////////////////////////////////////////
-- Valkrana (Nilfgaard) / Defines
--///////////////////////////////////////////////////////
UPDATE LoadingInfo SET BackgroundImage = 'LEADER_IPG_EMHYR_BACKGROUND' WHERE LeaderType = 'LEADER_SAILOR_VALKRANA';

INSERT INTO CivilizationLeaders	(CivilizationType, LeaderType, CapitalName)
VALUES	('CIVILIZATION_IPG_NILFGAARD', 'LEADER_SAILOR_VALKRANA', 'LOC_CITY_NAME_IPG_NILFGAARD_12'); -- Loc Grim

-- Nilfgaardian Camp, Fire Scorpion
INSERT OR REPLACE INTO AiFavoredItems	
		(ListType,							Favored,	Item,										Value)
VALUES	('SAILOR_VALKRANA_Districts',		1,			'DISTRICT_NILFGAARDIAN_IMPERIAL_CAMP',		0),
		('SAILOR_VALKRANA_Units',			1,			'UNIT_NILFGAARD_FIRE_SCORPION',				0),
		('SAILOR_VALKRANA_Techs',			1,			'TECH_GUNPOWDER',							0); -- Unlocks Fire Scorpion

INSERT OR REPLACE INTO AiFavoredItems (ListType, Favored, Item, Value) SELECT 'SAILOR_VALKRANA_Buildings', 1, BuildingType, 0    
FROM Buildings WHERE PrereqDistrict = 'DISTRICT_NILFGAARDIAN_IMPERIAL_CAMP' AND TraitType IS NULL;