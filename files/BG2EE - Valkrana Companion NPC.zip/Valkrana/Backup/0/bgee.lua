portraits =
{
	{'MAN1', 1},
	{'MAN2', 1},
	{'GENDWRF', 1},
	{'GENMELF', 1},
	{'GENMHLF', 1},
	{'NHORC', 1},
	{'AJANTIS', 1},
	{'CORAN', 1},
	{'EDWIN', 1},
	{'ELDOTH', 1},
	{'GARRICK', 1},
	{'KAGAIN', 1},
	{'KHALID', 1},
	{'KIVAN', 1},
	{'MINSC', 1},
	{'MONTAR', 1},
	{'QUAYLE', 1},
	{'TIAX', 1},
	{'XAN', 1},
	{'XZAR', 1},
	{'YESLICK', 1},
	{'RASAAD', 1},
	{'DORN',	1},
	{'NCERND', 1},
	{'NKELDOR', 1},
	{'NANOMEN', 1},
	{'NEDWIN', 1},
	{'NHAER', 1},
	{'NJAN', 1},
	{'NMINSC', 1},
	{'NVALYGA', 1},
	{'NYOSHIM', 1},
	{'NKORGAN', 1},
	{'BDSHAM1', 1},
	{'BDORCM1', 1},
	{'WOMAN1', 2},
	{'WOMAN2', 2},
	{'ALORA', 2},
	{'BRANWE', 2},
	{'DYNAHEI', 2},
	{'FALDORN', 2},
	{'IMOEN', 2},
	{'JAHEIRA', 2},
	{'SAFANA', 2},
	{'SHARTEL', 2},
	{'SKIE', 2},
	{'VICONIA', 2},
	{'NEERA', 2},
	{'NNALIA', 2},
	{'NMAZZY', 2},
	{'NAERIE', 2},
	{'NJAHEIR', 2},
	{'NVICON', 2},
	{'BDSHAF1', 2},
	{'BDORCF1', 2},
	{'YANNER1', 2},
	{'YANNER2', 2},
	{'YANNER3', 2},
	{'YANNER4', 1},
	{'YANNER5', 1},
	{'YANNER6', 1},
	{'HELM', 1},
	{'HVLN', 1},
	{'OHHEX', 2},
	{'SKAN', 2},
	{'MANLEY0', 1},
	{'MANLEY3', 1},
	{'MANLEY6', 1},
	{'MANLEY7', 1},
	{'MANLEY8', 1},
	{'MANLEY9', 1},
	{'MANLEY1', 2},
	{'MANLEY2', 2},
	{'MANLEY4', 2},
	{'MANLEY5', 2},
	{'MANLEYX', 2},
	{'bdtma', 1},
	{'bdtmb', 2},
	{'bdtmc', 1},
	{'bdtmd', 1},
	{'bdtme', 2},
	{'bdtmf', 2},
	{'bdtmg', 1},
	{'bdtmh', 1},
	{'bdtmi', 1},
	{'bdtmj', 2},
	{'bdtmk', 1}
}

movies = 
{
	{ 'intro', 10, 170, 74093, 1, 1},
	{ 'intro', 630, 720, 74049, 1, 1},
	{ 'intro', 735, 940, 74050, 1, 1},
	{ 'intro', 985, 1210, 74051, 1, 1},
	{ 'intro', 1315, 1385, 74052, 1, 1},
	{ 'intro', 1425, 1770, 74053, 1, 1},
	{ 'intro', 1865, 2150, 74054, 1, 1},
	{ 'intro', 2165, 2300, 74055, 1, 1},
	{ 'intro', 2345, 2550, 74056, 1, 1},
	{ 'intro', 2605, 2710, 74057, 1, 1},
	{ 'intro', 2730, 2860, 74058, 1, 1},
	{ 'intro', 3045, 3110, 74059, 1, 1},
	{ 'intro', 3135, 3320, 74060, 1, 1},

	{ 'intro15f', 1, 200, 70674, 1, 1 },
	{ 'intro15f', 460, 590, 70675, 1, 1 },
	{ 'intro15f', 600, 713, 70676, 1, 1 },
	{ 'intro15f', 727, 850, 70677, 1, 1 },
	{ 'intro15f', 865, 1020, 70679, 1, 1 },
	{ 'intro15f', 1025, 1192, 70681, 1, 1 },
	{ 'intro15f', 1210, 1310, 70682, 1, 1 },
	{ 'intro15f', 1315, 1455, 70683, 1, 1 },
	{ 'intro15f', 1462, 1630, 70684, 1, 1 },
	{ 'intro15f', 1642, 1742, 70685, 1, 1 },
	{ 'intro15f', 1750, 1880, 70686, 1, 1 },
	{ 'intro15f', 1895, 2030, 70687, 1, 1 },
	
	{ 'end15fps', 480, 540, 70669, 1, 1 },  
	{ 'end15fps', 1245, 1365, 70670, 1, 1 },
	{ 'end15fps', 1387, 1465, 70671, 1, 1 },
	{ 'end15fps', 1492, 1515, 70672, 1, 1 },
	{ 'end15fps', 1560, 1662, 70673, 1, 1 },
	
	{ 'melissan', 167, 197, 74085, 1, 1 },
	{ 'melissan', 217, 280, 74086, 1, 1 },
	{ 'melissan', 302, 405, 74087, 1, 1 },
	{ 'melissan', 425, 1515, 74088, 1, 1 },
	
	{ 'blackpit', 45, 100, 103210, 1, 1 },
	{ 'blackpit', 115, 200, 103211, 1, 1 },
	{ 'blackpit', 215, 350, 103212, 1, 1 },
	{ 'blackpit', 365, 440, 103213, 1, 1 },

	{ 'endmve1', 92, 147, 74077, 1, 1 },
	{ 'endmve1', 167, 315, 74078, 1, 1 },
	{ 'endmve1', 335, 455, 74079, 1, 1 },
	{ 'endmve1', 475, 560, 74080, 1, 1 },
	{ 'endmve1', 580, 727, 74081, 1, 1 },
	{ 'endmve1', 747, 802, 74082, 1, 1 },
	{ 'endmve1', 822, 917, 74083, 1, 1 },
	{ 'endmve1', 937, 1662, 74084, 1, 1 },	
	
	{ 'endmve2', 105, 202, 74068, 1, 1 },  
	{ 'endmve2', 222, 310, 74069, 1, 1 },
	{ 'endmve2', 330, 427, 74070, 1, 1 },
	{ 'endmve2', 447, 495, 74071, 1, 1 },
	{ 'endmve2', 515, 597, 74072, 1, 1 },
	{ 'endmve2', 617, 727, 74073, 1, 1 },
	{ 'endmve2', 747, 785, 74074, 1, 1 },
	{ 'endmve2', 805, 867, 74075, 1, 1 },
	{ 'endmve2', 887, 1662, 74076, 1, 1 },
	
	{ 'endmve3', 105, 180, 74048, 1, 1 },  
	{ 'endmve3', 200, 265, 74061, 1, 1 },
	{ 'endmve3', 285, 427, 74062, 1, 1 },
	{ 'endmve3', 447, 495, 74063, 1, 1 },
	{ 'endmve3', 515, 617, 74064, 1, 1 },
	{ 'endmve3', 637, 727, 74065, 1, 1 },
	{ 'endmve3', 747, 870, 74066, 1, 1 },
	{ 'endmve3', 890, 1662, 74067, 1, 1 }
}
credits =
{
	83359,	-- Overhaul
	83360,	-- WotC Atari
	83361,	-- Special Thanks Volunteers
	83362,	-- Volunteers
	83363,	-- Volunteers
	100284,	-- Volunteers
	102778,
	102824,
	102825,
	102826,
	102827,
	102828,
	102829,
	102830,
	102831,
	102623
}

mageBookStrings = {
	SPWI908 = {tip = 55373, title = 'CHAIN_CONTINGENCY_TITLE', action = "ADD_SPELLS_CONTINGENCY_LABEL"},
	SPWI617 = {tip = 55373, title = 'CONTINGENCY_TITLE', action = "ADD_SPELLS_CONTINGENCY_LABEL"},
	SPWI809 = {tip = 55372, title = 'SPELL_TRIGGER_TITLE', action = "ADD_SPELLS_TRIGGER_LABEL"},
	SPWI710 = {tip = 60420, title = 'SPELL_SEQUENCER_TITLE', action = "ADD_SPELLS_SEQUENCER_LABEL"},
	SPWI420 = {tip = 60420, title = 'MINOR_SEQUENCER_TITLE', action = "ADD_SPELLS_SEQUENCER_LABEL"},
	}

Infinity_AddDLC( 'dorn', 'DLCDN', 95310, 95311, 'BG2EE_IOS_DORN', 1, 'bg2ee_android_dorn')
Infinity_AddDLC( 'neera', 'DLCNE', 95312, 95313, 'BG2EE_IOS_NEERA', 2, 'bg2ee_android_neera')
Infinity_AddDLC( 'hexxat', 'DLCHX', 95314, 102524, 'BG2EE_IOS_HEXXAT', 3, 'bg2ee_android_hexxat')
Infinity_AddDLC( 'rasaad', 'DLCRS', 102523, 102522, 'BG2EE_IOS_RASAAD', 4, 'bg2ee_android_rasaad')
Infinity_AddDLC( 'yanner', 'DLCYN', 95315, 95316, 'BG2EE_IOS_PORTRAITPACK1', 5, 'bg2ee_android_portraitpack1')
Infinity_AddDLC( 'BDTM', 'DLCBDTP', 103242, 103243, 'BGEE_BDTP', 6, 'beamdog_team_pack' )

Infinity_AddDLCContent('DORN', 1 )
Infinity_AddDLCContent('NEERA', 2 )
Infinity_AddDLCContent('OHHEX', 3 )
Infinity_AddDLCContent('RASAAD', 4 )
Infinity_AddDLCContent('YANNER1', 5 )
Infinity_AddDLCContent('YANNER2', 5 )
Infinity_AddDLCContent('YANNER3', 5 )
Infinity_AddDLCContent('YANNER4', 5 )
Infinity_AddDLCContent('YANNER5', 5 )
Infinity_AddDLCContent('YANNER6', 5 )

Infinity_AddDLCContent('bdtma', 6 )
Infinity_AddDLCContent('bdtmb', 6 )
Infinity_AddDLCContent('bdtmc', 6 )
Infinity_AddDLCContent('bdtmd', 6 )
Infinity_AddDLCContent('bdtme', 6 )
Infinity_AddDLCContent('bdtmf', 6 )
Infinity_AddDLCContent('bdtmg', 6 )
Infinity_AddDLCContent('bdtmh', 6 )
Infinity_AddDLCContent('bdtmi', 6 )
Infinity_AddDLCContent('bdtmj', 6 )
Infinity_AddDLCContent('bdtmk', 6 )
--Soundsets
Infinity_AddDLCContent('bdtpam', 6 )
Infinity_AddDLCContent('bdtpbe', 6 )
Infinity_AddDLCContent('bdtpag', 6 )
Infinity_AddDLCContent('bdtpdg', 6 )
Infinity_AddDLCContent('bdtpeh', 6 )
Infinity_AddDLCContent('bdtpsd', 6 )
Infinity_AddDLCContent('bdtpto', 6 )

purchasedDLC = {}
purchasedDLC[1] = 1
purchasedDLC[2] = 1
purchasedDLC[3] = 1
purchasedDLC[4] = 2
purchasedDLC[5] = 1
purchasedDLC[6] = 1

keybindings = 
{
	{
		{ 1,	1,	'Inventory',				"ASSIGN_KEYS_PAGE_INVENTORY",				'',		0,	105 },
		{ 2,	1,	'Character Record',			"ASSIGN_KEYS_PAGE_CHARACTERINFORMATION",	'',		0,	114 },
		{ 3,	1,	'Return To Game',			"ASSIGN_KEYS_PAGE_RETURNTOGAME",			'',		0,	103 },
		{ 4,	1,	'Journal',					"ASSIGN_KEYS_PAGE_JOURNAL",					'',		0,	106 },
		{ 5,	1,	'Map',						"ASSIGN_KEYS_PAGE_AREAMAP",					'',		0,	109 },
		{ 6,	1,	'Wizard Spells',			"ASSIGN_KEYS_PAGE_MAGESPELLS",				'',		0,	119 },
		{ 7,	1,	'Priest Spells',			"ASSIGN_KEYS_PAGE_PRIESTSPELLS",			'',		0,	112 },
		{ 8,	1,	'Options',					"ASSIGN_KEYS_PAGE_OPTIONS",					'',		0,	111 },
		{ 9,	1,	'Character Arbitration',	"ASSIGN_KEYS_PAGE_CHARACTERARBITRATION",	'',		0,	99 }
	},
	{
		{ 10,	2,	'Guard / Protect',			"ASSIGN_KEYS_ACTIONS_GUARD",				'',		0,	0 },
		{ 11,	2,	'Turn Undead',				"ASSIGN_KEYS_ACTIONS_TURNUNDEAD",			'',		0,	0 },
		{ 12, 2,	'Battle Song',				"ASSIGN_KEYS_ACTIONS_BARDSONG",				'',		0,	0 },
		{ 13, 2,	'Cast Spell',				"ASSIGN_KEYS_ACTIONS_CASTSPELL",			'',		0,	0 },
		{ 14, 2,	'Use Item',					"ASSIGN_KEYS_ACTIONS_USEITEM",				'',		0,	0 },
		{ 15, 2,	'Dialog',					"ASSIGN_KEYS_ACTIONS_DIALOG",				'',		0,	0 },
		{ 16, 2,	'Thieving',					"ASSIGN_KEYS_ACTIONS_THIEVING",				'',		0,	0 },
		{ 17, 2,	'Stealth',					"ASSIGN_KEYS_ACTIONS_STEALTH",				'',		0,	0 },
		{ 18, 2,	'Trap Detection',			"ASSIGN_KEYS_ACTIONS_FINDTRAPS",			'',		0,	0 },
		{ 19, 2,	'Group Stop',				"ASSIGN_KEYS_ACTIONS_GROUPSTOP",			'',		0,	0 },
		{ 20, 2,	'Group Attack',				"ASSIGN_KEYS_ACTIONS_GROUPATTACK",			'',		0,	0 },
		{ 21, 2,	'Special Abilities',		"ASSIGN_KEYS_ACTIONS_SPECIALABILITIES",		'',		0,	0 },
		{ 22, 2,	'Equip Melee Weapon',		"ASSIGN_KEYS_ACTIONS_EQUIPMELEEWEAPON",		'',		0,	0 },
		{ 23, 2,	'Equip Range Weapon',		"ASSIGN_KEYS_ACTIONS_EQUIPRANGEDWEAPON",	'',		0,	0 }
	},
	{
		{ 24, 3,	'Quick Load',				"ASSIGN_KEYS_MISC_QUICKLOAD",		'',		0,	108 },
		{ 25, 3,	'Hide Interface',			"ASSIGN_KEYS_MISC_HIDEINTERFACE",	'',		0,	104 },
		{ 26, 3,	'Right Interface',			"ASSIGN_KEYS_MISC_RIGHTINTERFACE",	'',		0,	117 },
		{ 27, 3,	'Chat Window',				"ASSIGN_KEYS_MISC_CHATWINDOW",		'',		0,	116 },
		{ 28, 3,	'Location',					"ASSIGN_KEYS_MISC_LOCATION",		'',		0,	120 },
		{ 29, 3,	'Quick Save',				"ASSIGN_KEYS_MISC_QUICKSAVE",		'',		0,	113 },
		{ 30, 3,	'Toggle AI',				"ASSIGN_KEYS_MISC_TOGGLEAI",		'',		0,	97 },
		{ 31, 3,	'Left Interface',			"ASSIGN_KEYS_MISC_LEFTINTERFACE",	'',		0,	121 },
		{ 32, 3,	'Rest',						"ASSIGN_KEYS_MISC_REST",			'',		0,	0 },
		{ 33, 3,	'Hard Pause',				"ASSIGN_KEYS_MISC_HARDPAUSE",		'',		0,	0 },
		{ 34, 3,   'Scroll Up',					"ASSIGN_KEYS_MISC_SCROLLUP",		'',		0,	0 },
		{ 35, 3,   'Scroll Right',				"ASSIGN_KEYS_MISC_SCROLLRIGHT",		'',		0,	0 },
		{ 36, 3,   'Scroll Down',				"ASSIGN_KEYS_MISC_SCROLLDOWN",		'',		0,	0 },
		{ 37, 3,   'Scroll Left',				"ASSIGN_KEYS_MISC_SCROLLLEFT",		'',		0,	0 },
		{ 38, 3, 'Zoom In',						"ASSIGN_KEYS_QUICKSLOTS_ZOOMIN",  	'',		0,	61 },
		{ 39, 3, 'Zoom Out',					"ASSIGN_KEYS_QUICKSLOTS_ZOOMOUT",  	'',		0,	45 },
		{ 40, 3, 'Quick Loot',					"99897",							'',		0,	0 }
	},
	{
		{ 41,	4,	'Spell Slot 1',				"ASSIGN_KEYS_QUICKSLOTS_SPELLSLOT1",		'',		0,	0 },
		{ 42,	4,	'Spell Slot 2',				"ASSIGN_KEYS_QUICKSLOTS_SPELLSLOT2",		'',		0,	0 },
		{ 43,	4,	'Spell Slot 3',				"ASSIGN_KEYS_QUICKSLOTS_SPELLSLOT3",		'',		0,	0 },
		{ 44,	4,	'Weapon Slot 1',			"ASSIGN_KEYS_QUICKSLOTS_WEAPONSLOT1",		'',		0,	0 },
		{ 45,	4,	'Weapon Slot 2',			"ASSIGN_KEYS_QUICKSLOTS_WEAPONSLOT2",		'',		0,	0 },
		{ 46,	4,	'Weapon Slot 3',			"ASSIGN_KEYS_QUICKSLOTS_WEAPONSLOT3",		'',		0,	0 },
		{ 47,	4,	'Weapon Slot 4',			"ASSIGN_KEYS_QUICKSLOTS_WEAPONSLOT4",		'',		0,	0 },
		{ 48,	4,	'Item Slot 1',				"ASSIGN_KEYS_QUICKSLOTS_ITEMSLOT1",			'',		0,	0 },
		{ 49,	4,	'Item Slot 2',				"ASSIGN_KEYS_QUICKSLOTS_ITEMSLOT2",			'',		0,	0 },
		{ 50,	4,	'Item Slot 3',				"ASSIGN_KEYS_QUICKSLOTS_ITEMSLOT3",			'',		0,	0 },
		{ 51,	4,	'Formation Slot 1',			"ASSIGN_KEYS_QUICKSLOTS_FORMATIONSLOT1",	'',		0,	0 },
		{ 52,	4,	'Formation Slot 2',			"ASSIGN_KEYS_QUICKSLOTS_FORMATIONSLOT2",	'',		0,	0 },
		{ 53,	4,	'Formation Slot 3',			"ASSIGN_KEYS_QUICKSLOTS_FORMATIONSLOT3",	'',		0,	0 },
		{ 54,	4,	'Formation Slot 4',			"ASSIGN_KEYS_QUICKSLOTS_FORMATIONSLOT4",	'',		0,	0 },
		{ 55,	4,	'Formation Slot 5',			"ASSIGN_KEYS_QUICKSLOTS_FORMATIONSLOT5",	'',		0,	0 },
		{ 56, 4, 'Character 1',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTER1",  		'',		0,	49 },
		{ 57, 4, 'Character 2',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTER2",  		'',		0,	50 },
		{ 58, 4, 'Character 3',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTER3",  		'',		0,	51 },
		{ 59, 4, 'Character 4',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTER4",  		'',		0,	52 },
		{ 60, 4, 'Character 5',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTER5",  		'',		0,	53 },
		{ 61, 4, 'Character 6',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTER6",  		'',		0,	54 },
		{ 62, 4, 'Characters 1&2',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTERS12",  	'',		0,	55 },
		{ 63, 4, 'Characters 3&4',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTERS34",  	'',		0,	56 },
		{ 64, 4, 'Characters 5&6',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTERS56",  	'',		0,	57 },
		{ 65, 4, 'Select 1,2,3',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTERS123",  	'',		0,	0 },
		{ 66, 4, 'Select 4,5,6',				"ASSIGN_KEYS_QUICKSLOTS_CHARACTERS456",  	'',		0,	0 },
		{ 67, 4, 'Select all',					"ASSIGN_KEYS_QUICKSLOTS_SELECTALL",  		'',		0,	48 }
	},
	{
		{ 181, 5,	'SPPR101',					12089,  '',     0,	0 },
		{ 182, 5,  'SPPR102',					12097,  '',		0,	0 },
		{ 183, 5,  'SPPR103',					12110,  '',		0,	0 },
		{ 184, 5,  'SPPR104',					12041,  '',		0,	0 },
		{ 185, 5,  'SPPR105',					12119,	'',		0,	0 },
		{ 186,	5,  'SPPR106',					12098,  '',     0,	0 },
		{ 187, 5,  'SPPR107',					12023,  '',     0,	0 },
		{ 188, 5,  'SPPR108',					12083,  '',     0,	0 },
		{ 189, 5,  'SPPR109',					12084,  '',		0,	0 },
		{ 190, 5,  'SPPR110',					12118,	'',		0,	0 },
		{ 191, 5, 'SPPR111',					25601, '',		0,	0 }, -- Armor of Faith
		{ 192, 5, 'SPPR113',					3351, '',		0,	0 }, -- Doom
		{ 193, 5, 'SPPR150',					103062, '',		0,	0 }, -- Spirit Ward
		{ 194, 5,  'SPPR201',					12111,  '',     0,	0 },
		{ 195,	5,	'SPPR202',					12121,  '',		0,	0 },
		{ 196, 5,  'SPPR203',					12090,	'',		0,	0 },
		{ 197,	5,	'SPPR204',					12099,	'',		0,	0 },
		{ 198,	5,	'SPPR205',					12094,	'',		0,	0 },
		{ 199,	5,	'SPPR206',					12105,	'',		0,	0 },
		{ 200, 5,	'SPPR207',					12106,	'',		0,	0 },
		{ 201,	5,	'SPPR208',					12049,	'',		0,	0 },
		{ 202,	5,	'SPPR209',					12043,	'',		0,	0 },
		{ 203,	5,	'SPPR210',					12122,	'',		0,	0 },
		{ 204,	5,	'SPPR211',					12123,	'',		0,	0 },
		{ 205,	5,	'SPPR212',					12112,	'',		0,	0 },
		{ 206,	5,	'SPPR213',					12107,	'',		0,	0 },
		{ 207,	5,	'SPPR214',					12108,	'',		0,	0 },
		{ 208,  5,  'SPPR250',					103067, '',		0,	0 }, -- Writhing Fog
		{ 209,	5,	'SPPR301',					12073,	'',		0,	0 },
		{ 210,	5,	'SPPR302',					12124,	'',		0,	0 },
		{ 211,	5,	'SPPR304',					12085,	'',		0,	0 },
		{ 212,	5,	'SPPR305',					12100,	'',		0,	0 },
		{ 213,	5,	'SPPR306',					12086,	'',		0,	0 },
		{ 214,	5,	'SPPR307',					12087,	'',		0,	0 },
		{ 215,	5,	'SPPR308',					12088,	'',		0,	0 },
		{ 216, 5,	'SPPR309',					12095,	'',		0,	0 },
		{ 217,	5,	'SPPR310',					12103,	'',		0,	0 },
		{ 218,	5,	'SPPR311',					12101,	'',		0,	0 },
		{ 219,	5,	'SPPR312',					12125,	'',		0,	0 },
		{ 220, 5, 'SPPR313',					3925, '',		0,	0 }, -- Holy Smite
		{ 221, 5, 'SPPR314',					4346, '',		0,	0 }, -- Unholy Blight
		{ 222, 5, 'SPPR315',					3350, '',		0,	0 }, -- Cure Medium Wounds
		{ 223, 5, 'SPPR317',					2445, '',		0,	0 }, -- Cure Disease
		{ 224, 5, 'SPPR318',					38581, '',		0,	0 }, -- Zone of Sweet Air
		{ 225, 5, 'SPPR319',					45045, '',		0,	0 }, -- Summon Insects
		{ 226, 5, 'SPPR350',					103069, '',		0,	0 }, -- Spiritual Clarity
		{ 227,	5,	'SPPR401',					12114,	'',		0,	0 },
		{ 228,	5,	'SPPR402',					12091,	'',		0,	0 },
		{ 229,	5,	'SPPR403',					12102,	'',		0,	0 },
		{ 230,	5,	'SPPR404',					12115,	'',		0,	0 },
		{ 231,	5,	'SPPR405',					22618,	'',		0,	0 },
		{ 232, 5,	'SPPR406',					22829,	'',		0,	0 },
		{ 233,	5,	'SPPR407',					22620,	'',		0,	0 },
		{ 234,	5,	'SPPR408',					12014,	'',		0,	0 },
		{ 235, 5, 'SPPR409',					5789, '',		0,	0 }, -- Death Ward
		{ 236, 5, 'SPPR410',					25613, '',		0,	0 }, -- Call Woodland Beings
		{ 237, 5, 'SPPR411',					5805, '',		0,	0 }, -- Poison
		{ 238, 5, 'SPPR412',					6087, '',		0,	0 }, -- Holy Power
		{ 239, 5, 'SPPR413',					55842, '',		0,	0 }, -- Negative Plane Protection
		{ 240, 5, 'SPPR414',					2624, '',		0,	0 }, -- Cause Serious Wounds
		{ 241, 5, 'SPPR415',					38133, '',		0,	0 }, -- Farsight
		{ 242, 5, 'SPPR416',					38568, '',		0,	0 }, -- Cloak of Fear
		{ 243, 5, 'SPPR417',					55844, '',		0,	0 }, -- Lesser Restoration
		{ 244, 5, 'SPPR450',					103071, '',		0,	0 }, -- Spirit Fire
		{ 245,	5,	'SPPR501',					12092,	'',		0,	0 },
		{ 246,	5,	'SPPR502',					12092,	'',		0,	0 },
		{ 247,	5,	'SPPR503',					12109,	'',		0,	0 },
		{ 248,	5,	'SPPR504',					12117,	'',		0,	0 },
		{ 249,	5,	'SPPR506',					22833,	'',		0,	0 },
		{ 250, 5, 'SPPR507',					22833, '',		0,	0 }, -- Champion's Strength
		{ 251,	5,	'SPPR508',					22903,	'',		0,	0 },		
		{ 252, 5, 'SPPR509',					26783, '',		0,	0 }, -- Magic Resistance
		{ 253, 5, 'SPPR510',					11193, '',		0,	0 }, -- Cause Critical Wounds
		{ 254, 5, 'SPPR511',					6928, '',		0,	0 }, -- Slay Living
		{ 255, 5, 'SPPR512',					6938, '',		0,	0 }, -- Greater Command
		{ 256, 5, 'SPPR513',					7070, '',		0,	0 }, -- Righteous Magic
		{ 257, 5, 'SPPR514',					7468, '',		0,	0 }, -- Mass Cure
		{ 258, 5, 'SPPR515',					2365, '',		0,	0 }, -- Repulse Undead
		{ 259, 5, 'SPPR516',					44945, '',		0,	0 }, -- Pixie Dust
		{ 260, 5, 'SPPR517',					45050, '',		0,	0 }, -- Insect Plague
		{ 261, 5, 'SPPR550',					103073, '',		0,	0 }, -- Recall Spirit
		{ 262, 5, 'SPPR601',					14263, '',		0,	0 }, -- Aerial Servant
		{ 263, 5, 'SPPR602',					14264, '',		0,	0 }, -- Animal Summoning III
		{ 264, 5, 'SPPR603',					14262, '',		0,	0 }, -- Blade Barrier
		{ 265, 5, 'SPPR604',					16163, '',		0,	0 }, -- Conjure Animals
		{ 266, 5, 'SPPR605',					15211, '',		0,	0 }, -- Conjure Fire Elemental
		{ 267, 5, 'SPPR606',					14253, '',		0,	0 }, -- Fire Seeds
		{ 268, 5, 'SPPR607',					8786, '',		0,	0 }, -- Heal
		{ 269, 5, 'SPPR608',					11200, '',		0,	0 }, -- Harm
		{ 270, 5, 'SPPR609',					38569, '',		0,	0 }, -- False Dawn
		{ 271, 5, 'SPPR610',					38571, '',		0,	0 }, -- Dolorous Decay
		{ 272, 5, 'SPPR611',					38573, '',		0,	0 }, -- Wondrous Recall
		{ 273, 5, 'SPPR612',					38575, '',		0,	0 }, -- Bolt of Glory
		{ 274, 5, 'SPPR613',					38577, '',		0,	0 }, -- Physical Mirror
		{ 275, 5, 'SPPR614',					38579, '',		0,	0 }, -- Sol's Searing Orb
		{ 276, 5, 'SPPR650',					103075, '',		0,	0 }, -- Spiritual Lock
		{ 277, 5, 'SPPR701',					11014, '',		0,	0 }, -- Shield of the Archons
		{ 278, 5, 'SPPR702',					15180, '',		0,	0 }, -- Conjure Earth Elemental
		{ 279, 5, 'SPPR703',					14260, '',		0,	0 }, -- Gate
		{ 280, 5, 'SPPR704',					44948, '',		0,	0 }, -- Nature's Beauty
		{ 281, 5, 'SPPR705',					14261, '',		0,	0 }, -- Fire Storm
		{ 282, 5, 'SPPR706',					22145, '',		0,	0 }, -- Symbol, Fear
		{ 283, 5, 'SPPR707',					2664, '',		0,	0 }, -- Sunray
		{ 284, 5, 'SPPR708',					7665, '',		0,	0 }, -- Finger of Death
		{ 285, 5, 'SPPR709',					12051, '',		0,	0 }, -- Confusion
		{ 286, 5, 'SPPR710',					25762, '',		0,	0 }, -- Holy Word
		{ 287, 5, 'SPPR711',					10996, '',		0,	0 }, -- Regeneration
		{ 288, 5, 'SPPR712',					25765, '',		0,	0 }, -- Resurrection
		{ 289, 5, 'SPPR713',					35603, '',		0,	0 }, -- Greater Restoration
		{ 290, 5, 'SPPR715',					35752, '',		0,	0 }, -- Unholy Word
		{ 291, 5, 'SPPR717',					25750, '',		0,	0 }, -- Creeping Doom
		{ 292, 5, 'SPPR718',					39956, '',		0,	0 }, -- Symbol, Stun
		{ 293, 5, 'SPPR719',					39966, '',		0,	0 }, -- Symbol, Death
		{ 294, 5, 'SPPR720',					45054, '',		0,	0 }, -- Earthquake
		{ 295, 5, 'SPPR721',					63615, '',		0,	0 }, -- Energy Blades
		{ 296, 5, 'SPPR722',					63742, '',		0,	0 }, -- Storm of Vengeance
		{ 297, 5, 'SPPR723',					63746, '',		0,	0 }, -- Elemental Summoning
		{ 298, 5, 'SPPR724',					63768, '',		0,	0 }, -- Greater Elemental Summoning
		{ 299, 5, 'SPPR725',					63801, '',		0,	0 }, -- Globe of Blades
		{ 300, 5, 'SPPR726',					63828, '',		0,	0 }, -- Summon Deva
		{ 301, 5, 'SPPR727',					63830, '',		0,	0 }, -- Summon Fallen Deva
		{ 302, 5, 'SPPR728',					63820, '',		0,	0 }, -- Implosion
		{ 303, 5, 'SPPR729',					65410, '',		0,	0 }, -- Mass Raise Dead
		{ 304, 5, 'SPPR730',					63842, '',		0,	0 }, -- Aura of Flaming Death
		{ 305, 5, 'SPPR731',					63873, '',		0,	0 }, -- Fire Elemental Transformation
		{ 306, 5, 'SPPR732',					63882, '',		0,	0 }, -- Earth Elemental Transformation
		{ 307, 5, 'SPPR750',					103078, '',		0,	0 }, -- Ether Gate
		{ 308, 5, 'SPPR751',					103080, '',		0,	0 } -- Ethereal Retribution
	},
	{
		{ 309,  6, 'SPWI101',					12030,	'',		0,	0 },
		{ 310,  6, 'SPWI102',					12031,	'',		0,	0 },
		{ 311, 6, 'SPWI103',					12074,	'',		0,	0 },
		{ 312, 6, 'SPWI104',					12045,	'',		0,	0 },
		{ 313, 6, 'SPWI105',					12075,	'',		0,	0 },
		{ 314, 6, 'SPWI106',					12015,	'',		0,	0 },
		{ 315, 6, 'SPWI107',					12046,	'',		0,	0 },
		{ 316, 6, 'SPWI108',					12024,	'',		0,	0 },
		{ 317, 6, 'SPWI110',					12040,	'',		0,	0 }, -- Identify
		{ 318, 6, 'SPWI111',					12039,	'',		0,	0 },
		{ 319, 6, 'SPWI112',					12052,	'',		0,	0 },
		{ 320, 6, 'SPWI113',					12023,	'',		0,	0 },
		{ 321, 6, 'SPWI114',					12053,	'',		0,	0 },
		{ 322, 6, 'SPWI115',					12076,	'',		0,	0 },
		{ 323, 6, 'SPWI116',					12047,	'',		0,	0 },
		{ 324, 6, 'SPWI117',					12067,	'',		0,	0 },
		{ 325, 6, 'SPWI118',					12054,	'',		0,	0 },
		{ 326, 6, 'SPWI119',					12068,	'',		0,	0 },
		{ 327, 6, 'SPWI120',					25866,	'',		0,	0 }, -- Reflected Image
		{ 328, 6, 'SPWI123',					8072,	'',		0,	0 }, -- Find Familiar
		{ 329, 6, 'SPWI124',					55831,	'',		0,	0 }, -- Nahal's Reckless Dweomer
		{ 330, 6, 'SPWI125',					38586,	'',		0,	0 }, -- Spook
		{ 331, 6, 'SPWI201',					12016,	'',		0,	0 },
		{ 332, 6, 'SPWI202',					12041,	'',		0,	0 },
		{ 333, 6, 'SPWI203',					12042,	'',		0,	0 },
		{ 334, 6, 'SPWI205',					12069,	'',		0,	0 },
		{ 335, 6, 'SPWI206',					12017,	'',		0,	0 },
		{ 336, 6, 'SPWI207',					12131,	'',		0,	0 },
		{ 337, 6, 'SPWI208',					12043,	'',		0,	0 },
		{ 338, 6, 'SPWI209',					12048,	'',		0,	0 },
		{ 339, 6, 'SPWI210',					12025,	'',		0,	0 },
		{ 340, 6, 'SPWI211',					12033,	'',		0,	0 },
		{ 341, 6, 'SPWI212',					12018,	'',		0,	0 },
		{ 342, 6, 'SPWI213',					12056,	'',		0,	0 },
		{ 343, 6, 'SPWI214',					12077,	'',		0,	0 },
		{ 344, 6, 'SPWI215',					12057,	'',		0,	0 },
		{ 345, 6, 'SPWI217',					12058,	'',		0,	0 },
		{ 346, 6, 'SPWI218',					12070,	'',		0,	0 },
		{ 347, 6, 'SPWI219',					12079,	'',		0,	0 },
		{ 348, 6, 'SPWI220',					7480,	'',		0,	0 }, -- Power Word, Sleep
		{ 349, 6, 'SPWI221',					7725,	'',		0,	0 }, -- Ray of Enfeeblement
		{ 350, 6, 'SPWI222',					64319,	'',		0,	0 }, -- Chaos Shield
		{ 351, 6, 'SPWI223',					38592,	'',		0,	0 }, -- Deafness
		{ 352, 6, 'SPWI224',					38594,	'',		0,	0 }, -- Glitterdust
		{ 353, 6, 'SPWI301',					12044,	'',		0,	0 },
		{ 354, 6, 'SPWI302',					12026,	'',		0,	0 },
		{ 355, 6, 'SPWI303',					12034,	'',		0,	0 },
		{ 356, 6, 'SPWI304',					6618,	'',		0,	0 },
		{ 357, 6, 'SPWI305',					12080,	'',		0,	0 },
		{ 358, 6, 'SPWI306',					12049,	'',		0,	0 },
		{ 359, 6, 'SPWI307',					12019,	'',		0,	0 }, -- Invisibility, 10' Radius
		{ 360, 6, 'SPWI308',					12060,	'',		0,	0 },
		{ 361, 6, 'SPWI309',					12035,	'',		0,	0 },
		{ 362, 6, 'SPWI310',					12027,	'',		0,	0 },
		{ 363, 6, 'SPWI311',					12028,	'',		0,	0 },
		{ 364, 6, 'SPWI312',					12081,	'',     0,	0 },
		{ 365, 6, 'SPWI313',					12072,	'',		0,	0 },
		{ 366, 6, 'SPWI314',					12071,	'',		0,	0 },
		{ 367, 6, 'SPWI315',					12020,	'',		0,	0 }, -- Wraithform
		{ 368, 6, 'SPWI316',					12050,	'',		0,	0 },
		{ 369, 6, 'SPWI317',					12129,	'',		0,	0 },
		{ 370, 6, 'SPWI318',					10861,	'',		0,	0 }, -- Minor Spell Deflection
		{ 371, 6, 'SPWI319',					12086,	'',		0,	0 }, -- Protection From Fire
		{ 372, 6, 'SPWI320',					7539,	'',		0,	0 }, -- Protection From Cold
		{ 373, 6, 'SPWI321',					25873,	'',		0,	0 }, -- Spell Thrust
		{ 374, 6, 'SPWI322',					25871,	'',		0,	0 }, -- Detect Illusion
		{ 375, 6, 'SPWI324',					32379,	'',		0,	0 }, -- Hold Undead
		{ 376, 6, 'SPWI325',					38588,	'',		0,	0 }, -- Melf's Minute Meteors
		{ 377, 6, 'SPWI326',					12026,	'',		0,	0 }, -- Dispel Magic
		{ 378, 6, 'SPWI401',					12051,	'',		0,	0 },
		{ 379, 6, 'SPWI402',					12082,	'',		0,	0 },
		{ 380, 6, 'SPWI403',					12061,	'',		0,	0 }, -- Fire Shield (Blue)
		{ 381, 6, 'SPWI404',					12062,	'',		0,	0 },
		{ 382, 6, 'SPWI405',					12021,	'',		0,	0 },
		{ 383, 6, 'SPWI406',					12029,	'',		0,	0 },
		{ 384, 6, 'SPWI407',					12037,	'',		0,	0 },
		{ 385, 6, 'SPWI408',					25875,	'',		0,	0 }, -- Stoneskin
		{ 386, 6, 'SPWI409',					12063,	'',		0,	0 },
		{ 387, 6, 'SPWI410',					12087,	'',		0,	0 },
		{ 388, 6, 'SPWI411',					22173,	'',		0,	0 },
		{ 389, 6, 'SPWI412',					22185,	'',		0,	0 },
		{ 390, 6, 'SPWI413',					22177,	'',		0,	0 },
		{ 391, 6, 'SPWI414',					22608,	'',		0,	0 },
		{ 392, 6, 'SPWI415',					20963,	'',		0,	0 },
		{ 393, 6, 'SPWI416',					22316,	'',		0,	0 },
		{ 394, 6, 'SPWI417',					25904,	'',		0,	0 }, -- Enchanted Weapon
		{ 395, 6, 'SPWI418',					25880,	'',		0,	0 }, -- Fire Shield (Red)
		{ 396, 6, 'SPWI419',					25884,	'',		0,	0 }, -- Secret Word
		{ 397, 6, 'SPWI420',					25889,	'',		0,	0 }, -- Minor Sequencer
		{ 398, 6, 'SPWI421',					25892,	'',		0,	0 }, -- Teleport Field
		{ 399, 6, 'SPWI423',					29207,	'',		0,	0 }, -- Spider Spawn
		{ 400, 6, 'SPWI424',					38133,	'',		0,	0 }, -- Farsight
		{ 401, 6, 'SPWI425',					38596,	'',		0,	0 }, -- Wizard Eye
		{ 402, 6, 'SPWI501',					12073,	'',		0,	0 },
		{ 403, 6, 'SPWI502',					12065,	'',		0,	0 },
		{ 404, 6, 'SPWI503',					12066,	'',		0,	0 },
		{ 405, 6, 'SPWI504',					12038,	'',		0,	0 },
		{ 406, 6, 'SPWI505',					12022,	'',		0,	0 },
		{ 407, 6, 'SPWI506',					22614,	'',		0,	0 },
		{ 408, 6, 'SPWI507',					22616,	'',		0,	0 },
		{ 409, 6, 'SPWI508',					22610,	'',		0,	0 },
		{ 410, 6, 'SPWI509',					22612,	'',		0,	0 },
		{ 411, 6, 'SPWI510',					25912,	'',		0,	0 }, -- Spell Immunity
		{ 412, 6, 'SPWI511',					7606,	'',		0,	0 }, -- Protection From Normal Weapons
		{ 413, 6, 'SPWI512',					7571,	'',		0,	0 }, -- Protection From Electricity
		{ 414, 6, 'SPWI513',					25914,	'',		0,	0 }, -- Breach
		{ 415, 6, 'SPWI514',					16963,	'',		0,	0 }, -- Lower Resistance
		{ 416, 6, 'SPWI515',					25927,	'',		0,	0 }, -- Oracle
		{ 417, 6, 'SPWI516',					24830,	'',		0,	0 }, -- Conjure Lesser Fire Elemental
		{ 418, 6, 'SPWI517',					7563,	'',		0,	0 }, -- Protection From Acid
		{ 419, 6, 'SPWI518',					7787,	'',		0,	0 }, -- Phantom Blade
		{ 420, 6, 'SPWI519',					26228,	'',		0,	0 }, -- Spell Shield
		{ 421, 6, 'SPWI520',					24827,	'',		0,	0 }, -- Conjure Lesser Air Elemental
		{ 422, 6, 'SPWI521',					24829,	'',		0,	0 }, -- Conjure Lesser Earth Elemental
		{ 423, 6, 'SPWI522',					10850,	'',		0,	0 }, -- Minor Spell Turning
		{ 424, 6, 'SPWI523',					39964,	'',		0,	0 }, -- Sunfire
		{ 425, 6, 'SPWI601',					23790,	'',		0,	0 },
		{ 426, 6, 'SPWI602',					23791,	'',		0,	0 },
		{ 427, 6, 'SPWI603',					23792,	'',		0,	0 },
		{ 428, 6, 'SPWI604',					23793,	'',		0,	0 },
		{ 429, 6, 'SPWI605',					7917,	'',		0,	0 },
		{ 430, 6, 'SPWI606',					7930,	'',		0,	0 }, -- Protection From Magic Energy
		{ 431, 6, 'SPWI607',					25930,	'',		0,	0 }, -- Mislead
		{ 432, 6, 'SPWI608',					25934,	'',		0,	0 }, -- Pierce Magic
		{ 434, 6, 'SPWI609',					25633,	'',		0,	0 }, -- True Sight
		{ 435, 6, 'SPWI611',					7610,	'',		0,	0 }, -- Protection From Magical Weapons
		{ 436, 6, 'SPWI612',					7778,	'',		0,	0 }, -- Power Word, Silence
		{ 437, 6, 'SPWI613',					25937,	'',		0,	0 }, -- Improved Haste
		{ 438, 6, 'SPWI614',					7621,	'',		0,	0 }, -- Death Fog
		{ 439, 6, 'SPWI615',					25939,	'',		0,	0 }, -- Chain Lightning
		{ 440, 6, 'SPWI616',					2628,	'',		0,	0 }, -- Disintegrate
		{ 441, 6, 'SPWI617',					25942,	'',		0,	0 }, -- Contingency
		{ 442, 6, 'SPWI618',					10888,	'',		0,	0 }, -- Spell Deflection
		{ 443, 6, 'SPWI619',					24785,	'',		0,	0 }, -- Wyvern Call
		{ 444, 6, 'SPWI620',					15211,	'',		0,	0 }, -- Conjure Fire Elemental
		{ 445, 6, 'SPWI621',					24839,	'',		0,	0 }, -- Conjure Air Elemental
		{ 446, 6, 'SPWI622',					15180,	'',		0,	0 }, -- Conjure Earth Elemental
		{ 447, 6, 'SPWI623',					29211,	'',		0,	0 }, -- Carrion Summons
		{ 448, 6, 'SPWI624',					29213,	'',		0,	0 }, -- Summon Nishruu
		{ 449, 6, 'SPWI625',					32393,	'',		0,	0 }, -- Stone to Flesh
		{ 450, 6, 'SPWI701',					10871,	'',		0,	0 }, -- Spell Turning
		{ 451, 6, 'SPWI702',					7598,	'',		0,	0 }, -- Protection From The Elements
		{ 452, 6, 'SPWI703',					25944,	'',		0,	0 }, -- Project Image
		{ 453, 6, 'SPWI704',					15465,	'',		0,	0 }, -- Ruby Ray of Reversal
		{ 454, 6, 'SPWI705',					25947,	'',		0,	0 }, -- Khelben's Warding Whip
		{ 455, 6, 'SPWI707',					17320,	'',		0,	0 }, -- Cacofiend
		{ 456, 6, 'SPWI708',					7612,	'',		0,	0 }, -- Mantle
		{ 457, 6, 'SPWI710',					25951,	'',		0,	0 }, -- Spell Sequencer
		{ 458, 6, 'SPWI711',					25953,	'',		0,	0 }, -- Sphere of Chaos
		{ 459, 6, 'SPWI712',					25958,	'',		0,	0 }, -- Delayed Blast Fireball
		{ 460, 6, 'SPWI713',					7665,	'',		0,	0 }, -- Finger of Death
		{ 461, 6, 'SPWI714',					25960,	'',		0,	0 }, -- Prismatic Spray
		{ 462, 6, 'SPWI715',					22143,	'',		0,	0 }, -- Power Word, Stun
		{ 463, 6, 'SPWI716',					7831,	'',		0,	0 }, -- Mordenkainen's Sword
		{ 464, 6, 'SPWI717',					29215,	'',		0,	0 }, -- Summon Efreeti
		{ 465, 6, 'SPWI718',					29217,	'',		0,	0 }, -- Summon Djinni
		{ 466, 6, 'SPWI719',					29219,	'',		0,	0 }, -- Summon Hakeashar
		{ 467, 6, 'SPWI720',					32409,	'',		0,	0 }, -- Control Undead
		{ 468, 6, 'SPWI721',					32427,	'',		0,	0 }, -- Mass Invisibility
		{ 469, 6, 'SPWI722',					38598,	'',		0,	0 }, -- Limited Wish
		{ 470, 6, 'SPWI723',					64324,	'',		0,	0 }, -- Improved Chaos Shield
		{ 471, 6, 'SPWI803',					7600,	'',		0,	0 }, -- Protection From Energy
		{ 472, 6, 'SPWI804',					26234,	'',		0,	0 }, -- Simulacrum
		{ 473, 6, 'SPWI805',					26240,	'',		0,	0 }, -- Pierce Shield
		{ 474, 6, 'SPWI807',					17360,	'',		0,	0 }, -- Summon Fiend
		{ 475, 6, 'SPWI808',					7617,	'',		0,	0 }, -- Improved Mantle
		{ 476, 6, 'SPWI809',					26243,	'',		0,	0 }, -- Spell Trigger
		{ 477, 6, 'SPWI810',					7663,	'',		0,	0 }, -- Incendiary Cloud
		{ 478, 6, 'SPWI811',					22145,	'',		0,	0 }, -- Symbol, Fear
		{ 479, 6, 'SPWI812',					7679,	'',		0,	0 }, -- Abi-Dalzim's Horrid Wilting
		{ 480, 6, 'SPWI813',					18141,	'',		0,	0 }, -- Maze
		{ 481, 6, 'SPWI815',					7783,	'',		0,	0 }, -- Power Word, Blind
		{ 482, 6, 'SPWI816',					39956,	'',		0,	0 }, -- Symbol, Stun
		{ 483, 6, 'SPWI817',					39966,	'',		0,	0 }, -- Symbol, Death
		{ 484, 6, 'SPWI818',					63097,	'',		0,	0 }, -- Bigby's Clenched Fist
		{ 485, 6, 'SPWI902',					26304,	'',		0,	0 }, -- Spell Trap
		{ 486, 6, 'SPWI903',					26314,	'',		0,	0 }, -- Spellstrike
		{ 487, 6, 'SPWI905',					14260,	'',		0,	0 }, -- Gate
		{ 488, 6, 'SPWI907',					7619,	'',		0,	0 }, -- Absolute Immunity
		{ 489, 6, 'SPWI908',					26328,	'',		0,	0 }, -- Chain Contingency
		{ 490, 6, 'SPWI909',					26332,	'',		0,	0 }, -- Time Stop
		{ 491, 6, 'SPWI910',					16946,	'',		0,	0 }, -- Imprisonment
		{ 492, 6, 'SPWI911',					26345,	'',		0,	0 }, -- Meteor Swarm
		{ 493, 6, 'SPWI912',					22142,	'',		0,	0 }, -- Power Word, Kill
		{ 494, 6, 'SPWI913',					7710,	'',		0,	0 }, -- Wail of the Banshee
		{ 495, 6, 'SPWI914',					23358,	'',		0,	0 }, -- Energy Drain 
		{ 496, 6, 'SPWI915',					7851,	'',		0,	0 }, -- Black Blade of Disaster
		{ 497, 6, 'SPWI916',					26356,	'',		0,	0 }, -- Shapechange
		{ 498, 6, 'SPWI917',					35553,	'',		0,	0 }, -- Freedom
		{ 499, 6, 'SPWI918',					63153,	'',		0,	0 }, -- Bigby's Crushing Hand
		{ 500, 6, 'SPWI919',					63157,	'',		0,	0 }, -- Wish		
        { 501, 6, 'SPWI920',                    63615,  '',     0,  0 }, -- Energy Blades        
        { 502, 6, 'SPWI921',                    63217,  '',     0,  0 }, -- Improved Alacrity        
        { 503, 6, 'SPWI922',                    63219,  '',     0,  0 }, -- Dragon's Breath        
        { 504, 6, 'SPWI923',                    63231,  '',     0,  0 }, -- Summon Planetar    
        { 505, 6, 'SPWI924',                    63233,  '',     0,  0 }, -- Summon Dark Planetar    
        { 506, 6, 'SPWI925',                    63580,  '',     0,  0 } -- Comet		
	}
};
keycategories = 
{
	{ 1, "ASSIGN_KEYS_PAGE", 			'Keymap Page' },
	{ 2, "ASSIGN_KEYS_ACTIONS", 		'Keymap Action' },
	{ 3, "ASSIGN_KEYS_MISC", 			'Keymap Miscellaneous' },
	{ 4, "ASSIGN_KEYS_QUICKSLOTS", 		'Keymap Quick Slots' },
	{ 5, "ASSIGN_KEYS_PRIESTSPELLS",	'Priest Spells' },
	{ 6, "ASSIGN_KEYS_MAGESPELLS", 		'Mage Spells' }
};

languages = {
    {'zh_CN', 103214, 103215, 'Chinese (Simplified)'},	
	{'en_US', 99385, 99386, 'English'},
	{'fr_FR', 103580, 103581, 'French'},
	{'de_DE', 103039, 103040, 'German'},
	{'it_IT', 103044, 103045, 'Italian'},
    {'ko_KR', 103582, 103583, 'Korean'},
    {'pl_PL', 103218, 103219, 'Polish'},
	{'ru_RU', 103216, 103217, 'Russian'},
	{'es_ES', 103037, 103038, 'Spanish'}
}

journal={}
info={}
user={}
quests_old = 
{
	{  1,'main',74295,1,0,0,-1},
	{  2,'',74318,0,0,0,-1},
	{  3,'',16202,0,0,0,-1},
	{  4,'',74319,0,0,0,-1},
	{  5,'',74320,0,0,0,-1},
	{  6,'',74321,0,0,0,-1},
	{  7,'',74322,0,0,0,-1},
	{  8,'',74323,0,0,0,-1},
	{  9,'',74324,0,0,0,-1},
	{ 10,'',74325,0,0,0,-1},
	{ 11,'',74326,0,0,0,-1},
	{ 12,'',74327,0,0,0,-1},
	{ 13,'',74328,0,0,0,-1},
	{ 14,'',74329,0,0,0,-1},
	{ 15,'',74330,0,0,0,-1},
	{ 16,'',74331,0,0,0,-1},
	{ 17,'',74332,0,0,0,-1},
	{ 18,'',74333,0,0,0,-1},
	{ 19,'',74334,0,0,0,-1},
	{ 20,'',74335,0,0,0,-1},
	{ 21,'',74336,0,0,0,-1},
	{ 22,'',74337,0,0,0,-1},
	{ 23,'',74338,0,0,0,-1},
	{ 24,'',74339,0,0,0,-1},
	{ 25,'',74340,0,0,0,-1},
	{ 26,'',74341,0,0,0,-1},
	{ 27,'',74342,0,0,0,-1},
	{ 28,'',74343,0,0,0,-1},
	{ 29,'',74344,0,0,0,-1},
	{ 30,'',74345,0,0,0,-1},
	{ 31,'',74346,0,0,0,-1},
	{ 32,'',74347,0,0,0,-1},
	{ 33,'',74348,0,0,0,-1},
	{ 34,'',74349,0,0,0,-1},
	{ 35,'',74350,0,0,0,-1},
	{ 36,'',74351,0,0,0,-1},
	{ 37,'',74352,0,0,0,-1},
	{ 38,'',74353,0,0,0,-1},
	{ 39,'',74354,0,0,0,-1},
	{ 40,'',74355,0,0,0,-1},
	{ 41,'',74356,0,0,0,-1},
	{ 42,'',74357,0,0,0,-1},
	{ 43,'',74358,0,0,0,-1},
	{ 44,'',74359,0,0,0,-1},
	{ 45,'',74360,0,0,0,-1},
	{ 46,'',74361,0,0,0,-1},
	{ 47,'',74362,0,0,0,-1},
	{ 48,'',74363,0,0,0,-1},
	{ 49,'',74364,0,0,0,-1},
	{ 50,'',74365,0,0,0,-1},
	{ 51,'',74366,0,0,0,-1},
	{ 52,'',74367,0,0,0,-1},
	{ 53,'',74368,0,0,0,-1},
	{ 54,'',74369,0,0,0,-1},
	{ 55,'',74370,0,0,0,-1},
	{ 56,'',74371,0,0,0,-1},
	{ 57,'',74372,0,0,0,-1},
	{ 58,'',74373,0,0,0,-1},
	{ 59,'',74374,0,0,0,-1},
	{ 60,'',74375,0,0,0,-1},
	{ 61,'',74376,0,0,0,-1},
	{ 62,'',74377,0,0,0,-1},
	{ 63,'',74378,0,0,0,-1},
	{ 64,'',74379,0,0,0,-1},
	{ 65,'',74380,0,0,0,-1},
	{ 66,'',74381,0,0,0,-1},
	{ 67,'',74382,0,0,0,-1},
	{ 68,'',74383,0,0,0,-1},
	{ 69,'',74384,0,0,0,-1},
	{ 70,'',74385,0,0,0,-1},
	{ 71,'',74386,0,0,0,-1},
	{ 72,'',74387,0,0,0,-1},
	{ 73,'',74388,0,0,0,-1},
	{ 74,'',74389,0,0,0,-1},
	{ 75,'',74390,0,0,0,-1},
	{ 76,'',74391,0,0,0,-1},
	{ 77,'',74392,0,0,0,-1},
	{ 78,'',74393,0,0,0,-1},
	{ 79,'',74394,0,0,0,-1},
	{ 80,'',74395,0,0,0,-1},
	{ 81,'',74396,0,0,0,-1},
	{ 82,'',74397,0,0,0,-1},
	{ 83,'',74398,0,0,0,-1},
	{ 84,'',74399,0,0,0,-1},
	{ 85,'',74400,0,0,0,-1},
	{ 86,'',74401,0,0,0,-1},
	{ 87,'',74402,0,0,0,-1},
	{ 88,'',74403,0,0,0,-1},
	{ 89,'',74404,0,0,0,-1},
	{ 90,'',74405,0,0,0,-1},
	{ 91,'',74406,0,0,0,-1},
	{ 92,'',74407,0,0,0,-1},
	{ 93,'',74408,0,0,0,-1},
	{ 94,'',74409,0,0,0,-1},
	{ 95,'',74410,0,0,0,-1},
	{ 96,'',74411,0,0,0,-1},
	{ 97,'',74412,0,0,0,-1},
	{ 98,'',74413,0,0,0,-1},
	{ 99,'',74414,0,0,0,-1},
	{100,'',74415,0,0,0,-1},
	{101,'',74416,0,0,0,-1},
	{102,'',74417,0,0,0,-1},
	{103,'',74418,0,0,0,-1},
	{104,'',74419,0,0,0,-1},
	{105,'',74420,0,0,0,-1},
	{106,'',74421,0,0,0,-1},
	{107,'',74422,0,0,0,-1},
	{108,'',74423,0,0,0,-1},
	{109,'',74424,0,0,0,-1},
	{110,'',74425,0,0,0,-1},
	{111,'',74426,0,0,0,-1},
	{112,'',74427,0,0,0,-1},
	{113,'',74428,0,0,0,-1},
	{114,'',74429,0,0,0,-1},
	{115,'',74430,0,0,0,-1},
	{116,'',74431,0,0,0,-1},
	{117,'',74432,0,0,0,-1},
	{118,'',74433,0,0,0,-1},
	{119,'',74434,0,0,0,-1},
	{120,'',74435,0,0,0,-1},
	{121,'',74436,0,0,0,-1},
	{122,'',74437,0,0,0,-1},
	{123,'',74438,0,0,0,-1},
	{124,'',74439,0,0,0,-1},
	{125,'',74440,0,0,0,-1},
	{126,'',74441,0,0,0,-1},
	{127,'',74442,0,0,0,-1},
	{128,'',74443,0,0,0,-1},
	{129,'',74444,0,0,0,-1},
	{130,'',74445,0,0,0,-1},
	{131,'',74446,0,0,0,-1},
	{132,'',74447,0,0,0,-1},
	{133,'',74448,0,0,0,-1},
	{134,'',74449,0,0,0,-1},
	{135,'',74450,0,0,0,-1},
	{136,'',74451,0,0,0,-1},
	{137,'',74452,0,0,0,-1},
	{138,'',74453,0,0,0,-1},
	{139,'',74454,0,0,0,-1},
	{140,'',74455,0,0,0,-1},
	{141,'',74456,0,0,0,-1},
	{142,'',74457,0,0,0,-1},
	{143,'',74458,0,0,0,-1},
	{144,'',74459,0,0,0,-1},
	{145,'',74460,0,0,0,-1},
	{146,'',74461,0,0,0,-1},
	{147,'',74462,0,0,0,-1},
	{148,'',74463,0,0,0,-1},
	{149,'',74464,0,0,0,-1},
	{150,'',74465,0,0,0,-1},
	{152,'',74467,0,0,0,-1},
	{153,'',74468,0,0,0,-1},
	{154,'',74469,0,0,0,-1},
	{155,'',74470,0,0,0,-1},
	{156,'',74471,0,0,0,-1},
	{157,'',74472,0,0,0,-1},
	{158,'',74473,0,0,0,-1},
	{159,'',74474,0,0,0,-1},
	{160,'',74475,0,0,0,-1},
	{161,'',74476,0,0,0,-1},
	{162,'',74477,0,0,0,-1},
	{163,'',74478,0,0,0,-1},
	{164,'',74479,0,0,0,-1},
	{165,'',74480,0,0,0,-1},
	{166,'',74481,0,0,0,-1},
	{167,'',66122,0,0,0,-1},
	{168,'',74482,0,0,0,-1},
	{169,'',74483,0,0,0,-1},
	{170,'',74484,0,0,0,-1},
	{171,'',74485,0,0,0,-1},
	{172,'',74486,0,0,0,-1},
	{173,'',74487,0,0,0,-1},
	{174,'',74488,0,0,0,-1},
	{175,'',74489,0,0,0,-1},
	{176,'',74490,0,0,0,-1},
	{177,'',74491,0,0,0,-1},
	{178,'',74492,0,0,0,-1},
	{179,'',74493,0,0,0,-1},
	{180,'',74494,0,0,0,-1},
	{181,'',74495,0,0,0,-1},
	{182,'',74496,0,0,0,-1},
	{183,'',74497,0,0,0,-1},
	{184,'',74498,0,0,0,-1},
	{185,'',74499,0,0,0,-1},
	{186,'',74500,0,0,0,-1},
	{187,'',74501,0,0,0,-1},
	{188,'',74502,0,0,0,-1},
	{189,'',74503,0,0,0,-1},
	{190,'',74504,0,0,0,-1},
	{191,'',74505,0,0,0,-1},
	{192,'',74506,0,0,0,-1},
	{193,'',74507,0,0,0,-1},
	{194,'',93935,0,0,0,-1},
	{195,'',94452,0,0,0,-1},
	{196,'',94457,0,0,0,-1},
	{197,'',94461,0,0,0,-1},
	{198,'',94464,0,0,0,-1},
	{199,'',94474,0,0,0,-1},
	{200,'',94483,0,0,0,-1},
	{201,'',94495,0,0,0,-1},
	{202,'',96076,0,0,0,-1},
	{203,'',96107,0,0,0,-1},
	{204,'',96115,0,0,0,-1},
	{205,'',100039,0,0,0,-1},
	{206,'',94558,0,0,0,-1},
	{207,'',94559,0,0,0,-1},
	{208,'',94560,0,0,0,-1},
	{209,'',102771,0,0,0,-1},
	{210,'',94033,0,0,0,-1},
	{211,'',88267,0,0,0,-1},
	{212,'',95779,0,0,0,-1},
	{213,'',95872,0,0,0,-1},
	{214,'',96007,0,0,0,-1},
	{215,'',96026,0,0,0,-1},
	{216,'',102772,0,0,0,-1},
	{217,'',94561,0,0,0,-1},
	{218,'',95658,0,0,0,-1},
};

journals_quests_old =
{
	{96383, 1, 0,0,'',-1},
	{96384, 1, 0,0,'',-1},
	{96385, 1, 0,0,'',-1},
	{96386, 1, 0,0,'',-1},
	{96387, 1, 0,0,'',-1},
	{96388, 1, 0,0,'',-1},
	{96389, 1, 0,0,'',-1},
	{96391, 1, 0,0,'',-1},
	{96390, 1, 0,0,'',-1},
	{96392, 1, 0,0,'',-1},
	{96393, 1, 0,0,'',-1},
	{96422, 1, 0,0,'',-1},
	{96437, 1, 0,0,'',-1},
	{96469, 1, 0,0,'',-1},
	{96521, 1, 0,0,'',-1},
	{96522, 1, 0,0,'',-1},
	{96528, 1, 0,0,'',-1},
	{96554, 1, 0,0,'',-1},
	{96562, 1, 0,0,'',-1},
	{96563, 1, 0,0,'',-1},
	{96576, 1, 0,0,'',-1},
	{96586, 1, 0,0,'',-1},
	{96636, 1, 0,0,'',-1},
	{96637, 1, 0,0,'',-1},
	{96642, 1, 0,0,'',-1},
	{96648, 1, 0,0,'',-1},
	{96650, 1, 0,0,'',-1},
	{96655, 1, 0,0,'',-1},
	{96656, 1, 0,0,'',-1},
	{96686, 1, 0,0,'',-1},
	{96687, 1, 0,0,'',-1},
	{96688, 1, 0,0,'',-1},
	{97314, 1, 0,0,'',-1},
	{97315, 1, 0,0,'',-1},
	{97316, 1, 0,0,'',-1},
	{97317, 1, 0,0,'',-1},
	{97318, 1, 0,0,'',-1},
	{97319, 1, 0,0,'',-1},
	{97320, 1, 0,0,'',-1},
	{97322, 1, 0,0,'',-1},
	{97325, 1, 0,0,'',-1},
	{97326, 1, 0,0,'',-1},
	{97327, 1, 0,0,'',-1},
	{97328, 1, 0,0,'',-1},
	{97329, 1, 0,0,'',-1},
	{97330, 1, 0,0,'',-1},
	{97331, 1, 0,0,'',-1},
	{97332, 1, 0,0,'',-1},
	{97333, 1, 0,0,'',-1},
	{97334, 1, 0,0,'',-1},
	{97335, 1, 0,0,'',-1},
	{97336, 1, 0,0,'',-1},
	{97337, 1, 0,0,'',-1},
	{97338, 1, 0,0,'',-1},
	{97339, 1, 0,0,'',-1},
	{97341, 1, 0,0,'',-1},
	{97340, 1, 0,0,'',-1},
	{97342, 1, 0,0,'',-1},
	{97343, 1, 0,0,'',-1},
	{97344, 1, 0,0,'',-1},
	{97345, 1, 0,0,'',-1},
	{97346, 1, 0,0,'',-1},
	{97347, 1, 0,0,'',-1},
	{97348, 1, 0,0,'',-1},
	{97349, 1, 0,0,'',-1},
	{97350, 1, 0,0,'',-1},
	{97351, 1, 0,0,'',-1},
	{97352, 1, 0,0,'',-1},
	{97353, 1, 0,0,'',-1},
	{97354, 1, 0,0,'',-1},
	{97355, 1, 0,0,'',-1},
	{97356, 1, 0,0,'',-1},
	{97357, 1, 0,0,'',-1},
	{97358, 1, 0,0,'',-1},
	{  293,  2,0,0,'',-1},
	{  465,  3,0,0,'',-1},
	{61973,  3,0,0,'',-1},
	{  843,  4,0,0,'',-1},
	{ 1340,  5,0,0,'',-1},
	{ 1349,  5,0,0,'',-1},
	{ 1363,  5,0,0,'',-1},
	{ 4751,  5,0,0,'',-1},
	{ 4833,  5,0,0,'',-1},
	{ 4834,  5,0,0,'',-1},
	{ 4836,  5,0,0,'',-1},
	{10626,  5,0,0,'',-1},
	{47970,  5,0,0,'',-1},
	{47971,  5,0,0,'',-1},
	{47972,  5,0,0,'',-1},
	{ 2025,  6,0,0,'',-1},
	{ 2028,  6,0,0,'',-1},
	{ 2065,  6,0,0,'',-1},
	{ 2069,  6,0,0,'',-1},
	{30375,  6,0,0,'',-1},
	{34387,  6,0,0,'',-1},
	{34388,  6,0,0,'',-1},
	{34391,  6,0,0,'',-1},
	{34399,  6,0,0,'',-1},
	{34407,  6,0,0,'',-1},
	{34413,  6,0,0,'',-1},
	{34416,  6,0,0,'',-1},
	{34417,  6,0,0,'',-1},
	{34418,  6,0,0,'',-1},
	{34419,  6,0,0,'',-1},
	{34420,  6,0,0,'',-1},
	{34422,  6,0,0,'',-1},
	{47712,  6,0,0,'',-1},
	{ 2051,  7,0,0,'',-1},
	{ 2070,  7,0,0,'',-1},
	{ 2073,  7,0,0,'',-1},
	{ 2076,  7,0,0,'',-1},
	{ 2080,  7,0,0,'',-1},
	{ 2081,  7,0,0,'',-1},
	{ 2082,  7,0,0,'',-1},
	{ 2083,  7,0,0,'',-1},
	{ 2088,  7,0,0,'',-1},
	{47721,  7,0,0,'',-1},
	{47723,  7,0,0,'',-1},
	{61261,  7,0,0,'',-1},
	{61262,  7,0,0,'',-1},
	{ 2052,  8,0,0,'',-1},
	{ 2057,  9,0,0,'',-1},
	{ 2060,  9,0,0,'',-1},
	{ 2061,  9,0,0,'',-1},
	{47736,  9,0,0,'',-1},
	{47737,  9,0,0,'',-1},
	{ 2071, 10,0,0,'',-1},
	{ 2072, 10,0,0,'',-1},
	{ 2074, 10,0,0,'',-1},
	{ 2075, 10,0,0,'',-1},
	{ 2077, 10,0,0,'',-1},
	{ 2079, 10,0,0,'',-1},
	{46838, 10,0,0,'',-1},
	{47726, 10,0,0,'',-1},
	{47735, 10,0,0,'',-1},
	{61915, 10,0,0,'',-1},
	{ 2097, 11,0,0,'',-1},
	{ 2098, 11,0,0,'',-1},
	{ 2099, 11,0,0,'',-1},
	{ 2119, 11,0,0,'',-1},
	{ 5828, 11,0,0,'',-1},
	{ 6607, 11,0,0,'',-1},
	{ 7169, 11,0,0,'',-1},
	{ 7240, 11,0,0,'',-1},
	{ 7738, 11,0,0,'',-1},
	{ 9704, 11,0,0,'',-1},
	{ 9932, 11,0,0,'',-1},
	{10102, 11,0,0,'',-1},
	{15722, 11,0,0,'',-1},
	{15723, 11,0,0,'',-1},
	{15727, 11,0,0,'',-1},
	{20256, 11,0,0,'',-1},
	{22949, 11,0,0,'',-1},
	{32002, 11,0,0,'',-1},
	{34497, 11,0,0,'',-1},
	{61267, 11,0,0,'',-1},
	{ 2118, 12,0,0,'',-1},
	{19272, 12,0,0,'',-1},
	{ 2147, 13,0,0,'',-1},
	{34144, 13,0,0,'',-1},
	{34168, 13,0,0,'',-1},
	{34172, 13,0,0,'',-1},
	{34182, 13,0,0,'',-1},
	{47536, 13,0,0,'',-1},
	{ 2319, 14,0,0,'',-1},
	{ 2320, 14,0,0,'',-1},
	{ 2321, 14,0,0,'',-1},
	{ 6609, 14,0,0,'',-1},
	{ 9976, 14,0,0,'',-1},
	{ 9977, 14,0,0,'',-1},
	{15721, 14,0,0,'',-1},
	{15743, 14,0,0,'',-1},
	{23550, 14,0,0,'',-1},
	{ 2939, 15,0,0,'',-1},
	{ 2940, 15,0,0,'',-1},
	{ 2957, 15,0,0,'',-1},
	{ 2965, 15,0,0,'',-1},
	{ 2966, 15,0,0,'',-1},
	{ 2967, 15,0,0,'',-1},
	{ 2971, 15,0,0,'',-1},
	{ 2972, 15,0,0,'',-1},
	{ 2973, 15,0,0,'',-1},
	{ 2974, 15,0,0,'',-1},
	{ 2975, 15,0,0,'',-1},
	{ 2993, 15,0,0,'',-1},
	{ 2996, 15,0,0,'',-1},
	{ 3013, 15,0,0,'',-1},
	{ 3017, 15,0,0,'',-1},
	{ 3024, 15,0,0,'',-1},
	{ 3027, 15,0,0,'',-1},
	{ 3028, 15,0,0,'',-1},
	{ 3029, 15,0,0,'',-1},
	{ 3030, 16,0,0,'',-1},
	{ 3031, 16,0,0,'',-1},
	{ 3032, 16,0,0,'',-1},
	{ 3033, 16,0,0,'',-1},
	{ 3034, 16,0,0,'',-1},
	{ 3036, 16,0,0,'',-1},
	{ 3039, 16,0,0,'',-1},
	{ 3040, 17,0,0,'',-1},
	{ 3296, 18,0,0,'',-1},
	{ 3301, 19,0,0,'',-1},
	{ 3303, 19,0,0,'',-1},
	{ 3304, 20,0,0,'',-1},
	{ 3361, 21,0,0,'',-1},
	{ 3362, 21,0,0,'',-1},
	{ 5059, 21,0,0,'',-1},
	{ 6934, 21,0,0,'',-1},
	{ 7235, 21,0,0,'',-1},
	{ 9982, 21,0,0,'',-1},
	{10106, 21,0,0,'',-1},
	{10107, 21,0,0,'',-1},
	{10670, 21,0,0,'',-1},
	{10671, 21,0,0,'',-1},
	{10933, 21,0,0,'',-1},
	{11645, 21,0,0,'',-1},
	{11661, 21,0,0,'',-1},
	{11681, 21,0,0,'',-1},
	{11686, 21,0,0,'',-1},
	{11689, 21,0,0,'',-1},
	{11755, 21,0,0,'',-1},
	{11884, 21,0,0,'',-1},
	{11904, 21,0,0,'',-1},
	{15698, 21,0,0,'',-1},
	{15703, 21,0,0,'',-1},
	{15715, 21,0,0,'',-1},
	{15760, 21,0,0,'',-1},
	{15783, 21,0,0,'',-1},
	{15794, 21,0,0,'',-1},
	{15801, 21,0,0,'',-1},
	{16541, 21,0,0,'',-1},
	{16558, 21,0,0,'',-1},
	{16677, 21,0,0,'',-1},
	{19364, 21,0,0,'',-1},
	{20367, 21,0,0,'',-1},
	{23504, 21,0,0,'',-1},
	{23512, 21,0,0,'',-1},
	{23521, 21,0,0,'',-1},
	{23530, 21,0,0,'',-1},
	{ 3374, 22,0,0,'',-1},
	{ 3377, 22,0,0,'',-1},
	{ 3716, 22,0,0,'',-1},
	{ 3927, 22,0,0,'',-1},
	{ 5814, 22,0,0,'',-1},
	{ 6542, 22,0,0,'',-1},
	{ 6555, 22,0,0,'',-1},
	{ 6589, 22,0,0,'',-1},
	{ 7002, 22,0,0,'',-1},
	{ 7122, 22,0,0,'',-1},
	{ 7243, 22,0,0,'',-1},
	{11864, 22,0,0,'',-1},
	{15710, 22,0,0,'',-1},
	{16331, 22,0,0,'',-1},
	{16351, 22,0,0,'',-1},
	{20214, 22,0,0,'',-1},
	{22924, 22,0,0,'',-1},
	{32084, 22,0,0,'',-1},
	{32085, 22,0,0,'',-1},
	{ 3422, 23,0,0,'',-1},
	{ 6557, 23,0,0,'',-1},
	{ 7241, 23,0,0,'',-1},
	{ 9705, 23,0,0,'',-1},
	{ 9919, 23,0,0,'',-1},
	{10047, 23,0,0,'',-1},
	{23551, 23,0,0,'',-1},
	{ 3654, 24,0,0,'',-1},
	{15693, 24,0,0,'',-1},
	{15714, 24,0,0,'',-1},
	{ 3680, 25,0,0,'',-1},
	{ 5823, 25,0,0,'',-1},
	{ 6467, 25,0,0,'',-1},
	{ 6587, 25,0,0,'',-1},
	{ 7170, 25,0,0,'',-1},
	{ 7684, 25,0,0,'',-1},
	{10109, 25,0,0,'',-1},
	{10116, 25,0,0,'',-1},
	{10929, 25,0,0,'',-1},
	{10931, 25,0,0,'',-1},
	{10936, 25,0,0,'',-1},
	{15809, 25,0,0,'',-1},
	{16669, 25,0,0,'',-1},
	{19432, 25,0,0,'',-1},
	{22948, 25,0,0,'',-1},
	{55580, 25,0,0,'',-1},
	{ 4323, 26,0,0,'',-1},
	{16543, 26,0,0,'',-1},
	{23447, 26,0,0,'',-1},
	{ 4352, 27,0,0,'',-1},
	{ 5017, 27,0,0,'',-1},
	{ 5742, 27,0,0,'',-1},
	{ 6330, 27,0,0,'',-1},
	{ 6426, 27,0,0,'',-1},
	{ 6427, 27,0,0,'',-1},
	{ 6436, 27,0,0,'',-1},
	{ 6437, 27,0,0,'',-1},
	{ 6438, 27,0,0,'',-1},
	{ 6443, 27,0,0,'',-1},
	{ 6945, 27,0,0,'',-1},
	{ 9738, 27,0,0,'',-1},
	{ 9980, 27,0,0,'',-1},
	{10250, 27,0,0,'',-1},
	{15713, 27,0,0,'',-1},
	{16557, 27,0,0,'',-1},
	{16671, 27,0,0,'',-1},
	{23346, 27,0,0,'',-1},
	{23503, 27,0,0,'',-1},
	{23537, 27,0,0,'',-1},
	{23557, 27,0,0,'',-1},
	{46841, 27,0,0,'',-1},
	{ 4354, 28,0,0,'',-1},
	{ 5802, 28,0,0,'',-1},
	{ 7045, 28,0,0,'',-1},
	{ 7701, 28,0,0,'',-1},
	{10140, 28,0,0,'',-1},
	{15719, 28,0,0,'',-1},
	{15720, 28,0,0,'',-1},
	{22934, 28,0,0,'',-1},
	{23404, 28,0,0,'',-1},
	{23523, 28,0,0,'',-1},
	{62156, 28,0,0,'',-1},
	{62157, 28,0,0,'',-1},
	{ 4659, 29,0,0,'',-1},
	{ 4661, 29,0,0,'',-1},
	{ 4662, 29,0,0,'',-1},
	{46843, 29,0,0,'',-1},
	{ 4660, 30,0,0,'',-1},
	{46844, 30,0,0,'',-1},
	{61115, 30,0,0,'',-1},
	{ 4679, 31,0,0,'',-1},
	{ 4680, 31,0,0,'',-1},
	{46845, 31,0,0,'',-1},
	{ 4685, 32,0,0,'',-1},
	{46846, 32,0,0,'',-1},
	{46847, 32,0,0,'',-1},
	{46848, 32,0,0,'',-1},
	{46849, 32,0,0,'',-1},
	{46850, 32,0,0,'',-1},
	{46851, 32,0,0,'',-1},
	{47761, 32,0,0,'',-1},
	{ 4838, 33,0,0,'',-1},
	{ 4840, 33,0,0,'',-1},
	{ 4841, 33,0,0,'',-1},
	{47980, 33,0,0,'',-1},
	{47981, 33,0,0,'',-1},
	{47982, 33,0,0,'',-1},
	{ 4997, 34,0,0,'',-1},
	{ 7686, 34,0,0,'',-1},
	{15779, 34,0,0,'',-1},
	{16531, 34,0,0,'',-1},
	{34657, 34,0,0,'',-1},
	{34658, 34,0,0,'',-1},
	{34659, 34,0,0,'',-1},
	{ 5014, 35,0,0,'',-1},
	{ 7242, 35,0,0,'',-1},
	{23225, 35,0,0,'',-1},
	{ 5083, 36,0,0,'',-1},
	{ 5825, 36,0,0,'',-1},
	{ 6549, 36,0,0,'',-1},
	{ 6576, 36,0,0,'',-1},
	{ 7025, 36,0,0,'',-1},
	{ 7079, 36,0,0,'',-1},
	{ 7262, 36,0,0,'',-1},
	{ 9920, 36,0,0,'',-1},
	{10073, 36,0,0,'',-1},
	{10074, 36,0,0,'',-1},
	{11648, 36,0,0,'',-1},
	{16002, 36,0,0,'',-1},
	{16336, 36,0,0,'',-1},
	{16354, 36,0,0,'',-1},
	{16542, 36,0,0,'',-1},
	{20986, 36,0,0,'',-1},
	{23395, 36,0,0,'',-1},
	{23489, 36,0,0,'',-1},
	{23491, 36,0,0,'',-1},
	{40131, 36,0,0,'',-1},
	{42371, 36,0,0,'',-1},
	{49487, 36,0,0,'',-1},
	{49488, 36,0,0,'',-1},
	{ 5696, 37,0,0,'',-1},
	{ 5697, 37,0,0,'',-1},
	{ 5698, 37,0,0,'',-1},
	{ 5699, 37,0,0,'',-1},
	{ 5700, 37,0,0,'',-1},
	{ 5743, 38,0,0,'',-1},
	{23513, 38,0,0,'',-1},
	{ 5775, 39,0,0,'',-1},
	{ 5776, 39,0,0,'',-1},
	{ 5824, 39,0,0,'',-1},
	{ 7040, 39,0,0,'',-1},
	{ 7747, 39,0,0,'',-1},
	{10004, 39,0,0,'',-1},
	{10005, 39,0,0,'',-1},
	{10124, 39,0,0,'',-1},
	{15706, 39,0,0,'',-1},
	{15747, 39,0,0,'',-1},
	{16316, 39,0,0,'',-1},
	{16329, 39,0,0,'',-1},
	{16570, 39,0,0,'',-1},
	{16571, 39,0,0,'',-1},
	{16572, 39,0,0,'',-1},
	{16573, 39,0,0,'',-1},
	{46852, 39,0,0,'',-1},
	{46853, 39,0,0,'',-1},
	{46854, 39,0,0,'',-1},
	{46855, 39,0,0,'',-1},
	{46856, 39,0,0,'',-1},
	{46857, 39,0,0,'',-1},
	{ 5810, 40,0,0,'',-1},
	{ 6403, 40,0,0,'',-1},
	{ 6405, 40,0,0,'',-1},
	{ 6535, 40,0,0,'',-1},
	{ 6545, 40,0,0,'',-1},
	{ 6582, 40,0,0,'',-1},
	{ 6590, 40,0,0,'',-1},
	{ 6943, 40,0,0,'',-1},
	{ 6954, 40,0,0,'',-1},
	{ 6999, 40,0,0,'',-1},
	{ 7001, 40,0,0,'',-1},
	{ 7147, 40,0,0,'',-1},
	{ 7148, 40,0,0,'',-1},
	{ 9649, 40,0,0,'',-1},
	{10104, 40,0,0,'',-1},
	{15792, 40,0,0,'',-1},
	{15793, 40,0,0,'',-1},
	{16339, 40,0,0,'',-1},
	{16529, 40,0,0,'',-1},
	{16668, 40,0,0,'',-1},
	{22931, 40,0,0,'',-1},
	{23424, 40,0,0,'',-1},
	{ 5811, 41,0,0,'',-1},
	{ 5831, 41,0,0,'',-1},
	{ 6538, 41,0,0,'',-1},
	{ 9703, 41,0,0,'',-1},
	{11880, 41,0,0,'',-1},
	{14924, 41,0,0,'',-1},
	{23547, 41,0,0,'',-1},
	{ 5812, 42,0,0,'',-1},
	{ 7168, 42,0,0,'',-1},
	{ 5819, 43,0,0,'',-1},
	{ 6603, 43,0,0,'',-1},
	{ 6606, 43,0,0,'',-1},
	{ 6613, 43,0,0,'',-1},
	{ 6955, 43,0,0,'',-1},
	{ 6956, 43,0,0,'',-1},
	{ 7012, 43,0,0,'',-1},
	{ 7013, 43,0,0,'',-1},
	{ 7014, 43,0,0,'',-1},
	{11546, 43,0,0,'',-1},
	{11854, 43,0,0,'',-1},
	{16564, 43,0,0,'',-1},
	{22930, 43,0,0,'',-1},
	{ 5822, 44,0,0,'',-1},
	{ 6556, 44,0,0,'',-1},
	{16007, 44,0,0,'',-1},
	{ 5826, 45,0,0,'',-1},
	{ 7085, 45,0,0,'',-1},
	{ 7167, 45,0,0,'',-1},
	{16548, 45,0,0,'',-1},
	{16549, 45,0,0,'',-1},
	{ 5827, 46,0,0,'',-1},
	{ 7944, 46,0,0,'',-1},
	{ 9918, 46,0,0,'',-1},
	{19286, 46,0,0,'',-1},
	{ 5832, 47,0,0,'',-1},
	{ 6933, 47,0,0,'',-1},
	{ 7032, 47,0,0,'',-1},
	{ 7096, 47,0,0,'',-1},
	{ 9978, 47,0,0,'',-1},
	{ 9986, 47,0,0,'',-1},
	{11690, 47,0,0,'',-1},
	{15725, 47,0,0,'',-1},
	{15745, 47,0,0,'',-1},
	{15746, 47,0,0,'',-1},
	{15787, 47,0,0,'',-1},
	{16333, 47,0,0,'',-1},
	{19438, 47,0,0,'',-1},
	{20170, 47,0,0,'',-1},
	{23444, 47,0,0,'',-1},
	{23445, 47,0,0,'',-1},
	{23485, 47,0,0,'',-1},
	{23486, 47,0,0,'',-1},
	{23500, 47,0,0,'',-1},
	{23519, 47,0,0,'',-1},
	{61412, 47,0,0,'',-1},
	{ 5833, 48,0,0,'',-1},
	{ 7256, 48,0,0,'',-1},
	{11821, 48,0,0,'',-1},
	{11872, 48,0,0,'',-1},
	{ 6279, 49,0,0,'',-1},
	{ 6496, 49,0,0,'',-1},
	{ 6501, 49,0,0,'',-1},
	{ 6836, 49,0,0,'',-1},
	{11883, 49,0,0,'',-1},
	{15718, 49,0,0,'',-1},
	{15748, 49,0,0,'',-1},
	{23446, 49,0,0,'',-1},
	{23481, 49,0,0,'',-1},
	{23482, 49,0,0,'',-1},
	{23506, 49,0,0,'',-1},
	{ 6288, 50,0,0,'',-1},
	{ 6447, 51,0,0,'',-1},
	{ 6594, 51,0,0,'',-1},
	{10127, 51,0,0,'',-1},
	{16555, 51,0,0,'',-1},
	{23340, 51,0,0,'',-1},
	{23492, 51,0,0,'',-1},
	{ 6509, 52,0,0,'',-1},
	{ 6534, 52,0,0,'',-1},
	{ 7995, 52,0,0,'',-1},
	{ 8127, 52,0,0,'',-1},
	{ 8128, 52,0,0,'',-1},
	{ 8129, 52,0,0,'',-1},
	{10128, 52,0,0,'',-1},
	{16302, 52,0,0,'',-1},
	{16343, 52,0,0,'',-1},
	{16524, 52,0,0,'',-1},
	{16544, 52,0,0,'',-1},
	{16569, 52,0,0,'',-1},
	{20179, 52,0,0,'',-1},
	{20365, 52,0,0,'',-1},
	{20453, 52,0,0,'',-1},
	{23371, 52,0,0,'',-1},
	{23409, 52,0,0,'',-1},
	{ 6550, 53,0,0,'',-1},
	{ 6592, 53,0,0,'',-1},
	{ 7020, 53,0,0,'',-1},
	{ 7021, 53,0,0,'',-1},
	{ 7264, 53,0,0,'',-1},
	{10119, 53,0,0,'',-1},
	{10592, 53,0,0,'',-1},
	{10620, 53,0,0,'',-1},
	{ 6554, 54,0,0,'',-1},
	{10010, 54,0,0,'',-1},
	{10105, 54,0,0,'',-1},
	{15797, 54,0,0,'',-1},
	{62079, 54,0,0,'',-1},
	{ 6558, 55,0,0,'',-1},
	{ 6572, 56,0,0,'',-1},
	{ 6830, 56,0,0,'',-1},
	{ 9998, 56,0,0,'',-1},
	{20542, 56,0,0,'',-1},
	{ 6583, 57,0,0,'',-1},
	{ 6584, 57,0,0,'',-1},
	{ 6585, 57,0,0,'',-1},
	{10103, 57,0,0,'',-1},
	{10125, 57,0,0,'',-1},
	{11775, 57,0,0,'',-1},
	{16335, 57,0,0,'',-1},
	{23341, 57,0,0,'',-1},
	{ 6597, 58,0,0,'',-1},
	{ 7166, 58,0,0,'',-1},
	{ 6601, 59,0,0,'',-1},
	{ 6602, 60,0,0,'',-1},
	{ 6605, 61,0,0,'',-1},
	{22910, 61,0,0,'',-1},
	{34188, 61,0,0,'',-1},
	{34189, 61,0,0,'',-1},
	{ 6996, 62,0,0,'',-1},
	{ 7022, 62,0,0,'',-1},
	{ 7023, 62,0,0,'',-1},
	{ 7024, 62,0,0,'',-1},
	{ 7026, 62,0,0,'',-1},
	{10108, 62,0,0,'',-1},
	{15696, 62,0,0,'',-1},
	{15731, 62,0,0,'',-1},
	{15803, 62,0,0,'',-1},
	{15805, 62,0,0,'',-1},
	{15965, 62,0,0,'',-1},
	{16530, 62,0,0,'',-1},
	{20371, 62,0,0,'',-1},
	{20452, 62,0,0,'',-1},
	{22914, 62,0,0,'',-1},
	{37194, 62,0,0,'',-1},
	{ 7034, 63,0,0,'',-1},
	{32082, 63,0,0,'',-1},
	{32083, 63,0,0,'',-1},
	{34668, 63,0,0,'',-1},
	{34669, 63,0,0,'',-1},
	{ 7036, 64,0,0,'',-1},
	{16028, 64,0,0,'',-1},
	{ 7075, 65,0,0,'',-1},
	{ 7123, 65,0,0,'',-1},
	{15701, 65,0,0,'',-1},
	{16563, 65,0,0,'',-1},
	{20593, 65,0,0,'',-1},
	{ 7076, 66,0,0,'',-1},
	{ 7084, 67,0,0,'',-1},
	{23545, 67,0,0,'',-1},
	{23562, 67,0,0,'',-1},
	{ 7088, 68,0,0,'',-1},
	{ 7090, 69,0,0,'',-1},
	{ 7236, 69,0,0,'',-1},
	{ 7683, 69,0,0,'',-1},
	{ 7737, 69,0,0,'',-1},
	{ 8302, 69,0,0,'',-1},
	{10269, 69,0,0,'',-1},
	{11771, 69,0,0,'',-1},
	{ 7144, 70,0,0,'',-1},
	{16348, 70,0,0,'',-1},
	{ 7146, 71,0,0,'',-1},
	{10928, 71,0,0,'',-1},
	{11855, 71,0,0,'',-1},
	{20939, 71,0,0,'',-1},
	{20943, 71,0,0,'',-1},
	{ 7163, 72,0,0,'',-1},
	{22945, 72,0,0,'',-1},
	{ 7252, 73,0,0,'',-1},
	{ 7253, 73,0,0,'',-1},
	{ 7255, 73,0,0,'',-1},
	{22952, 73,0,0,'',-1},
	{23306, 73,0,0,'',-1},
	{ 7994, 74,0,0,'',-1},
	{ 8126, 74,0,0,'',-1},
	{ 8730, 75,0,0,'',-1},
	{23351, 75,0,0,'',-1},
	{ 9682, 76,0,0,'',-1},
	{15751, 76,0,0,'',-1},
	{15752, 76,0,0,'',-1},
	{16535, 76,0,0,'',-1},
	{23407, 76,0,0,'',-1},
	{ 9979, 77,0,0,'',-1},
	{10718, 77,0,0,'',-1},
	{15705, 77,0,0,'',-1},
	{16553, 77,0,0,'',-1},
	{34114, 77,0,0,'',-1},
	{10066, 78,0,0,'',-1},
	{10101, 79,0,0,'',-1},
	{16338, 79,0,0,'',-1},
	{10122, 80,0,0,'',-1},
	{10131, 80,0,0,'',-1},
	{11817, 80,0,0,'',-1},
	{22941, 80,0,0,'',-1},
	{23535, 80,0,0,'',-1},
	{10123, 81,0,0,'',-1},
	{15735, 81,0,0,'',-1},
	{15739, 81,0,0,'',-1},
	{23561, 81,0,0,'',-1},
	{10837, 82,0,0,'',-1},
	{53278, 82,0,0,'',-1},
	{54410, 82,0,0,'',-1},
	{54413, 82,0,0,'',-1},
	{57859, 82,0,0,'',-1},
	{57860, 82,0,0,'',-1},
	{57863, 82,0,0,'',-1},
	{57864, 82,0,0,'',-1},
	{57894, 82,0,0,'',-1},
	{10935, 83,0,0,'',-1},
	{16533, 83,0,0,'',-1},
	{10944, 84,0,0,'',-1},
	{11722, 85,0,0,'',-1},
	{15724, 86,0,0,'',-1},
	{22917, 86,0,0,'',-1},
	{15784, 87,0,0,'',-1},
	{16556, 88,0,0,'',-1},
	{47983, 88,0,0,'',-1},
	{47984, 88,0,0,'',-1},
	{19636, 89,0,0,'',-1},
	{19681, 89,0,0,'',-1},
	{19682, 90,0,0,'',-1},
	{19688, 90,0,0,'',-1},
	{47987, 90,0,0,'',-1},
	{47988, 90,0,0,'',-1},
	{47989, 90,0,0,'',-1},
	{47990, 90,0,0,'',-1},
	{20311, 91,0,0,'',-1},
	{20632, 92,0,0,'',-1},
	{20633, 92,0,0,'',-1},
	{20671, 93,0,0,'',-1},
	{22928, 93,0,0,'',-1},
	{34231, 93,0,0,'',-1},
	{47985, 93,0,0,'',-1},
	{20694, 94,0,0,'',-1},
	{21650, 95,0,0,'',-1},
	{21892, 96,0,0,'',-1},
	{34294, 96,0,0,'',-1},
	{23458, 97,0,0,'',-1},
	{23508, 98,0,0,'',-1},
	{34089, 99,0,0,'',-1},
	{34092,100,0,0,'',-1},
	{34093,100,0,0,'',-1},
	{47779,100,0,0,'',-1},
	{34099,101,0,0,'',-1},
	{47514,101,0,0,'',-1},
	{47515,101,0,0,'',-1},
	{34105,102,0,0,'',-1},
	{47519,102,0,0,'',-1},
	{34106,103,0,0,'',-1},
	{47518,103,0,0,'',-1},
	{34107,104,0,0,'',-1},
	{47522,104,0,0,'',-1},
	{34108,105,0,0,'',-1},
	{47523,105,0,0,'',-1},
	{34110,106,0,0,'',-1},
	{34111,106,0,0,'',-1},
	{47528,106,0,0,'',-1},
	{34112,107,0,0,'',-1},
	{34113,107,0,0,'',-1},
	{47531,107,0,0,'',-1},
	{34118,108,0,0,'',-1},
	{34119,108,0,0,'',-1},
	{47532,108,0,0,'',-1},
	{34183,109,0,0,'',-1},
	{34187,109,0,0,'',-1},
	{47537,109,0,0,'',-1},
	{34194,110,0,0,'',-1},
	{34198,110,0,0,'',-1},
	{34201,110,0,0,'',-1},
	{34205,110,0,0,'',-1},
	{34207,110,0,0,'',-1},
	{34211,110,0,0,'',-1},
	{34217,110,0,0,'',-1},
	{34218,110,0,0,'',-1},
	{34220,110,0,0,'',-1},
	{34232,110,0,0,'',-1},
	{34233,110,0,0,'',-1},
	{34234,110,0,0,'',-1},
	{34235,110,0,0,'',-1},
	{34236,110,0,0,'',-1},
	{34237,110,0,0,'',-1},
	{34238,110,0,0,'',-1},
	{34239,110,0,0,'',-1},
	{34240,110,0,0,'',-1},
	{34241,110,0,0,'',-1},
	{34243,110,0,0,'',-1},
	{47538,110,0,0,'',-1},
	{47545,110,0,0,'',-1},
	{34244,111,0,0,'',-1},
	{34245,111,0,0,'',-1},
	{34246,111,0,0,'',-1},
	{47725,111,0,0,'',-1},
	{34247,112,0,0,'',-1},
	{34249,112,0,0,'',-1},
	{34265,112,0,0,'',-1},
	{34266,112,0,0,'',-1},
	{34267,112,0,0,'',-1},
	{34269,112,0,0,'',-1},
	{34271,112,0,0,'',-1},
	{34276,112,0,0,'',-1},
	{34277,112,0,0,'',-1},
	{34281,112,0,0,'',-1},
	{34287,112,0,0,'',-1},
	{47575,112,0,0,'',-1},
	{47578,112,0,0,'',-1},
	{34290,113,0,0,'',-1},
	{47651,113,0,0,'',-1},
	{47704,113,0,0,'',-1},
	{34291,114,0,0,'',-1},
	{34295,114,0,0,'',-1},
	{34296,114,0,0,'',-1},
	{34299,114,0,0,'',-1},
	{34300,114,0,0,'',-1},
	{47581,114,0,0,'',-1},
	{34301,115,0,0,'',-1},
	{34302,115,0,0,'',-1},
	{34307,115,0,0,'',-1},
	{34311,115,0,0,'',-1},
	{34315,115,0,0,'',-1},
	{34324,115,0,0,'',-1},
	{34337,116,0,0,'',-1},
	{47705,116,0,0,'',-1},
	{34382,117,0,0,'',-1},
	{34383,117,0,0,'',-1},
	{34384,117,0,0,'',-1},
	{47710,117,0,0,'',-1},
	{34385,118,0,0,'',-1},
	{34386,119,0,0,'',-1},
	{34443,120,0,0,'',-1},
	{34712,120,0,0,'',-1},
	{34717,120,0,0,'',-1},
	{34718,120,0,0,'',-1},
	{34719,120,0,0,'',-1},
	{34720,120,0,0,'',-1},
	{34721,120,0,0,'',-1},
	{34725,120,0,0,'',-1},
	{34726,120,0,0,'',-1},
	{47992,120,0,0,'',-1},
	{47993,120,0,0,'',-1},
	{47994,120,0,0,'',-1},
	{47995,120,0,0,'',-1},
	{47996,120,0,0,'',-1},
	{47997,120,0,0,'',-1},
	{47998,120,0,0,'',-1},
	{47999,120,0,0,'',-1},
	{48000,120,0,0,'',-1},
	{34660,121,0,0,'',-1},
	{34661,121,0,0,'',-1},
	{34662,121,0,0,'',-1},
	{34663,121,0,0,'',-1},
	{34664,121,0,0,'',-1},
	{34665,121,0,0,'',-1},
	{34666,121,0,0,'',-1},
	{34667,121,0,0,'',-1},
	{48002,121,0,0,'',-1},
	{48003,121,0,0,'',-1},
	{48017,121,0,0,'',-1},
	{48018,121,0,0,'',-1},
	{34673,122,0,0,'',-1},
	{34683,122,0,0,'',-1},
	{34687,122,0,0,'',-1},
	{34691,122,0,0,'',-1},
	{34692,122,0,0,'',-1},
	{34695,122,0,0,'',-1},
	{34696,122,0,0,'',-1},
	{43045,123,0,0,'',-1},
	{45237,124,0,0,'',-1},
	{55522,124,0,0,'',-1},
	{55524,124,0,0,'',-1},
	{55526,124,0,0,'',-1},
	{55527,124,0,0,'',-1},
	{55530,124,0,0,'',-1},
	{55531,124,0,0,'',-1},
	{55532,124,0,0,'',-1},
	{55533,124,0,0,'',-1},
	{55534,124,0,0,'',-1},
	{55535,124,0,0,'',-1},
	{55536,124,0,0,'',-1},
	{55537,124,0,0,'',-1},
	{55538,124,0,0,'',-1},
	{55539,124,0,0,'',-1},
	{55540,124,0,0,'',-1},
	{55541,124,0,0,'',-1},
	{55542,124,0,0,'',-1},
	{55543,124,0,0,'',-1},
	{46839,125,0,0,'',-1},
	{47740,125,0,0,'',-1},
	{46840,126,0,0,'',-1},
	{47742,126,0,0,'',-1},
	{46842,127,0,0,'',-1},
	{47517,128,0,0,'',-1},
	{47759,129,0,0,'',-1},
	{51915,129,0,0,'',-1},
	{51916,129,0,0,'',-1},
	{47783,130,0,0,'',-1},
	{47805,130,0,0,'',-1},
	{47806,130,0,0,'',-1},
	{47831,130,0,0,'',-1},
	{47837,130,0,0,'',-1},
	{47838,130,0,0,'',-1},
	{47839,130,0,0,'',-1},
	{47848,131,0,0,'',-1},
	{47851,131,0,0,'',-1},
	{47854,131,0,0,'',-1},
	{47862,132,0,0,'',-1},
	{47863,132,0,0,'',-1},
	{47864,132,0,0,'',-1},
	{47866,132,0,0,'',-1},
	{47873,132,0,0,'',-1},
	{47874,132,0,0,'',-1},
	{47986,133,0,0,'',-1},
	{47991,134,0,0,'',-1},
	{48001,135,0,0,'',-1},
	{48012,136,0,0,'',-1},
	{48014,136,0,0,'',-1},
	{48015,136,0,0,'',-1},
	{48016,136,0,0,'',-1},
	{48013,137,0,0,'',-1},
	{48019,138,0,0,'',-1},
	{49258,139,0,0,'',-1},
	{50733,139,0,0,'',-1},
	{50749,139,0,0,'',-1},
	{54895,139,0,0,'',-1},
	{54924,139,0,0,'',-1},
	{54925,139,0,0,'',-1},
	{54926,139,0,0,'',-1},
	{54927,139,0,0,'',-1},
	{54929,139,0,0,'',-1},
	{54930,139,0,0,'',-1},
	{54935,139,0,0,'',-1},
	{54936,139,0,0,'',-1},
	{54946,139,0,0,'',-1},
	{54947,139,0,0,'',-1},
	{54948,139,0,0,'',-1},
	{54949,139,0,0,'',-1},
	{54950,139,0,0,'',-1},
	{54951,139,0,0,'',-1},
	{54952,139,0,0,'',-1},
	{55128,139,0,0,'',-1},
	{55203,139,0,0,'',-1},
	{55232,139,0,0,'',-1},
	{55265,139,0,0,'',-1},
	{55291,139,0,0,'',-1},
	{55342,139,0,0,'',-1},
	{55363,139,0,0,'',-1},
	{55364,139,0,0,'',-1},
	{55365,139,0,0,'',-1},
	{55366,139,0,0,'',-1},
	{55497,139,0,0,'',-1},
	{55499,139,0,0,'',-1},
	{55503,139,0,0,'',-1},
	{55504,139,0,0,'',-1},
	{55505,139,0,0,'',-1},
	{55506,139,0,0,'',-1},
	{55507,139,0,0,'',-1},
	{55508,139,0,0,'',-1},
	{55509,139,0,0,'',-1},
	{55510,139,0,0,'',-1},
	{55511,139,0,0,'',-1},
	{55513,139,0,0,'',-1},
	{49465,140,0,0,'',-1},
	{49476,140,0,0,'',-1},
	{49472,141,0,0,'',-1},
	{51885,142,0,0,'',-1},
	{51888,142,0,0,'',-1},
	{53242,142,0,0,'',-1},
	{54288,142,0,0,'',-1},
	{54289,142,0,0,'',-1},
	{54290,142,0,0,'',-1},
	{54291,142,0,0,'',-1},
	{54293,143,0,0,'',-1},
	{54376,143,0,0,'',-1},
	{54686,144,0,0,'',-1},
	{57914,144,0,0,'',-1},
	{57940,144,0,0,'',-1},
	{57944,144,0,0,'',-1},
	{57946,144,0,0,'',-1},
	{57948,144,0,0,'',-1},
	{57949,144,0,0,'',-1},
	{57950,144,0,0,'',-1},
	{57951,144,0,0,'',-1},
	{57952,144,0,0,'',-1},
	{57954,144,0,0,'',-1},
	{57958,144,0,0,'',-1},
	{54928,145,0,0,'',-1},
	{55408,146,0,0,'',-1},
	{55409,146,0,0,'',-1},
	{55435,147,0,0,'',-1},
	{55458,147,0,0,'',-1},
	{55459,147,0,0,'',-1},
	{55544,148,0,0,'',-1},
	{55545,148,0,0,'',-1},
	{55546,148,0,0,'',-1},
	{55547,148,0,0,'',-1},
	{55548,148,0,0,'',-1},
	{55549,148,0,0,'',-1},
	{55550,148,0,0,'',-1},
	{55551,148,0,0,'',-1},
	{55552,148,0,0,'',-1},
	{55553,148,0,0,'',-1},
	{55554,148,0,0,'',-1},
	{55555,148,0,0,'',-1},
	{55556,148,0,0,'',-1},
	{55557,148,0,0,'',-1},
	{55558,148,0,0,'',-1},
	{55559,148,0,0,'',-1},
	{55560,148,0,0,'',-1},
	{55561,148,0,0,'',-1},
	{55562,148,0,0,'',-1},
	{55563,148,0,0,'',-1},
	{55564,148,0,0,'',-1},
	{55565,148,0,0,'',-1},
	{55566,148,0,0,'',-1},
	{61436,148,0,0,'',-1},
	{61437,148,0,0,'',-1},
	{61438,148,0,0,'',-1},
	{55567,149,0,0,'',-1},
	{55568,149,0,0,'',-1},
	{55569,149,0,0,'',-1},
	{55570,149,0,0,'',-1},
	{55571,149,0,0,'',-1},
	{55572,149,0,0,'',-1},
	{55573,149,0,0,'',-1},
	{55574,149,0,0,'',-1},
	{55575,149,0,0,'',-1},
	{55576,149,0,0,'',-1},
	{55577,149,0,0,'',-1},
	{55578,149,0,0,'',-1},
	{55579,149,0,0,'',-1},
	{55581,149,0,0,'',-1},
	{55582,149,0,0,'',-1},
	{55583,149,0,0,'',-1},
	{55584,149,0,0,'',-1},
	{55585,149,0,0,'',-1},
	{55586,149,0,0,'',-1},
	{55587,149,0,0,'',-1},
	{55588,149,0,0,'',-1},
	{55589,149,0,0,'',-1},
	{55590,149,0,0,'',-1},
	{55591,149,0,0,'',-1},
	{55592,149,0,0,'',-1},
	{55593,149,0,0,'',-1},
	{55594,149,0,0,'',-1},
	{55595,149,0,0,'',-1},
	{55596,149,0,0,'',-1},
	{55597,149,0,0,'',-1},
	{55598,149,0,0,'',-1},
	{55599,149,0,0,'',-1},
	{55600,149,0,0,'',-1},
	{55601,149,0,0,'',-1},
	{55602,149,0,0,'',-1},
	{55603,149,0,0,'',-1},
	{55604,149,0,0,'',-1},
	{55605,149,0,0,'',-1},
	{55606,149,0,0,'',-1},
	{55607,149,0,0,'',-1},
	{55608,149,0,0,'',-1},
	{55609,149,0,0,'',-1},
	{55610,149,0,0,'',-1},
	{55611,149,0,0,'',-1},
	{55612,149,0,0,'',-1},
	{55613,149,0,0,'',-1},
	{55614,149,0,0,'',-1},
	{55615,149,0,0,'',-1},
	{55616,149,0,0,'',-1},
	{55617,149,0,0,'',-1},
	{55618,149,0,0,'',-1},
	{55619,149,0,0,'',-1},
	{55620,149,0,0,'',-1},
	{55621,149,0,0,'',-1},
	{55622,149,0,0,'',-1},
	{55623,149,0,0,'',-1},
	{55624,149,0,0,'',-1},
	{55625,150,0,0,'',-1},
	{55626,150,0,0,'',-1},
	{55627,150,0,0,'',-1},
	{55628,150,0,0,'',-1},
	{55629,150,0,0,'',-1},
	{55630,150,0,0,'',-1},
	{55631,150,0,0,'',-1},
	{55632,150,0,0,'',-1},
	{55633,150,0,0,'',-1},
	{55634,150,0,0,'',-1},
	{55635,150,0,0,'',-1},
	{55636,150,0,0,'',-1},
	{55637,150,0,0,'',-1},
	{55638,150,0,0,'',-1},
	{55639,150,0,0,'',-1},
	{55640,150,0,0,'',-1},
	{55641,150,0,0,'',-1},
	{55642,150,0,0,'',-1},
	{55643,150,0,0,'',-1},
	{55644,150,0,0,'',-1},
	{57515,151,0,0,'',-1},
	{57518,152,0,0,'',-1},
	{57533,153,0,0,'',-1},
	{57534,153,0,0,'',-1},
	{57535,153,0,0,'',-1},
	{57536,153,0,0,'',-1},
	{57851,153,0,0,'',-1},
	{57854,153,0,0,'',-1},
	{57856,153,0,0,'',-1},
	{57549,154,0,0,'',-1},
	{57550,154,0,0,'',-1},
	{57551,155,0,0,'',-1},
	{57552,155,0,0,'',-1},
	{57553,155,0,0,'',-1},
	{57554,155,0,0,'',-1},
	{57555,155,0,0,'',-1},
	{57556,155,0,0,'',-1},
	{57557,155,0,0,'',-1},
	{57558,156,0,0,'',-1},
	{57566,156,0,0,'',-1},
	{57567,156,0,0,'',-1},
	{57568,156,0,0,'',-1},
	{57569,156,0,0,'',-1},
	{57570,156,0,0,'',-1},
	{57579,156,0,0,'',-1},
	{57559,157,0,0,'',-1},
	{57563,158,0,0,'',-1},
	{57580,159,0,0,'',-1},
	{57761,160,0,0,'',-1},
	{57767,161,0,0,'',-1},
	{57768,161,0,0,'',-1},
	{57779,161,0,0,'',-1},
	{57842,161,0,0,'',-1},
	{57843,161,0,0,'',-1},
	{57866,162,0,0,'',-1},
	{57868,162,0,0,'',-1},
	{61279,163,0,0,'',-1},
	{61280,163,0,0,'',-1},
	{61348,164,0,0,'',-1},
	{61352,164,0,0,'',-1},
	{61413,165,0,0,'',-1},
	{61414,165,0,0,'',-1},
	{62038,166,0,0,'',-1},
	{62402,167,0,0,'',-1},
	{62423,167,0,0,'',-1},
	{62461,167,0,0,'',-1},
	{62481,167,0,0,'',-1},
	{62581,167,0,0,'',-1},
	{62582,167,0,0,'',-1},
	{62594,167,0,0,'',-1},
	{62660,167,0,0,'',-1},
	{62665,167,0,0,'',-1},
	{62682,167,0,0,'',-1},
	{62987,167,0,0,'',-1},
	{63048,167,0,0,'',-1},
	{63049,167,0,0,'',-1},
	{63091,167,0,0,'',-1},
	{71078,167,0,0,'',-1},
	{63733,168,0,0,'',-1},
	{63734,168,0,0,'',-1},
	{63735,168,0,0,'',-1},
	{63736,169,0,0,'',-1},
	{63737,169,0,0,'',-1},
	{63738,169,0,0,'',-1},
	{63739,169,0,0,'',-1},
	{63813,170,0,0,'',-1},
	{63815,170,0,0,'',-1},
	{63816,170,0,0,'',-1},
	{63819,170,0,0,'',-1},
	{71159,170,0,0,'',-1},
	{63822,171,0,0,'',-1},
	{63823,171,0,0,'',-1},
	{63824,172,0,0,'',-1},
	{63825,172,0,0,'',-1},
	{63827,173,0,0,'',-1},
	{63832,173,0,0,'',-1},
	{63833,173,0,0,'',-1},
	{63836,173,0,0,'',-1},
	{63837,173,0,0,'',-1},
	{64995,174,0,0,'',-1},
	{65001,174,0,0,'',-1},
	{65003,174,0,0,'',-1},
	{65062,174,0,0,'',-1},
	{73957,174,0,0,'',-1},
	{73961,174,0,0,'',-1},
	{64998,175,0,0,'',-1},
	{65000,175,0,0,'',-1},
	{65594,175,0,0,'',-1},
	{65015,176,0,0,'',-1},
	{65028,176,0,0,'',-1},
	{65031,176,0,0,'',-1},
	{65034,176,0,0,'',-1},
	{65038,176,0,0,'',-1},
	{65041,176,0,0,'',-1},
	{65045,176,0,0,'',-1},
	{65049,176,0,0,'',-1},
	{65051,176,0,0,'',-1},
	{65052,176,0,0,'',-1},
	{65769,177,0,0,'',-1},
	{66112,177,0,0,'',-1},
	{66117,177,0,0,'',-1},
	{66121,177,0,0,'',-1},
	{66143,177,0,0,'',-1},
	{66263,177,0,0,'',-1},
	{66262,178,0,0,'',-1},
	{66357,179,0,0,'',-1},
	{67720,179,0,0,'',-1},
	{67721,179,0,0,'',-1},
	{67722,179,0,0,'',-1},
	{67723,179,0,0,'',-1},
	{67747,179,0,0,'',-1},
	{67464,180,0,0,'',-1},
	{67465,180,0,0,'',-1},
	{67471,180,0,0,'',-1},
	{67718,181,0,0,'',-1},
	{67719,181,0,0,'',-1},
	{72245,181,0,0,'',-1},
	{70666,182,0,0,'',-1},
	{71102,183,0,0,'',-1},
	{72343,184,0,0,'',-1},
	{73207,184,0,0,'',-1},
	{73384,184,0,0,'',-1},
	{73477,185,0,0,'',-1},
	{73724,185,0,0,'',-1},
	{73725,185,0,0,'',-1},
	{73726,185,0,0,'',-1},
	{73727,185,0,0,'',-1},
	{73728,185,0,0,'',-1},
	{73729,185,0,0,'',-1},
	{73731,185,0,0,'',-1},
	{73732,185,0,0,'',-1},
	{73733,185,0,0,'',-1},
	{73486,186,0,0,'',-1},
	{73487,186,0,0,'',-1},
	{73488,186,0,0,'',-1},
	{73489,186,0,0,'',-1},
	{73490,186,0,0,'',-1},
	{73491,186,0,0,'',-1},
	{73526,187,0,0,'',-1},
	{73855,188,0,0,'',-1},
	{73856,188,0,0,'',-1},
	{73857,189,0,0,'',-1},
	{73858,190,0,0,'',-1},
	{73859,191,0,0,'',-1},
	{73861,192,0,0,'',-1},
	{73863,192,0,0,'',-1},
	{73864,192,0,0,'',-1},
	{73865,192,0,0,'',-1},
	{73958,193,0,0,'',-1},
	{73959,193,0,0,'',-1},
	{85016,194,0,0,'',-1},
	{85023,194,0,0,'',-1},
	{85025,194,0,0,'',-1},
	{85034,194,0,0,'',-1},
	{85056,194,0,0,'',-1},
	{85058,194,0,0,'',-1},
	{85066,194,0,0,'',-1},
	{85067,194,0,0,'',-1},
	{85068,194,0,0,'',-1},
	{85069,194,0,0,'',-1},
	{85086,194,0,0,'',-1},
	{85091,194,0,0,'',-1},
	{85092,194,0,0,'',-1},
	{85093,194,0,0,'',-1},
	{94024,194,0,0,'',-1},
	{94025,194,0,0,'',-1},
	{93943,194,0,0,'',-1},
	{93946,194,0,0,'',-1},
	{93979,194,0,0,'',-1},
	{93980,194,0,0,'',-1},
	{93981,194,0,0,'',-1},
	{93984,194,0,0,'',-1},
	{93985,194,0,0,'',-1},
	{93988,194,0,0,'',-1},
	{94453,195,0,0,'',-1},
	{94454,195,0,0,'',-1},
	{94455,195,0,0,'',-1},
	{94456,195,0,0,'',-1},
	{94458,196,0,0,'',-1},
	{94459,196,0,0,'',-1},
	{94460,196,0,0,'',-1},
	{94462,197,0,0,'',-1},
	{94463,197,0,0,'',-1},
	{94465,198,0,0,'',-1},
	{94466,198,0,0,'',-1},
	{94467,198,0,0,'',-1},
	{94475,199,0,0,'',-1},
	{94476,199,0,0,'',-1},
	{94477,199,0,0,'',-1},
	{94478,199,0,0,'',-1},
	{94479,199,0,0,'',-1},
	{94480,199,0,0,'',-1},
	{94481,199,0,0,'',-1},
	{94482,199,0,0,'',-1},
	{94484,200,0,0,'',-1},
	{94485,200,0,0,'',-1},
	{94486,200,0,0,'',-1},
	{94487,200,0,0,'',-1},
	{94488,200,0,0,'',-1},
	{94489,200,0,0,'',-1},
	{94490,200,0,0,'',-1},
	{94496,201,0,0,'',-1},
	{94497,201,0,0,'',-1},
	{94498,201,0,0,'',-1},
	{94499,201,0,0,'',-1},
	{94500,201,0,0,'',-1},
	{94501,201,0,0,'',-1},
	{94502,201,0,0,'',-1},
	{94503,201,0,0,'',-1},
	{94504,201,0,0,'',-1},
	{94505,201,0,0,'',-1},
	{94506,201,0,0,'',-1},
	{94507,201,0,0,'',-1},
	{96068,202,0,0,'',-1},
	{96069,202,0,0,'',-1},
	{96070,202,0,0,'',-1},
	{96071,202,0,0,'',-1},
	{96072,202,0,0,'',-1},
	{96073,202,0,0,'',-1},
	{96074,202,0,0,'',-1},
	{96075,202,0,0,'',-1},
	{91214,203,0,0,'',-1},
	{91248,203,0,0,'',-1},
	{91277,203,0,0,'',-1},
	{90354,203,0,0,'',-1},
	{90351,203,0,0,'',-1},
	{90346,203,0,0,'',-1},
	{90347,203,0,0,'',-1},
	{89660,203,0,0,'',-1},
	{89677,203,0,0,'',-1},
	{91528,203,0,0,'',-1},
	{92067,203,0,0,'',-1},
	{84943,204,0,0,'',-1},
	{84942,204,0,0,'',-1},
	{84945,204,0,0,'',-1},
	{84972,204,0,0,'',-1},
	{84948,204,0,0,'',-1},
	{84950,204,0,0,'',-1},
	{84949,204,0,0,'',-1},
	{84953,204,0,0,'',-1},
	{84955,204,0,0,'',-1},
	{84958,204,0,0,'',-1},
	{84964,204,0,0,'',-1},
	{84967,204,0,0,'',-1},
	{84971,204,0,0,'',-1},
	{85120,204,0,0,'',-1},
	{83513,204,0,0,'',-1},
	{85169,204,0,0,'',-1},
	{85172,204,0,0,'',-1},
	{85175,204,0,0,'',-1},
	{85290,204,0,0,'',-1},
	{86500,204,0,0,'',-1},
	{86506,204,0,0,'',-1},
	{103116,204,0,0,'',-1},
	{100040,205,0,0,'',-1},
	{100041,205,0,0,'',-1},
	{100042,205,0,0,'',-1},
	{90956,206,0,0,'',-1},
	{94553,206,0,0,'',-1},
	{94554,206,0,0,'',-1},
	{94555,206,0,0,'',-1},
	{94556,206,0,0,'',-1},
	{94557,206,0,0,'',-1},
	{93847,207,0,0,'',-1},
	{93848,207,0,0,'',-1},
	{90957,207,0,0,'',-1},
	{93849,207,0,0,'',-1},
	{93912,208,0,0,'',-1},
	{93913,208,0,0,'',-1},
	{93914,208,0,0,'',-1},
	{90952,209,0,0,'',-1},
	{90953,209,0,0,'',-1},
	{94032,210,0,0,'',-1},
	{94034,210,0,0,'',-1},
	{94035,210,0,0,'',-1},
	{94036,210,0,0,'',-1},
	{94037,210,0,0,'',-1},
	{94038,210,0,0,'',-1},
	{94039,210,0,0,'',-1},
	{94040,210,0,0,'',-1},
	{92593,211,0,0,'',-1},
	{92594,211,0,0,'',-1},
	{92595,211,0,0,'',-1},
	{92596,211,0,0,'',-1},
	{92597,211,0,0,'',-1},
	{95780,212,0,0,'',-1},
	{95781,212,0,0,'',-1},
	{95782,212,0,0,'',-1},
	{95783,212,0,0,'',-1},
	{95784,212,0,0,'',-1},
	{95785,212,0,0,'',-1},
	{95786,212,0,0,'',-1},
	{95787,212,0,0,'',-1},
	{95788,212,0,0,'',-1},
	{95789,212,0,0,'',-1},
	{95790,212,0,0,'',-1},
	{95873,213,0,0,'',-1},
	{95874,213,0,0,'',-1},
	{95875,213,0,0,'',-1},
	{92699,214,0,0,'',-1},
	{92700,214,0,0,'',-1},
	{92701,214,0,0,'',-1},
	{96027,215,0,0,'',-1},
	{96028,215,0,0,'',-1},
	{101238,216,0,0,'',-1},
	{101239,216,0,0,'',-1},
	{101240,216,0,0,'',-1},
	{101241,216,0,0,'',-1},
	{101242,216,0,0,'',-1},
	{101243,216,0,0,'',-1},
	{101244,216,0,0,'',-1},
	{101245,216,0,0,'',-1},
	{101246,216,0,0,'',-1},
	{101247,216,0,0,'',-1},
	{101248,216,0,0,'',-1},
	{101249,216,0,0,'',-1},
	{101250,216,0,0,'',-1},
	{101251,216,0,0,'',-1},
	{101252,216,0,0,'',-1},
	{90954,217,0,0,'',-1},
	{91264,217,0,0,'',-1},
	{91265,217,0,0,'',-1},
	{91576,217,0,0,'',-1},
	{91578,217,0,0,'',-1},
	{91579,217,0,0,'',-1},
	{94815,217,0,0,'',-1},
	{94816,217,0,0,'',-1},
	{92450,217,0,0,'',-1},
	{92451,217,0,0,'',-1},
	{92452,217,0,0,'',-1},
	{92859,217,0,0,'',-1},
	{92860,217,0,0,'',-1},
	{101266,217,0,0,'',-1},
	{101267,217,0,0,'',-1},
	{101268,217,0,0,'',-1},
	{101269,217,0,0,'',-1},
	{102773,217,0,0,'',-1},
	{103096,218,0,0,'',-1},
	{103099,218,0,0,'',-1},
};         

mp_sessions = {}
mp_sessions_jid = {}
mp_backend_type = 0
passwordMp = "password"

font_colors={}
--not from bgee. doesn't seem to be used in dragonspear:
-- font_colors['REALMS'] 	= '0xFFE2DDCF'
-- font_colors['NORMAL']	= '0xFF2C2121'
-- font_colors['STONESML']	= '0xFFCECECE'
-- font_colors['STONEBIG']	= '0xFFBCBCBC'
-- font_colors['INITIALS']	= '0xFFB98C00'

--from IWDEE, doesn't seem to be filled in for dragonspear
filenames_stringrefs={}
filenames_stringrefs['BDTPAM'] = {103244, 2}
filenames_stringrefs['BDTPBE'] = {103245, 2}
filenames_stringrefs['BDTPAG'] = {103246, 2}
filenames_stringrefs['BDTPDG'] = {103247, 2}
filenames_stringrefs['BDTPEH'] = {103248, 2}
filenames_stringrefs['BDTPSD'] = {103249, 2}
filenames_stringrefs['BDTPTO'] = {103250, 2}

-- filenames_stringrefs['MALE1'] = {12345, 2}
-- filenames_stringrefs['FEMALE1'] = {40380, 2}
-- filenames_stringrefs['FEMALE2'] = {40381, 2}
-- filenames_stringrefs['FEMALE3'] = {40382, 2}
-- filenames_stringrefs['FFIGHT1'] = {40375, 2}
-- filenames_stringrefs['FFIGHT2'] = {40376, 2}
-- filenames_stringrefs['FFIGHT3'] = {40377, 2}
-- filenames_stringrefs['FFIGHT4'] = {40378, 2}
-- filenames_stringrefs['FFIGHT5'] = {40379, 2}
-- filenames_stringrefs['FMAGE1'] = {40383, 2}
-- filenames_stringrefs['FMAGE2'] = {40384, 2}
-- filenames_stringrefs['FMAGE3'] = {40385, 2}
-- filenames_stringrefs['FMAGE4'] = {40386, 2}
-- filenames_stringrefs['FMAGE5'] = {40387, 2}
-- filenames_stringrefs['FTHIEF1'] = {40388, 2}
-- filenames_stringrefs['FTHIEF2'] = {40389, 2}
-- filenames_stringrefs['MALE1'] = {40390, 2}
-- filenames_stringrefs['MALE2'] = {40391, 2}
-- filenames_stringrefs['MALE3'] = {40392, 2}
-- filenames_stringrefs['MFIGHT1'] = {40393, 2}
-- filenames_stringrefs['MFIGHT2'] = {40394, 2}
-- filenames_stringrefs['MFIGHT3'] = {40395, 2}
-- filenames_stringrefs['MFIGHT4'] = {40396, 2}
-- filenames_stringrefs['MFIGHT5'] = {40397, 2}
-- filenames_stringrefs['MMAGE1'] = {40398, 2}
-- filenames_stringrefs['MMAGE2'] = {40399, 2}
-- filenames_stringrefs['MMAGE3'] = {40400, 2}
-- filenames_stringrefs['MMAGE4'] = {40401, 2}
-- filenames_stringrefs['MMAGE5'] = {40402, 2}
-- filenames_stringrefs['MTHIEF1'] = {40403, 2}
-- filenames_stringrefs['MTHIEF2'] = {40404, 2}

messageBoxMessageCount = 7
--TODO these should really become string refs.
-- CLOUD_SAVE_DOWNLOAD_FAILED,
-- CLOUD_SAVE_METADATA_WRITE_FAILED,
-- CLOUD_SAVE_METADATA_READ_FAILED,
-- CLOUD_SAVE_SNAPSHOT_LIST_DOWNLOAD_FAILED,
-- CLOUD_SAVE_CLOUD_READ_FAILED
-- CLOUD_SAVE_QUOTA_EXCEEDED
-- CLOUD_SAVE_FILE_TOO_LARGE	
messages = 
{
	'An error occurred while downloading a cloud save.',
	'An error occurred while writing a cloud save metadata file.',
	'An error occurred while reading a cloud save metadata file.',
	'An error occurred while downloading the list of cloud save files.',
	'An error occurred while uploading a cloud save.',
	'Your Steam cloud save storage quota has been exceeded.',
	'Save file is too large to upload to the Steam cloud.'
}

textflashes = {}
textflashidx = 1

cheatAreas = {
	{"AR0011", "Candlekeep Dream 1 (Do you remember Candlekeep?)"},
	{"AR0012", "Candlekeep Library (Main Door Trigger)"},
	{"AR0013", "Candlekeep Library (Stairway Triggers Up and Down)"},
	{"AR0014", "Candlekeep Library (Stairway Trigger Down)"},
	{"AR0020", "City Gates"},
	{"AR0021", "Crooked Crane 1st Floor"},
	{"AR0022", "Crooked Crane 2nd Floor"},
	{"AR0028", "Candlekeep Dream (After PC Soultheft)"},
	{"AR0041", "Random Encounter City"},
	{"AR0042", "Random Encounter Outdoor"},
	{"AR0043", "Random Encounter Outdoor (With rocks)"},
	{"AR0044", "Random Encounter Outdoor (sand)"},
	{"AR0045", "Random Encounter City"},
	{"AR0046", "Random Encounter City (bridge)"},
	{"AR0060", "Empty (Triggers, Doors... are there but no area)"},
	{"AR0061", "Empty (Triggers, Doors... are there but no area)"},
	{"AR0062", "Empty (Triggers, Doors... are there but no area)"},
	{"AR0063", "Empty (Triggers, Doors... are there but no area)"},
	{"AR0064", "Empty (Triggers, Doors... are there but no area)"},
	{"AR0065", "Empty (Triggers, Doors... are there but no area)"},
	{"AR0069", "Government Building (Cowled Cutscene -- 'Why is this man not gagged?')"},
	{"AR0070", "Spellhold (Irenicus Cutscene -- 'I cannot be caged...')"},
	{"AR0071", "Spellhold (Imoen Soultheft Cutscene -- 'Silence do, you have no purpose...')"},
	{"AR0072", "Ust Natha Temple (Irenicus/Bodhi, Ardula/Phaere Cutscene)"},
	{"AR0082", "Lich Grave in Bridge District Inn"},
	{"AR0083", "Candlekeep Library (Dream: PC learns to control the Slayer)"},
	{"AR0084", "Candlekeep Library (Stairway trigger down)"},
	{"AR0085", "Tree of Life"},
	{"AR0086", "Wooded Area"},
	{"AR0087", "Elven Dining Room"},
	{"AR0201", "Leading to ghoul village and beholder lair (Temple District)"},
	{"AR0202", "The Unseeing Eye Cult Hideout"},
	{"AR0203", "Temple of the Forgotten God -- Amaunator (Unseeing Eye Plot)"},
	{"AR0204", "The Forgotten Believers -- Temple City (Unseeing Eye Plot)"},
	{"AR0205", "The Beholder Hideout (Unseeing Eye Plot)"},
	{"AR0206", "Ghoul village (Temple District)"},
	{"AR0300", "The Docks"},
	{"AR0301", "Mae'Var's Hide Out"},
	{"AR0302", "Mae'Var's Inn 1st Floor -- Entrance"},
	{"AR0303", "Mae'Var's Inn 2nd Floor -- Training Area"},
	{"AR0304", "Mae'Var's Inn 3rd Floor -- Edwin"},
	{"AR0305", "Shadow Thieves Guild Entrance"},
	{"AR0306", "Renal Bloodscalp's Hideout"},
	{"AR0307", "Aran Linvail's Hideout"},
	{"AR0308", "Harper's 1st Floor"},
	{"AR0309", "Harper's 2nd Floor"},
	{"AR0310", "Pirates' Hideout in Sea Bounty Tavern"},
	{"AR0311", "Living Room (Entry points outside and up) -- Gaelan?"},
	{"AR0312", "Sleeping Room (Entry point down) -- Arledrian"},
	{"AR0313", "Sea Bounty Tavern 1st Floor"},
	{"AR0314", "Sea Bounty Tavern 2nd Floor"},
	{"AR0315", "Living Room (Favour for Edwin -- Mae'Var Plot)"},
	{"AR0316", "Sleeping Room (Favour for Edwin -- Mae'Var Plot)"},
	{"AR0317", "Sleeping Room (Favour for Edwin -- Mae'Var Plot)"},
	{"AR0318", "Storage Room"},
	{"AR0319", "Temple of Oghma"},
	{"AR0321", "Thief Stronghold (Hideout)"},
	{"AR0322", "Thief Stronghold (1st Floor)"},
	{"AR0323", "Thief Stronghold (2nd Floor)"},
	{"AR0324", "Thief Stronghold (3rd Floor)"},
	{"AR0325", "Corthala House 1st Floor"},
	{"AR0326", "Corthala House 2nd Floor"},
	{"AR0327", "Shadow Thief Entrance (sided with Bodhi)"},
	{"AR0328", "Shadow Thief 1st Floor (sided with Bodhi)"},
	{"AR0329", "Aran's Hideout (sided with Bodhi)"},
	{"AR0330", "House 1st Floor (Kangaxx)"},
	{"AR0331", "House Cellar (Kangaxx)"},
	{"AR0332", "Barracks in the Docks"},
	{"AR0333", "Barracks in the Docks"},
	{"AR0334", "Cromwell's Shop"},
	{"AR0335", "Sleeping Room"},
	{"AR0400", "Slums"},
	{"AR0401", "Jansen Cellar"},
	{"AR0402", "Jansen 1st Floor"},
	{"AR0403", "Jansen 2nd Floor"},
	{"AR0404", "Sewers beneath Coronet -- Lilarcor"},
	{"AR0405", "Slaver's Ship Building"},
	{"AR0406", "Copper Coronet"},
	{"AR0407", "Prebek's House"},
	{"AR0408", "Temple of Ilmater"},
	{"AR0409", "Living Room (Ployer's home)"},
	{"AR0410", "Sphere: Navigator's room -- Lavok's Hideout"},
	{"AR0411", "Sphere: Entrance floor"},
	{"AR0412", "Sphere: Ice and Fire Room"},
	{"AR0413", "Sphere: Enginge Room"},
	{"AR0414", "Sphere: Demon Plane"},
	{"AR0415", "Living Room 1st Floor"},
	{"AR0416", "Living Room 2nd Floor"},
	{"AR0417", "Living Room"},
	{"AR0418", "Myconids"},
	{"AR0419", "Myconid"},
	{"AR0420", "Sphere: Lizardmen Hideout"},
	{"AR0500", "Bridge District"},
	{"AR0501", "Tanner's Hideout 1st Floor"},
	{"AR0502", "Tanner's Hideout Cellar"},
	{"AR0503", "Tanner's Hideout Dock"},
	{"AR0504", "Saerk's House 1st Floor"},
	{"AR0505", "Saerk's House 2nd Floor"},
	{"AR0506", "Noble House 1st Floor"},
	{"AR0507", "Kidnappers' Hideout 1st Floor"},
	{"AR0508", "Kidnappers' Hideout 2nd Floor"},
	{"AR0509", "Five Flagons Inn 1st Floor"},
	{"AR0510", "Five Flagons Inn Theater"},
	{"AR0511", "Five Flagons Inn 2nd Floor"},
	{"AR0512", "Temple of Helm"},
	{"AR0513", "Calbor's Inn at Bridge District 1st Floor"},
	{"AR0514", "Inn at Bridge District 2nd Floor"},
	{"AR0515", "Inn at Bridge District 3rd Floor"},
	{"AR0516", "Planar Prison"},
	{"AR0517", "Planar Prison Cell"},
	{"AR0518", "Planar Prison Cell"},
	{"AR0519", "Planar Prison Cell"},
	{"AR0520", "Planar Prison Cell"},
	{"AR0521", "Planar Prison Cell"},
	{"AR0522", "Five Flagons Inn (Stronghold)"},
	{"AR0523", "Five Flagons Theater (Stronghold)"},
	{"AR0525", "House 1st Floor"},
	{"AR0526", "Sarcophagus Cellar"},
	{"AR0527", "House 1st Floor"},
	{"AR0528", "House 2nd Floor"},
	{"AR0529", "Neb's Hideout"},
	{"AR0530", "Storehouse"},
	{"AR0531", "Commoner House"},
	{"AR0600", "Circus Tent (phased)"},
	{"AR0601", "Air Plane in Irenicus's Dungeon"},
	{"AR0602", "Irenicus's Dungeon 1st Floor"},
	{"AR0603", "Irenicus's Dungeon 2nd Floor"},
	{"AR0604", "Circus Tent 1st Floor"},
	{"AR0605", "Circus Tent 2nd Floor"},
	{"AR0606", "Circus Tent 3rd Floor"},
	{"AR0607", "Circus Tent restored"},
	{"AR0700", "Waukeen's Promenade"},
	{"AR0701", "The Sewers"},
	{"AR0702", "Adventurer's Mart"},
	{"AR0703", "Temple of Ilmater"},
	{"AR0704", "Mithrest Inn"},
	{"AR0705", "Mekrath's Hideout in the Sewers (Haer'Dalis Plot)"},
	{"AR0706", "Armourer/Fletcher"},
	{"AR0707", "Enge's Shop"},
	{"AR0708", "Cernd's former home"},
	{"AR0709", "Den of the Seven Vales 1st Floor"},
	{"AR0710", "Fennecia's Home"},
	{"AR0711", "Illithid Hideout in the Sewers (The Hidden Plot)"},
	{"AR0712", "Den of the Seven Vales 2nd Floor"},
	{"AR0713", "Store or Inn at Promenade"},
	{"AR0714", "Debris at Waukeen's Promenade (Irenicus Cutscene in the beginning)"},
	{"AR0800", "Graveyard"},
	{"AR0801", "Bodhi's Hideout (sided with Aran)"},
	{"AR0802", "Netherscroll, Korgan's Book, Edwin"},
	{"AR0803", "Bodhi's Lair (sided with Aran)"},
	{"AR0804", "Pai'Na's Hideout"},
	{"AR0805", "Crypt"},
	{"AR0806", "Crypt"},
	{"AR0807", "Crypt"},
	{"AR0808", "Bodhi's Hideout (Abduction Plot, getting Imoen's soul)"},
	{"AR0809", "Bodhi's Lair (Abduction Plot, getting Imoen's soul)"},
	{"AR0810", "Crypt"},
	{"AR0811", "Crypt"},
	{"AR0812", "Crypt"},
	{"AR0813", "Crypt"},
	{"AR0900", "Temple District"},
	{"AR0901", "Temple of Helm"},
	{"AR0902", "Temple of Lathander"},
	{"AR0903", "Order of the Radiant Heart"},
	{"AR0904", "Temple of Talos"},
	{"AR0905", "Pimlico's Estate"},
	{"AR0906", "Guarded Compound 1st Floor"},
	{"AR0907", "Guarded Compound 2nd Floor"},
	{"AR1000", "Government District"},
	{"AR1001", "Delryn's Estate"},
	{"AR1002", "Councel Building"},
	{"AR1003", "Firecam's Estate"},
	{"AR1004", "Deril's Estate (Cernd Plot)"},
	{"AR1005", "Prison"},
	{"AR1006", "Jysstev's Estate (Oisig Plot)"},
	{"AR1007", "Noble House"},
	{"AR1008", "Twisted Rune"},
	{"AR1009", "Noble House (Isaea Roenall's)"},
	{"AR1010", "Temple of Waukeen"},
	{"AR1100", "Umar Hills"},
	{"AR1101", "Valygar's Cabin"},
	{"AR1102", "Merella's Cabin"},
	{"AR1103", "Jermien's Cabin"},
	{"AR1104", "Mayor Lloyd's Cabin"},
	{"AR1105", "Imnesvale Inn"},
	{"AR1106", "Umar's Cave"},
	{"AR1107", "Ranger-Protector's Cabin (Stronghold)"},
	{"AR1200", "Windspear Hills"},
	{"AR1201", "Firkraag's Entrance"},
	{"AR1202", "Firkraag's Maze"},
	{"AR1203", "Firkraag's Hideout"},
	{"AR1204", "Garren Windspear's Cabin"},
	{"AR1300", "De'Arnise Keep Destroyed"},
	{"AR1301", "De'Arnise Cellar"},
	{"AR1302", "De'Arnise Keep 1st Floor"},
	{"AR1303", "De'Arnise Keep 2nd Floor (Destroyed)"},
	{"AR1304", "De'Arnise Keep (Restored, Stronghold)"},
	{"AR1305", "De'Arnise Keep (Stronghold)"},
	{"AR1306", "De'Arnise Keep (Stronghold)"},
	{"AR1307", "De'Arnise Keep (Stronghold)"},
	{"AR1400", "Shadow Temple Land (restored, Ranger)"},
	{"AR1401", "Shadow Temple"},
	{"AR1402", "Shadow Dragon Hideout"},
	{"AR1403", "Wolfwere Hideout"},
	{"AR1404", "Shadow Temple Land shadowed"},
	{"AR1500", "Spellhold"},
	{"AR1501", "Cave (Spellhold Test)"},
	{"AR1502", "Fire Room (Spellhold Test)"},
	{"AR1503", "Spore Room (Spellhold Test)"},
	{"AR1504", "Crushing Trap Room (Spellhold Test)"},
	{"AR1505", "Lever Room (Spellhold Test)"},
	{"AR1506", "Troll Cave (Spellhold Test)"},
	{"AR1507", "Kobold Room (Spellhold Test)"},
	{"AR1508", "Final Judgement Spellhold Test"},
	{"AR1509", "Myconid Room (Spellhold Test)"},
	{"AR1510", "Sahuagin Room (Spellhold Test)"},
	{"AR1511", "Elven Table while Spellhold Test"},
	{"AR1512", "Bodhi's Hunt Level 1"},
	{"AR1513", "Bodhi's Hunt Level 2"},
	{"AR1514", "Bodhi's Hunt Level 3 (1st Slayer Change Happens here)"},
	{"AR1515", "Spellhold (Irenicus's Living Room)"},
	{"AR1516", "Spellhold (Soultheft Level)"},
	{"AR1600", "Brynnlaw"},
	{"AR1601", "Desharik's Estate"},
	{"AR1602", "Brynnlaw's Inn"},
	{"AR1603", "Brynnlaw's Shop"},
	{"AR1604", "Temple of Umberlee"},
	{"AR1605", "CW's House"},
	{"AR1606", "House of Desharik's Lover"},
	{"AR1607", "Githyanki Assault"},
	{"AR1608", "Cellar of Brothel"},
	{"AR1609", "Courtesan Room"},
	{"AR1610", "Brothel Prison"},
	{"AR1611", "Brothel"},
	{"AR1612", "Brothel Kitchen"},
	{"AR1613", "Brothel HQ"},
	{"AR1700", "Small Teeth Pass"},
	{"AR1800", "North Forest"},
	{"AR1900", "Druid Grove Area"},
	{"AR1901", "Druid Grove"},
	{"AR1902", "Storehouse (Ihtafeer's Storehouse)"},
	{"AR1904", "Troll Hill"},
	{"AR1905", "Store Tower"},
	{"AR2000", "Trademeet"},
	{"AR2001", "The Smithy"},
	{"AR2002", "Fentan's House"},
	{"AR2006", "Tiri's Home"},
	{"AR2007", "High Merchant's Estate"},
	{"AR2008", "Temple of Waukeen"},
	{"AR2009", "High Merchant Prison"},
	{"AR2010", "Trademeet's Inn"},
	{"AR2011", "Alibakkar's Estate"},
	{"AR2012", "Lurraxol's Estate"},
	{"AR2013", "Trademeet Crypt"},
	{"AR2014", "Djinni's Tent"},
	{"AR2015", "Merchant Tent"},
	{"AR2016", "Raffee's Tent"},
	{"AR2017", "Courtesan Tent"},
	{"AR2018", "Tent (no exit)"},
	{"AR2100", "Underdark"},
	{"AR2101", "Beholder Cave in Underdark"},
	{"AR2102", "Adalon's Cave"},
	{"AR2200", "Ust Natha"},
	{"AR2201", "Temple in Ust Natha"},
	{"AR2202", "Inn in Ust Natha 1st Floor"},
	{"AR2203", "Inn in Ust Natha; 2nd Floor"},
	{"AR2204", "House in Ust Natha"},
	{"AR2205", "House in Ust Natha"},
	{"AR2206", "Qilue's House in Ust Natha"},
	{"AR2207", "Deirex's Tower in Ust Natha"},
	{"AR2208", "Jarlaxle's House wherever"},
	{"AR2209", "Jae'llat's House"},
	{"AR2210", "Deirex's Cave"},
	{"AR2300", "Sahuagin City"},
	{"AR2400", "Mind Flayers in Underdark"},
	{"AR2401", "Cave Between Underdark and Exit from Underdark"},
	{"AR2402", "Kuo Toa in Underdark"},
	{"AR2500", "Elven Temple at Underdark Exit"},
	{"AR2600", "Thetyr Wood"},
	{"AR2601", "Meet Drizzt Do'Urden"},
	{"AR2602", "Cave in Woods to Suldanessellar"},
	{"AR2603", "Coran's Cabin"},
	{"AR2700", "Ancient Spirits?"},
	{"AR2800", "Suldanessellar"},
	{"AR2801", "House of High Priestess of Suldanessellar"},
	{"AR2802", "House in Suldanessellar"},
	{"AR2803", "Rillifane Temple"},
	{"AR2804", "To the Tree of Life (Entrance Hidden)"},
	{"AR2805", "To the Tree of Life (Entrance Revealed)"},
	{"AR2806", "Tree of Life"},
	{"AR2807", "Black Dragon's Hideout"},
	{"AR2808", "House in Suldanessellar"},
	{"AR2809", "House in Suldanessellar - Puzzle Box"},
	{"AR2810", "House in Suldanessellar"},
	{"AR2811", "House in Suldanessellar"},
	{"AR2812", "Temple of Rillifane after the Battle"},
	{"AR2900", "The Abyss"},
	{"AR2901", "Fear (Abyss)"},
	{"AR2902", "Pride (Abyss)"},
	{"AR2903", "Greed (Abyss)"},
	{"AR2904", "Selfish (Abyss)"},
	{"AR2905", "Sarevok (Abyss)"},
	{"AR2906", "Jon Battle ?"},
	{"AR3000", "Watcher's Keep"},
	{"AR3001", "Watcher's Keep -- Altar level"},
	{"AR3003", "Watcher's Keep -- Compass level"},
	{"AR3004", "Watcher's Keep"},
	{"AR3005", "Watcher's Keep -- tieflings"},
	{"AR3006", "Watcher's Keep -- Succubus"},
	{"AR3007", "Watcher's Keep --Cambion"},
	{"AR3008", "Watcher's Keep -- Baalor (Paladin Sword)"},
	{"AR3009", "Watcher's Keep -- Wild Magic ?"},
	{"AR3010", "Watcher's Keep -- Tanar'ri -- Obelisk"},
	{"AR3011", "Watcher's Keep -- Bard's Gloves, Manman's Journal"},
	{"AR3012", "Watcher's Keep -- Tahazzar"},
	{"AR3013", "Watcher's Keep -- Ka'rashur"},
	{"AR3014", "Watcher's Keep -- White Dragon Scales"},
	{"AR3015", "Watcher's Keep -- Aesgareth"},
	{"AR3016", "Watcher's Keep -- Chromatic Demon; Elementalist Level"},
	{"AR3017", "Watcher's Keep -- Carston and the machine"},
	{"AR3018", "Watcher's Keep -- Saladrex (Dragon)"},
	{"AR3019", "Watcher's Keep -- Helmite Level -- Last Seals"},
	{"AR3020", "Watcher's Keep -- Imprisoned One"},
	{"AR3021", "Watcher's Keep -- Illithids"},
	{"AR3022", "Watcher's Keep -- Anti-Paladins"},
	{"AR3023", "Watcher's Keep -- 'Adventure Level' (Mini Map!!!)"},
	{"AR3024", "Watcher's Keep -- Dragon -- Fear Challenge"},
	{"AR3025", "Watcher's Keep -- Orcs -- Ixil's Nail"},
	{"AR3026", "Watcher's Keep -- Imp -- Game"},
	{"AR3027", "Watcher's Keep -- Crypt -- Demi-Lich"},
	{"OH4000", "Rasaad - The Amphitheater"},
	{"OH4010", "Rasaad - Tears of Selune battle encounter"},
	{"OH4100", "Rasaad - Dark Moon Heretic Temple"},
	{"OH4101", "Rasaad - Dark Moon Heretic Temple Interior"},
	{"OH5000", "Dorn - Radiant Heart (Wedding)"},
	{"OH5100", "Dorn - Resurrection Gorge"},
	{"OH5110", "Dorn - Resurrection Gorge Cave"},
	{"OH5120", "Dorn - Resurrection Gorge Tree Interior"},
	{"OH5200", "Dorn - Resurrection Gorge Interior"},
	{"OH5300", "Dorn - Helmite Camp"},
	{"OH6000", "Neera - The Wild Forest"},
	{"OH6010", "Neera - Random Encounter in Athkatla"},
	{"OH6100", "Neera - The Hidden Refuge"},
	{"OH6200", "Neera - The Hidden Refuge (Destroyed)"},
	{"OH6300", "Neera - Red Wizard Enclave"},
	{"OH7000", "Hexxat - Top Left Quarter (Dragomir)"},
	{"OH7100", "Hexxat - Bottom Left Quarter (Shou Lung)"},
	{"OH7200", "Hexxat - Bottom Right Quarter (Zakhara)"},
}
cheatAreasArena = {
	{"OH8000", "TBP2 - Suzail Tavern"},
	{"OH8100", "TBP2 - Staging Area Map"},
	{"OH8200", "TBP2 - Arena 1"},
	{"OH8300", "TBP2 - Arena 2"},
	{"OH8400", "TBP2 - Arena 3"},
}
cheatAreasTutorial = {
	{"AR0015", "Baldur's Gate Estate (Tutorial starts here)"},
	{"AR0016", "Baldur's Gate Estate (Tutorial area)"},
	{"AR0017", "Baldur's Gate Estate (Tutorial area)"},
	{"AR0018", "Baldur's Gate Estate Cellar (Tutorial area)"},
}
cheatAreasExpansion = {
	{"AR3000", "Watcher's Keep"},
	{"AR3001", "Watcher's Keep -- Altar level"},
	{"AR3003", "Watcher's Keep -- Compass level"},
	{"AR3004", "Watcher's Keep"},
	{"AR3005", "Watcher's Keep -- tieflings"},
	{"AR3006", "Watcher's Keep -- Succubus"},
	{"AR3007", "Watcher's Keep --Cambion"},
	{"AR3008", "Watcher's Keep -- Baalor (Paladin Sword)"},
	{"AR3009", "Watcher's Keep -- Wild Magic ?"},
	{"AR3010", "Watcher's Keep -- Tanar'ri -- Obelisk"},
	{"AR3011", "Watcher's Keep -- Bard's Gloves, Manman's Journal"},
	{"AR3012", "Watcher's Keep -- Tahazzar"},
	{"AR3013", "Watcher's Keep -- Ka'rashur"},
	{"AR3014", "Watcher's Keep -- White Dragon Scales"},
	{"AR3015", "Watcher's Keep -- Aesgareth"},
	{"AR3016", "Watcher's Keep -- Chromatic Demon; Elementalist Level"},
	{"AR3017", "Watcher's Keep -- Carston and the machine"},
	{"AR3018", "Watcher's Keep -- Saladrex (Dragon)"},
	{"AR3019", "Watcher's Keep -- Helmite Level -- Last Seals"},
	{"AR3020", "Watcher's Keep -- Imprisoned One"},
	{"AR3021", "Watcher's Keep -- Illithids"},
	{"AR3022", "Watcher's Keep -- Anti-Paladins"},
	{"AR3023", "Watcher's Keep -- 'Adventure Level' (Mini Map!!!)"},
	{"AR3024", "Watcher's Keep -- Dragon -- Fear Challenge"},
	{"AR3025", "Watcher's Keep -- Orcs -- Ixil's Nail"},
	{"AR3026", "Watcher's Keep -- Imp -- Game"},
	{"AR3027", "Watcher's Keep -- Crypt -- Demi-Lich"},
	{"AR4000", "Spirit Heads"},
	{"AR4500", "Pocket Plane"},
	{"AR5000", "Saradush"},
	{"AR5001", "Gromnir 1st Level"},
	{"AR5002", "Gromnir's Hideout"},
	{"AR5003", "Saradush Tavern (Tankard Tree)"},
	{"AR5004", "Temple of Waukeen"},
	{"AR5005", "Gromnir's Barracks"},
	{"AR5006", "Saradush Prison"},
	{"AR5007", "Basement Entrance to Gromnir's Hideout"},
	{"AR5008", "Kiser's Home"},
	{"AR5009", "House (no exit?)"},
	{"AR5010", "Countess Santele's Home"},
	{"AR5011", "Arcana Archives"},
	{"AR5012", "House"},
	{"AR5013", "Sewers beneath Saradush"},
	{"AR5014", "Kiser's Home -- Cellar"},
	{"AR5015", "Saradush Militia Entrance"},
	{"AR5016", "Saradush Castle Jail (Kiser Plot)"},
	{"AR5200", "Fire Giant Entrance Area"},
	{"AR5201", "Fire Giant Keep"},
	{"AR5202", "Nyalee's Hideout; Gorion Wraith"},
	{"AR5203", "Yaga-Shura's Camp"},
	{"AR5204", "Yaga-Shura's Keep"},
	{"AR5500", "Amkethran"},
	{"AR5501", "Amkethran Inn"},
	{"AR5502", "Kerrick the Smith's House"},
	{"AR5503", "Chyil's House"},
	{"AR5504", "Smuggler Cave"},
	{"AR5505", "Balthazar's Home"},
	{"AR5506", "Commoner's Home"},
	{"AR5507", "Empty Home"},
	{"AR5508", "Faheed's Home"},
	{"AR5509", "Amkethran Crypt"},
	{"AR6000", "Abazigal's Entrance"},
	{"AR6001", "Abazigal's Lair Entrance Hall"},
	{"AR6002", "Abazigal's Lair -- Cells"},
	{"AR6003", "Abazigal's Lair -- Iycanth the Mad, Bondari"},
	{"AR6004", "Abazigal's Lair -- Fll'Yissetat"},
	{"AR6005", "Abazigal's Hideout"},
	{"AR6008", "Frost Salamander Cave"},
	{"AR6011", "Orbs and Gauth"},
	{"AR6012", "Pool Home -- breath under water"},
	{"AR6100", "Area outside Sendai's Hideout"},
	{"AR6101", "Main Entrance Sendai's Lair"},
	{"AR6102", "Sendai's Lair -- Slavemaster"},
	{"AR6103", "Sendai's Lair -- Spiders"},
	{"AR6104", "Sendai's Lair -- Crossway"},
	{"AR6105", "Sendai's Lair -- Diaytha, Abishai"},
	{"AR6106", "Sendai's Lair -- Captain Egeissag"},
	{"AR6107", "Sendai's Lair -- Mithykyl"},
	{"AR6108", "Sendai's Lair -- Sendai"},
	{"AR6109", "Sendai's Lair -- Drow"},
	{"AR6110", "Sendai's Lair -- Odamaron"},
	{"AR6111", "Woodcutter's House -- Sendai's Area"},
	{"AR6200", "The Throne of Bhaal"},
	{"AR6300", "Oasis in Tethyr"},
	{"AR6400", "River Area"},
	{"OH4200", "Rasaad - Dwarven Clanhold Exterior"},
	{"OH4210", "Rasaad - Dwarven Clanhold Interior"},
	{"OH4220", "Rasaad - Dwarven Mines"},
	{"OH4230", "Rasaad - Plane of Shadow"},
	{"OH4290", "Rasaad - Sharran Ambush"},
	{"OH5400", "Dorn - Forest Clearing"},
	{"OH5500", "Dorn - Lunia"},
	{"OH6400", "Neera - Wilderness Clearing"},
	{"OH6450", "Neera - The Black Pits: Arena"},
	{"OH6460", "Neera - The Black Pits: Staging Area"},
	{"OH6500", "Neera - Thayan Estate"},
	{"OH7300", "Hexxat - Completed Maze (Korkorran)"},
	{"OH7310", "Hexxat - Scene with L"},
}
fontcolors = {}
-- AABBGGRR
fontcolors['1'] = 'FFCAE2E9' -- title
fontcolors['2'] = 'FFCAE2E9' -- title highlight
fontcolors['3'] = 'FFCAE2E9' -- subtitle
fontcolors['4'] = 'FFEEFFFF' -- subtitle highlight
fontcolors['5'] = 'FF000000' -- parchment
fontcolors['6'] = 'FFEEFFFF' -- parchment highlight
fontcolors['7'] = 'FF000000' -- alternate parchment
fontcolors['8'] = 'FF102526' -- alternate parchment highlight
fontcolors['9'] = 'FFCDD6D9' -- semitrans dark background
fontcolors['A'] = 'FFFDE6E9' -- semitrans dark background highlight
fontcolors['B'] = 'FFCECECE'
fontcolors['C'] = 'FFC8F0C8' -- Minty update color
fontcolors['D'] = 'FF96C8FF' -- orangy subtitle color
fontcolors['R'] = 'FF0000FF' -- red
fontcolors['G'] = 'FF00FF00' -- green
fontcolors['M'] = 'FF000080' -- parchment red
fontcolors['$'] = 'FF82E6FF' -- gold yellow/orange

characters = {}

tempStats = {}

styles =
{
	gamelog =
	{
		color = 'B',
		font = 'POSTANTI',
		point = 12,
		useFontZoom = 1,
		valign = 'top',
		halign = 'left',
	},
	normal =
	{
		color = 'B',
		font = 'NORMAL',
		point = 12,
		valign = 'top',
		halign = 'left',
    useFontZoom = 1,
	},
	normal_parchment =
	{
		color = '5',
		font = 'NORMAL',
		point = 12,
		valign = 'top',
		halign = 'left',
    useFontZoom = 1,
	},
	title =
	{
		color = '1',
		font = 'REALMS',
		point = 16,
		valign = 'center',
		halign = 'center',
    useFontZoom = 0,
	},
	parchment = 
	{
		color = '5',
		font = 'NORMAL' ,
		point = 12,
		valign = 'top',
		halign = 'left',
    useFontZoom = 1,
	},
	button =
	{
		color = 'B',
		font = 'STONESML' ,
		point = 10,
		valign = 'center',
		halign = 'center',
		upper = 1,
		pad = {8,8,8,8},
    useFontZoom = 0,
	},
	label =
	{
		color = 'B',
		font = 'STONESML',
		point = 12,
		valign = 'center',
		halign = 'center',
    useFontZoom = 0,
	},
	label_parchment =
	{
		color = '5',
		font = 'STONESML',
		point = 12,
		valign = 'center',
		halign = 'center',
    useFontZoom = 0,
	},
	button_parchment =
	{
		color = '5',
		font = 'MODESTOM',
		point = 12,
		valign = 'center',
		halign = 'center',
		pad = {0,5,0,0},
    useFontZoom = 0,
	},
	edit =
	{
		color = 'B',
		font = 'NORMAL',
		point = 12,
		valign = 'top',
		halign = 'left',
    useFontZoom = 1,
	},
	edit_parchment =
	{
		color = '5',
		font = 'NORMAL',
		point = 12,
		valign = 'top',
		halign = 'left',
    useFontZoom = 1,
	},
	list =
	{
		color = 'B',
		font = 'STONESML',
		point = 12,
		valign = 'center',
		halign = 'left',
    useFontZoom = 0,
	},
	list_parchment =
	{
		color = '5',
		font = 'STONESML',
		point = 12,
		valign = 'center',
		halign = 'left',
    useFontZoom = 0,
	},
	gold =
	{
		color = '$',
		font = 'NORMAL',
		point = 12,
		valign = 'center',
		halign = 'center',
    useFontZoom = 0,
	}
}

chapterBackgrounds = {}
chapterBackgrounds[0] = "GUICHP0B"
chapterBackgrounds[1] = "GUICHP1B"
chapterBackgrounds[2] = "GUICHP2B"
chapterBackgrounds[3] = "GUICHP3B"
chapterBackgrounds[4] = "GUICHP4B"
chapterBackgrounds[5] = "GUICHP5B"
chapterBackgrounds[6] = "GUICHP6B"
chapterBackgrounds[7] = "GUICHP7B"
chapterBackgrounds[8] = "GUICHP8B"
chapterBackgrounds[9] = "GUICHP9B"
chapterBackgrounds[10] = "GUICHP10B"
chapterBackgrounds[11] = "GUICHP11B"
chapterBackgrounds[12] = "GUICHP12B"
chapterBackgrounds[13] = "GUICHP13B"

chapterBackgrounds[52] = "GUIDRM2"
chapterBackgrounds[53] = "GUIDRM3"
chapterBackgrounds[54] = "GUIDRM4"
chapterBackgrounds[55] = "GUIDRM5"
chapterBackgrounds[56] = "GUIDRM6"
chapterBackgrounds[57] = "GUIDRM7"
chapterBackgrounds[58] = "GUIDRM7"

chapterBackgrounds[100] = "GUICHP6B"

const =
{
	ENTRY_TYPE_NONE = -1,
	ENTRY_TYPE_USER = 0,
	ENTRY_TYPE_INPROGRESS = 1,
	ENTRY_TYPE_COMPLETE = 2,
	ENTRY_TYPE_INFO = 4,
	
	ENTRIES_IDX_STRREF = 1,
	ENTRIES_IDX_QUEST = 2,
	ENTRIES_IDX_STATE = 3,
	ENTRIES_IDX_SUBGROUP = 4,
	ENTRIES_IDX_TIMESTAMP = 5,
	ENTRIES_IDX_RECV = 6,
	
	JOURNAL_STATE_USER  = 0,
	JOURNAL_STATE_INPROGRESS = 1,
	JOURNAL_STATE_COMPLETE = 2,
	JOURNAL_STATE_INFO = 4,
	
	QUEST_IDX_ID = 1,
	QUEST_IDX_STRREF = 3,
	QUEST_IDX_STATE = 5,
	QUEST_IDX_CHAPTER = 6,
	QUEST_IDX_RECV = 7,
	
	USER_IDX_STRREF = 1,
	USER_IDX_TIMESTAMP = 2,
	USER_IDX_STATE = 3,
	USER_IDX_CHAPTER = 4,
	USER_IDX_RECV = 5,
	
	INFO_IDX_STRREF = 1,
	INFO_IDX_TIMESTAMP = 2,
	INFO_IDX_STATE = 3,
	INFO_IDX_CHAPTER = 4,
	INFO_IDX_RECV = 5,
	
	IDX_IMPORTANT = 1,
		
	STEP_DUALCLASS_CLASS = 24,
	STEP_DUALCLASS_PROFICIENCIES = 25,
	STEP_DUALCLASS_DONE = 27,
	
	CUSTOMIZE_ID = 17,
	SCRIPT_ID = 11,
	EXPORT_ID = 13,
	SOUND_ID = 20,
	
	JOURNAL_MODE_QUESTS = 1,
	JOURNAL_MODE_JOURNAL = 2,
	JOURNAL_MODE_EDIT = 3,
}

function buildQuestsTable()
	Infinity_Log("Initializing Quests")
	quests = {}
	userNotes = {}
	looseEntries = {}
	subGroups = {}
	createQuest    ( 74295 )
	createEntry    ( 74295, -1, 96383, {}, nil )
	createEntry    ( 74295, -1, 96384, {}, nil )
	createEntry    ( 74295, -1, 96385, {}, nil )
	createEntry    ( 74295, -1, 96386, {}, nil )
	createEntry    ( 74295, -1, 96387, {}, nil )
	createEntry    ( 74295, -1, 96388, {}, nil )
	createEntry    ( 74295, -1, 96389, {}, nil )
	createEntry    ( 74295, -1, 96391, {}, nil )
	createEntry    ( 74295, -1, 96390, {}, nil )
	createEntry    ( 74295, -1, 96392, {}, nil )
	createEntry    ( 74295, -1, 96393, {}, nil )
	createEntry    ( 74295, -1, 96422, {}, nil )
	createEntry    ( 74295, -1, 96437, {}, nil )
	createEntry    ( 74295, -1, 96469, {}, nil )
	createEntry    ( 74295, -1, 96521, {}, nil )
	createEntry    ( 74295, -1, 96522, {}, nil )
	createEntry    ( 74295, -1, 96528, {}, nil )
	createEntry    ( 74295, -1, 96554, {}, nil )
	createEntry    ( 74295, -1, 96562, {}, nil )
	createEntry    ( 74295, -1, 96563, {}, nil )
	createEntry    ( 74295, -1, 96576, {}, nil )
	createEntry    ( 74295, -1, 96586, {}, nil )
	createEntry    ( 74295, -1, 96636, {}, nil )
	createEntry    ( 74295, -1, 96637, {}, nil )
	createEntry    ( 74295, -1, 96642, {}, nil )
	createEntry    ( 74295, -1, 96648, {}, nil )
	createEntry    ( 74295, -1, 96650, {}, nil )
	createEntry    ( 74295, -1, 96655, {}, nil )
	createEntry    ( 74295, -1, 96656, {}, nil )
	createEntry    ( 74295, -1, 96686, {}, nil )
	createEntry    ( 74295, -1, 96687, {}, nil )
	createEntry    ( 74295, -1, 96688, {}, nil )
	createEntry    ( 74295, -1, 97314, {}, nil )
	createEntry    ( 74295, -1, 97315, {}, nil )
	createEntry    ( 74295, -1, 97316, {}, nil )
	createEntry    ( 74295, -1, 97317, {}, nil )
	createEntry    ( 74295, -1, 97318, {}, nil )
	createEntry    ( 74295, -1, 97319, {}, nil )
	createEntry    ( 74295, -1, 97320, {}, nil )
	createEntry    ( 74295, -1, 97322, {}, nil )
	createEntry    ( 74295, -1, 97325, {}, nil )
	createEntry    ( 74295, -1, 97326, {}, nil )
	createEntry    ( 74295, -1, 97327, {}, nil )
	createEntry    ( 74295, -1, 97328, {}, nil )
	createEntry    ( 74295, -1, 97329, {}, nil )
	createEntry    ( 74295, -1, 97330, {}, nil )
	createEntry    ( 74295, -1, 97331, {}, nil )
	createEntry    ( 74295, -1, 97332, {}, nil )
	createEntry    ( 74295, -1, 97333, {}, nil )
	createEntry    ( 74295, -1, 97334, {}, nil )
	createEntry    ( 74295, -1, 97335, {}, nil )
	createEntry    ( 74295, -1, 97336, {}, nil )
	createEntry    ( 74295, -1, 97337, {}, nil )
	createEntry    ( 74295, -1, 97338, {}, nil )
	createEntry    ( 74295, -1, 97339, {}, nil )
	createEntry    ( 74295, -1, 97341, {}, nil )
	createEntry    ( 74295, -1, 97340, {}, nil )
	createEntry    ( 74295, -1, 97342, {}, nil )
	createEntry    ( 74295, -1, 97343, {}, nil )
	createEntry    ( 74295, -1, 97344, {}, nil )
	createEntry    ( 74295, -1, 97345, {}, nil )
	createEntry    ( 74295, -1, 97346, {}, nil )
	createEntry    ( 74295, -1, 97347, {}, nil )
	createEntry    ( 74295, -1, 97348, {}, nil )
	createEntry    ( 74295, -1, 97349, {}, nil )
	createEntry    ( 74295, -1, 97350, {}, nil )
	createEntry    ( 74295, -1, 97351, {}, nil )
	createEntry    ( 74295, -1, 97352, {}, nil )
	createEntry    ( 74295, -1, 97353, {}, nil )
	createEntry    ( 74295, -1, 97354, {}, nil )
	createEntry    ( 74295, -1, 97355, {}, nil )
	createEntry    ( 74295, -1, 97356, {}, nil )
	createEntry    ( 74295, -1, 97357, {}, nil )
	createEntry    ( 74295, -1, 97358, {}, nil )
	createQuest    ( 74318 )
	createEntry    ( 74318, -1, 293, {}, nil )
	createQuest    ( 16202 )
	createEntry    ( 16202, -1, 465, {}, nil )
	createEntry    ( 16202, -1, 61973, {}, nil )
	createQuest    ( 74319 )
	createEntry    ( 74319, -1, 843, {}, nil )
	createQuest    ( 74320 )
	createEntry    ( 74320, -1, 1340, {}, nil )
	createEntry    ( 74320, -1, 1349, {}, nil )
	createEntry    ( 74320, -1, 1363, {}, nil )
	createEntry    ( 74320, -1, 4751, {}, nil )
	createEntry    ( 74320, -1, 4833, {}, nil )
	createEntry    ( 74320, -1, 4834, {}, nil )
	createEntry    ( 74320, -1, 4836, {}, nil )
	createEntry    ( 74320, -1, 10626, {}, nil )
	createEntry    ( 74320, -1, 47970, {}, nil )
	createEntry    ( 74320, -1, 47971, {}, nil )
	createEntry    ( 74320, -1, 47972, {}, nil )
	createQuest    ( 74321 )
	createEntry    ( 74321, -1, 2025, {}, nil )
	createEntry    ( 74321, -1, 2028, {}, nil )
	createEntry    ( 74321, -1, 2065, {}, nil )
	createEntry    ( 74321, -1, 2069, {}, nil )
	createEntry    ( 74321, -1, 30375, {}, nil )
	createEntry    ( 74321, -1, 34387, {}, nil )
	createEntry    ( 74321, -1, 34388, {}, nil )
	createEntry    ( 74321, -1, 34391, {}, nil )
	createEntry    ( 74321, -1, 34399, {}, nil )
	createEntry    ( 74321, -1, 34407, {}, nil )
	createEntry    ( 74321, -1, 34413, {}, nil )
	createEntry    ( 74321, -1, 34416, {}, nil )
	createEntry    ( 74321, -1, 34417, {}, nil )
	createEntry    ( 74321, -1, 34418, {}, nil )
	createEntry    ( 74321, -1, 34419, {}, nil )
	createEntry    ( 74321, -1, 34420, {}, nil )
	createEntry    ( 74321, -1, 34422, {}, nil )
	createEntry    ( 74321, -1, 47712, {}, nil )
	createQuest    ( 74322 )
	createEntry    ( 74322, -1, 2051, {}, nil )
	createEntry    ( 74322, -1, 2070, {}, nil )
	createEntry    ( 74322, -1, 2073, {}, nil )
	createEntry    ( 74322, -1, 2076, {}, nil )
	createEntry    ( 74322, -1, 2080, {}, nil )
	createEntry    ( 74322, -1, 2081, {}, nil )
	createEntry    ( 74322, -1, 2082, {}, nil )
	createEntry    ( 74322, -1, 2083, {}, nil )
	createEntry    ( 74322, -1, 2088, {}, nil )
	createEntry    ( 74322, -1, 47721, {}, nil )
	createEntry    ( 74322, -1, 47723, {}, nil )
	createEntry    ( 74322, -1, 61261, {}, nil )
	createEntry    ( 74322, -1, 61262, {}, nil )
	createQuest    ( 74323 )
	createEntry    ( 74323, -1, 2052, {}, nil )
	createQuest    ( 74324 )
	createEntry    ( 74324, -1, 2057, {}, nil )
	createEntry    ( 74324, -1, 2060, {}, nil )
	createEntry    ( 74324, -1, 2061, {}, nil )
	createEntry    ( 74324, -1, 47736, {}, nil )
	createEntry    ( 74324, -1, 47737, {}, nil )
	createQuest    ( 74325 )
	createEntry    ( 74325, -1, 2071, {}, nil )
	createEntry    ( 74325, -1, 2072, {}, nil )
	createEntry    ( 74325, -1, 2074, {}, nil )
	createEntry    ( 74325, -1, 2075, {}, nil )
	createEntry    ( 74325, -1, 2077, {}, nil )
	createEntry    ( 74325, -1, 2079, {}, nil )
	createEntry    ( 74325, -1, 46838, {}, nil )
	createEntry    ( 74325, -1, 47726, {}, nil )
	createEntry    ( 74325, -1, 47735, {}, nil )
	createEntry    ( 74325, -1, 61915, {}, nil )
	createQuest    ( 74326 )
	createEntry    ( 74326, -1, 2097, {}, nil )
	createEntry    ( 74326, -1, 2098, {}, nil )
	createEntry    ( 74326, -1, 2099, {}, nil )
	createEntry    ( 74326, -1, 2119, {}, nil )
	createEntry    ( 74326, -1, 5828, {}, nil )
	createEntry    ( 74326, -1, 6607, {}, nil )
	createEntry    ( 74326, -1, 7169, {}, nil )
	createEntry    ( 74326, -1, 7240, {}, nil )
	createEntry    ( 74326, -1, 7738, {}, nil )
	createEntry    ( 74326, -1, 9704, {}, nil )
	createEntry    ( 74326, -1, 9932, {}, nil )
	createEntry    ( 74326, -1, 10102, {}, nil )
	createEntry    ( 74326, -1, 15722, {}, nil )
	createEntry    ( 74326, -1, 15723, {}, nil )
	createEntry    ( 74326, -1, 15727, {}, nil )
	createEntry    ( 74326, -1, 20256, {}, nil )
	createEntry    ( 74326, -1, 22949, {}, nil )
	createEntry    ( 74326, -1, 32002, {}, nil )
	createEntry    ( 74326, -1, 34497, {}, nil )
	createEntry    ( 74326, -1, 61267, {}, nil )
	createQuest    ( 74327 )
	createEntry    ( 74327, -1, 2118, {}, nil )
	createEntry    ( 74327, -1, 19272, {}, nil )
	createQuest    ( 74328 )
	createEntry    ( 74328, -1, 2147, {}, nil )
	createEntry    ( 74328, -1, 34144, {}, nil )
	createEntry    ( 74328, -1, 34168, {}, nil )
	createEntry    ( 74328, -1, 34172, {}, nil )
	createEntry    ( 74328, -1, 34182, {}, nil )
	createEntry    ( 74328, -1, 47536, {}, nil )
	createQuest    ( 74329 )
	createEntry    ( 74329, -1, 2319, {}, nil )
	createEntry    ( 74329, -1, 2320, {}, nil )
	createEntry    ( 74329, -1, 2321, {}, nil )
	createEntry    ( 74329, -1, 6609, {}, nil )
	createEntry    ( 74329, -1, 9976, {}, nil )
	createEntry    ( 74329, -1, 9977, {}, nil )
	createEntry    ( 74329, -1, 15721, {}, nil )
	createEntry    ( 74329, -1, 15743, {}, nil )
	createEntry    ( 74329, -1, 23550, {}, nil )
	createQuest    ( 74330 )
	createEntry    ( 74330, -1, 2939, {}, nil )
	createEntry    ( 74330, -1, 2940, {}, nil )
	createEntry    ( 74330, -1, 2957, {}, nil )
	createEntry    ( 74330, -1, 2965, {}, nil )
	createEntry    ( 74330, -1, 2966, {}, nil )
	createEntry    ( 74330, -1, 2967, {}, nil )
	createEntry    ( 74330, -1, 2971, {}, nil )
	createEntry    ( 74330, -1, 2972, {}, nil )
	createEntry    ( 74330, -1, 2973, {}, nil )
	createEntry    ( 74330, -1, 2974, {}, nil )
	createEntry    ( 74330, -1, 2975, {}, nil )
	createEntry    ( 74330, -1, 2993, {}, nil )
	createEntry    ( 74330, -1, 2996, {}, nil )
	createEntry    ( 74330, -1, 3013, {}, nil )
	createEntry    ( 74330, -1, 3017, {}, nil )
	createEntry    ( 74330, -1, 3024, {}, nil )
	createEntry    ( 74330, -1, 3027, {}, nil )
	createEntry    ( 74330, -1, 3028, {}, nil )
	createEntry    ( 74330, -1, 3029, {}, nil )
	createQuest    ( 74331 )
	createEntry    ( 74331, -1, 3030, {}, nil )
	createEntry    ( 74331, -1, 3031, {}, nil )
	createEntry    ( 74331, -1, 3032, {}, nil )
	createEntry    ( 74331, -1, 3033, {}, nil )
	createEntry    ( 74331, -1, 3034, {}, nil )
	createEntry    ( 74331, -1, 3036, {}, nil )
	createEntry    ( 74331, -1, 3039, {}, nil )
	createQuest    ( 74332 )
	createEntry    ( 74332, -1, 3040, {}, nil )
	createQuest    ( 74333 )
	createEntry    ( 74333, -1, 3296, {}, nil )
	createQuest    ( 74334 )
	createEntry    ( 74334, -1, 3301, {}, nil )
	createEntry    ( 74334, -1, 3303, {}, nil )
	createQuest    ( 74335 )
	createEntry    ( 74335, -1, 3304, {}, nil )
	createQuest    ( 74336 )
	createEntry    ( 74336, -1, 3361, {}, nil )
	createEntry    ( 74336, -1, 3362, {}, nil )
	createEntry    ( 74336, -1, 5059, {}, nil )
	createEntry    ( 74336, -1, 6934, {}, nil )
	createEntry    ( 74336, -1, 7235, {}, nil )
	createEntry    ( 74336, -1, 9982, {}, nil )
	createEntry    ( 74336, -1, 10106, {}, nil )
	createEntry    ( 74336, -1, 10107, {}, nil )
	createEntry    ( 74336, -1, 10670, {}, nil )
	createEntry    ( 74336, -1, 10671, {}, nil )
	createEntry    ( 74336, -1, 10933, {}, nil )
	createEntry    ( 74336, -1, 11645, {}, nil )
	createEntry    ( 74336, -1, 11661, {}, nil )
	createEntry    ( 74336, -1, 11681, {}, nil )
	createEntry    ( 74336, -1, 11686, {}, nil )
	createEntry    ( 74336, -1, 11689, {}, nil )
	createEntry    ( 74336, -1, 11755, {}, nil )
	createEntry    ( 74336, -1, 11884, {}, nil )
	createEntry    ( 74336, -1, 11904, {}, nil )
	createEntry    ( 74336, -1, 15698, {}, nil )
	createEntry    ( 74336, -1, 15703, {}, nil )
	createEntry    ( 74336, -1, 15715, {}, nil )
	createEntry    ( 74336, -1, 15760, {}, nil )
	createEntry    ( 74336, -1, 15783, {}, nil )
	createEntry    ( 74336, -1, 15794, {}, nil )
	createEntry    ( 74336, -1, 15801, {}, nil )
	createEntry    ( 74336, -1, 16541, {}, nil )
	createEntry    ( 74336, -1, 16558, {}, nil )
	createEntry    ( 74336, -1, 16677, {}, nil )
	createEntry    ( 74336, -1, 19364, {}, nil )
	createEntry    ( 74336, -1, 20367, {}, nil )
	createEntry    ( 74336, -1, 23504, {}, nil )
	createEntry    ( 74336, -1, 23512, {}, nil )
	createEntry    ( 74336, -1, 23521, {}, nil )
	createEntry    ( 74336, -1, 23530, {}, nil )
	createQuest    ( 74337 )
	createEntry    ( 74337, -1, 3374, {}, nil )
	createEntry    ( 74337, -1, 3377, {}, nil )
	createEntry    ( 74337, -1, 3716, {}, nil )
	createEntry    ( 74337, -1, 3927, {}, nil )
	createEntry    ( 74337, -1, 5814, {}, nil )
	createEntry    ( 74337, -1, 6542, {}, nil )
	createEntry    ( 74337, -1, 6555, {}, nil )
	createEntry    ( 74337, -1, 6589, {}, nil )
	createEntry    ( 74337, -1, 7002, {}, nil )
	createEntry    ( 74337, -1, 7122, {}, nil )
	createEntry    ( 74337, -1, 7243, {}, nil )
	createEntry    ( 74337, -1, 11864, {}, nil )
	createEntry    ( 74337, -1, 15710, {}, nil )
	createEntry    ( 74337, -1, 16331, {}, nil )
	createEntry    ( 74337, -1, 16351, {}, nil )
	createEntry    ( 74337, -1, 20214, {}, nil )
	createEntry    ( 74337, -1, 22924, {}, nil )
	createEntry    ( 74337, -1, 32084, {}, nil )
	createEntry    ( 74337, -1, 32085, {}, nil )
	createQuest    ( 74338 )
	createEntry    ( 74338, -1, 3422, {}, nil )
	createEntry    ( 74338, -1, 6557, {}, nil )
	createEntry    ( 74338, -1, 7241, {}, nil )
	createEntry    ( 74338, -1, 9705, {}, nil )
	createEntry    ( 74338, -1, 9919, {}, nil )
	createEntry    ( 74338, -1, 10047, {}, nil )
	createEntry    ( 74338, -1, 23551, {}, nil )
	createQuest    ( 74339 )
	createEntry    ( 74339, -1, 3654, {}, nil )
	createEntry    ( 74339, -1, 15693, {}, nil )
	createEntry    ( 74339, -1, 15714, {}, nil )
	createQuest    ( 74340 )
	createEntry    ( 74340, -1, 3680, {}, nil )
	createEntry    ( 74340, -1, 5823, {}, nil )
	createEntry    ( 74340, -1, 6467, {}, nil )
	createEntry    ( 74340, -1, 6587, {}, nil )
	createEntry    ( 74340, -1, 7170, {}, nil )
	createEntry    ( 74340, -1, 7684, {}, nil )
	createEntry    ( 74340, -1, 10109, {}, nil )
	createEntry    ( 74340, -1, 10116, {}, nil )
	createEntry    ( 74340, -1, 10929, {}, nil )
	createEntry    ( 74340, -1, 10931, {}, nil )
	createEntry    ( 74340, -1, 10936, {}, nil )
	createEntry    ( 74340, -1, 15809, {}, nil )
	createEntry    ( 74340, -1, 16669, {}, nil )
	createEntry    ( 74340, -1, 19432, {}, nil )
	createEntry    ( 74340, -1, 22948, {}, nil )
	createEntry    ( 74340, -1, 55580, {}, nil )
	createQuest    ( 74341 )
	createEntry    ( 74341, -1, 4323, {}, nil )
	createEntry    ( 74341, -1, 16543, {}, nil )
	createEntry    ( 74341, -1, 23447, {}, nil )
	createQuest    ( 74342 )
	createEntry    ( 74342, -1, 4352, {}, nil )
	createEntry    ( 74342, -1, 5017, {}, nil )
	createEntry    ( 74342, -1, 5742, {}, nil )
	createEntry    ( 74342, -1, 6330, {}, nil )
	createEntry    ( 74342, -1, 6426, {}, nil )
	createEntry    ( 74342, -1, 6427, {}, nil )
	createEntry    ( 74342, -1, 6436, {}, nil )
	createEntry    ( 74342, -1, 6437, {}, nil )
	createEntry    ( 74342, -1, 6438, {}, nil )
	createEntry    ( 74342, -1, 6443, {}, nil )
	createEntry    ( 74342, -1, 6945, {}, nil )
	createEntry    ( 74342, -1, 9738, {}, nil )
	createEntry    ( 74342, -1, 9980, {}, nil )
	createEntry    ( 74342, -1, 10250, {}, nil )
	createEntry    ( 74342, -1, 15713, {}, nil )
	createEntry    ( 74342, -1, 16557, {}, nil )
	createEntry    ( 74342, -1, 16671, {}, nil )
	createEntry    ( 74342, -1, 23346, {}, nil )
	createEntry    ( 74342, -1, 23503, {}, nil )
	createEntry    ( 74342, -1, 23537, {}, nil )
	createEntry    ( 74342, -1, 23557, {}, nil )
	createEntry    ( 74342, -1, 46841, {}, nil )
	createQuest    ( 74343 )
	createEntry    ( 74343, -1, 4354, {}, nil )
	createEntry    ( 74343, -1, 5802, {}, nil )
	createEntry    ( 74343, -1, 7045, {}, nil )
	createEntry    ( 74343, -1, 7701, {}, nil )
	createEntry    ( 74343, -1, 10140, {}, nil )
	createEntry    ( 74343, -1, 15719, {}, nil )
	createEntry    ( 74343, -1, 15720, {}, nil )
	createEntry    ( 74343, -1, 22934, {}, nil )
	createEntry    ( 74343, -1, 23404, {}, nil )
	createEntry    ( 74343, -1, 23523, {}, nil )
	createEntry    ( 74343, -1, 62156, {}, nil )
	createEntry    ( 74343, -1, 62157, {}, nil )
	createQuest    ( 74344 )
	createEntry    ( 74344, -1, 4659, {}, nil )
	createEntry    ( 74344, -1, 4661, {}, nil )
	createEntry    ( 74344, -1, 4662, {}, nil )
	createEntry    ( 74344, -1, 46843, {}, nil )
	createQuest    ( 74345 )
	createEntry    ( 74345, -1, 4660, {}, nil )
	createEntry    ( 74345, -1, 46844, {}, nil )
	createEntry    ( 74345, -1, 61115, {}, nil )
	createQuest    ( 74346 )
	createEntry    ( 74346, -1, 4679, {}, nil )
	createEntry    ( 74346, -1, 4680, {}, nil )
	createEntry    ( 74346, -1, 46845, {}, nil )
	createQuest    ( 74347 )
	createEntry    ( 74347, -1, 4685, {}, nil )
	createEntry    ( 74347, -1, 46846, {}, nil )
	createEntry    ( 74347, -1, 46847, {}, nil )
	createEntry    ( 74347, -1, 46848, {}, nil )
	createEntry    ( 74347, -1, 46849, {}, nil )
	createEntry    ( 74347, -1, 46850, {}, nil )
	createEntry    ( 74347, -1, 46851, {}, nil )
	createEntry    ( 74347, -1, 47761, {}, nil )
	createQuest    ( 74348 )
	createEntry    ( 74348, -1, 4838, {}, nil )
	createEntry    ( 74348, -1, 4840, {}, nil )
	createEntry    ( 74348, -1, 4841, {}, nil )
	createEntry    ( 74348, -1, 47980, {}, nil )
	createEntry    ( 74348, -1, 47981, {}, nil )
	createEntry    ( 74348, -1, 47982, {}, nil )
	createQuest    ( 74349 )
	createEntry    ( 74349, -1, 4997, {}, nil )
	createEntry    ( 74349, -1, 7686, {}, nil )
	createEntry    ( 74349, -1, 15779, {}, nil )
	createEntry    ( 74349, -1, 16531, {}, nil )
	createEntry    ( 74349, -1, 34657, {}, nil )
	createEntry    ( 74349, -1, 34658, {}, nil )
	createEntry    ( 74349, -1, 34659, {}, nil )
	createQuest    ( 74350 )
	createEntry    ( 74350, -1, 5014, {}, nil )
	createEntry    ( 74350, -1, 7242, {}, nil )
	createEntry    ( 74350, -1, 23225, {}, nil )
	createQuest    ( 74351 )
	createEntry    ( 74351, -1, 5083, {}, nil )
	createEntry    ( 74351, -1, 5825, {}, nil )
	createEntry    ( 74351, -1, 6549, {}, nil )
	createEntry    ( 74351, -1, 6576, {}, nil )
	createEntry    ( 74351, -1, 7025, {}, nil )
	createEntry    ( 74351, -1, 7079, {}, nil )
	createEntry    ( 74351, -1, 7262, {}, nil )
	createEntry    ( 74351, -1, 9920, {}, nil )
	createEntry    ( 74351, -1, 10073, {}, nil )
	createEntry    ( 74351, -1, 10074, {}, nil )
	createEntry    ( 74351, -1, 11648, {}, nil )
	createEntry    ( 74351, -1, 16002, {}, nil )
	createEntry    ( 74351, -1, 16336, {}, nil )
	createEntry    ( 74351, -1, 16354, {}, nil )
	createEntry    ( 74351, -1, 16542, {}, nil )
	createEntry    ( 74351, -1, 20986, {}, nil )
	createEntry    ( 74351, -1, 23395, {}, nil )
	createEntry    ( 74351, -1, 23489, {}, nil )
	createEntry    ( 74351, -1, 23491, {}, nil )
	createEntry    ( 74351, -1, 40131, {}, nil )
	createEntry    ( 74351, -1, 42371, {}, nil )
	createEntry    ( 74351, -1, 49487, {}, nil )
	createEntry    ( 74351, -1, 49488, {}, nil )
	createQuest    ( 74352 )
	createEntry    ( 74352, -1, 5696, {}, nil )
	createEntry    ( 74352, -1, 5697, {}, nil )
	createEntry    ( 74352, -1, 5698, {}, nil )
	createEntry    ( 74352, -1, 5699, {}, nil )
	createEntry    ( 74352, -1, 5700, {}, nil )
	createQuest    ( 74353 )
	createEntry    ( 74353, -1, 5743, {}, nil )
	createEntry    ( 74353, -1, 23513, {}, nil )
	createQuest    ( 74354 )
	createEntry    ( 74354, -1, 5775, {}, nil )
	createEntry    ( 74354, -1, 5776, {}, nil )
	createEntry    ( 74354, -1, 5824, {}, nil )
	createEntry    ( 74354, -1, 7040, {}, nil )
	createEntry    ( 74354, -1, 7747, {}, nil )
	createEntry    ( 74354, -1, 10004, {}, nil )
	createEntry    ( 74354, -1, 10005, {}, nil )
	createEntry    ( 74354, -1, 10124, {}, nil )
	createEntry    ( 74354, -1, 15706, {}, nil )
	createEntry    ( 74354, -1, 15747, {}, nil )
	createEntry    ( 74354, -1, 16316, {}, nil )
	createEntry    ( 74354, -1, 16329, {}, nil )
	createEntry    ( 74354, -1, 16570, {}, nil )
	createEntry    ( 74354, -1, 16571, {}, nil )
	createEntry    ( 74354, -1, 16572, {}, nil )
	createEntry    ( 74354, -1, 16573, {}, nil )
	createEntry    ( 74354, -1, 46852, {}, nil )
	createEntry    ( 74354, -1, 46853, {}, nil )
	createEntry    ( 74354, -1, 46854, {}, nil )
	createEntry    ( 74354, -1, 46855, {}, nil )
	createEntry    ( 74354, -1, 46856, {}, nil )
	createEntry    ( 74354, -1, 46857, {}, nil )
	createQuest    ( 74355 )
	createEntry    ( 74355, -1, 5810, {}, nil )
	createEntry    ( 74355, -1, 6403, {}, nil )
	createEntry    ( 74355, -1, 6405, {}, nil )
	createEntry    ( 74355, -1, 6535, {}, nil )
	createEntry    ( 74355, -1, 6545, {}, nil )
	createEntry    ( 74355, -1, 6582, {}, nil )
	createEntry    ( 74355, -1, 6590, {}, nil )
	createEntry    ( 74355, -1, 6943, {}, nil )
	createEntry    ( 74355, -1, 6954, {}, nil )
	createEntry    ( 74355, -1, 6999, {}, nil )
	createEntry    ( 74355, -1, 7001, {}, nil )
	createEntry    ( 74355, -1, 7147, {}, nil )
	createEntry    ( 74355, -1, 7148, {}, nil )
	createEntry    ( 74355, -1, 9649, {}, nil )
	createEntry    ( 74355, -1, 10104, {}, nil )
	createEntry    ( 74355, -1, 15792, {}, nil )
	createEntry    ( 74355, -1, 15793, {}, nil )
	createEntry    ( 74355, -1, 16339, {}, nil )
	createEntry    ( 74355, -1, 16529, {}, nil )
	createEntry    ( 74355, -1, 16668, {}, nil )
	createEntry    ( 74355, -1, 22931, {}, nil )
	createEntry    ( 74355, -1, 23424, {}, nil )
	createQuest    ( 74356 )
	createEntry    ( 74356, -1, 5811, {}, nil )
	createEntry    ( 74356, -1, 5831, {}, nil )
	createEntry    ( 74356, -1, 6538, {}, nil )
	createEntry    ( 74356, -1, 9703, {}, nil )
	createEntry    ( 74356, -1, 11880, {}, nil )
	createEntry    ( 74356, -1, 14924, {}, nil )
	createEntry    ( 74356, -1, 23547, {}, nil )
	createQuest    ( 74357 )
	createEntry    ( 74357, -1, 5812, {}, nil )
	createEntry    ( 74357, -1, 7168, {}, nil )
	createQuest    ( 74358 )
	createEntry    ( 74358, -1, 5819, {}, nil )
	createEntry    ( 74358, -1, 6603, {}, nil )
	createEntry    ( 74358, -1, 6606, {}, nil )
	createEntry    ( 74358, -1, 6613, {}, nil )
	createEntry    ( 74358, -1, 6955, {}, nil )
	createEntry    ( 74358, -1, 6956, {}, nil )
	createEntry    ( 74358, -1, 7012, {}, nil )
	createEntry    ( 74358, -1, 7013, {}, nil )
	createEntry    ( 74358, -1, 7014, {}, nil )
	createEntry    ( 74358, -1, 11546, {}, nil )
	createEntry    ( 74358, -1, 11854, {}, nil )
	createEntry    ( 74358, -1, 16564, {}, nil )
	createEntry    ( 74358, -1, 22930, {}, nil )
	createQuest    ( 74359 )
	createEntry    ( 74359, -1, 5822, {}, nil )
	createEntry    ( 74359, -1, 6556, {}, nil )
	createEntry    ( 74359, -1, 16007, {}, nil )
	createQuest    ( 74360 )
	createEntry    ( 74360, -1, 5826, {}, nil )
	createEntry    ( 74360, -1, 7085, {}, nil )
	createEntry    ( 74360, -1, 7167, {}, nil )
	createEntry    ( 74360, -1, 16548, {}, nil )
	createEntry    ( 74360, -1, 16549, {}, nil )
	createQuest    ( 74361 )
	createEntry    ( 74361, -1, 5827, {}, nil )
	createEntry    ( 74361, -1, 7944, {}, nil )
	createEntry    ( 74361, -1, 9918, {}, nil )
	createEntry    ( 74361, -1, 19286, {}, nil )
	createQuest    ( 74362 )
	createEntry    ( 74362, -1, 5832, {}, nil )
	createEntry    ( 74362, -1, 6933, {}, nil )
	createEntry    ( 74362, -1, 7032, {}, nil )
	createEntry    ( 74362, -1, 7096, {}, nil )
	createEntry    ( 74362, -1, 9978, {}, nil )
	createEntry    ( 74362, -1, 9986, {}, nil )
	createEntry    ( 74362, -1, 11690, {}, nil )
	createEntry    ( 74362, -1, 15725, {}, nil )
	createEntry    ( 74362, -1, 15745, {}, nil )
	createEntry    ( 74362, -1, 15746, {}, nil )
	createEntry    ( 74362, -1, 15787, {}, nil )
	createEntry    ( 74362, -1, 16333, {}, nil )
	createEntry    ( 74362, -1, 19438, {}, nil )
	createEntry    ( 74362, -1, 20170, {}, nil )
	createEntry    ( 74362, -1, 23444, {}, nil )
	createEntry    ( 74362, -1, 23445, {}, nil )
	createEntry    ( 74362, -1, 23485, {}, nil )
	createEntry    ( 74362, -1, 23486, {}, nil )
	createEntry    ( 74362, -1, 23500, {}, nil )
	createEntry    ( 74362, -1, 23519, {}, nil )
	createEntry    ( 74362, -1, 61412, {}, nil )
	createQuest    ( 74363 )
	createEntry    ( 74363, -1, 5833, {}, nil )
	createEntry    ( 74363, -1, 7256, {}, nil )
	createEntry    ( 74363, -1, 11821, {}, nil )
	createEntry    ( 74363, -1, 11872, {}, nil )
	createQuest    ( 74364 )
	createEntry    ( 74364, -1, 6279, {}, nil )
	createEntry    ( 74364, -1, 6496, {}, nil )
	createEntry    ( 74364, -1, 6501, {}, nil )
	createEntry    ( 74364, -1, 6836, {}, nil )
	createEntry    ( 74364, -1, 11883, {}, nil )
	createEntry    ( 74364, -1, 15718, {}, nil )
	createEntry    ( 74364, -1, 15748, {}, nil )
	createEntry    ( 74364, -1, 23446, {}, nil )
	createEntry    ( 74364, -1, 23481, {}, nil )
	createEntry    ( 74364, -1, 23482, {}, nil )
	createEntry    ( 74364, -1, 23506, {}, nil )
	createQuest    ( 74365 )
	createEntry    ( 74365, -1, 6288, {}, nil )
	createQuest    ( 74366 )
	createEntry    ( 74366, -1, 6447, {}, nil )
	createEntry    ( 74366, -1, 6594, {}, nil )
	createEntry    ( 74366, -1, 10127, {}, nil )
	createEntry    ( 74366, -1, 16555, {}, nil )
	createEntry    ( 74366, -1, 23340, {}, nil )
	createEntry    ( 74366, -1, 23492, {}, nil )
	createQuest    ( 74367 )
	createEntry    ( 74367, -1, 6509, {}, nil )
	createEntry    ( 74367, -1, 6534, {}, nil )
	createEntry    ( 74367, -1, 7995, {}, nil )
	createEntry    ( 74367, -1, 8127, {}, nil )
	createEntry    ( 74367, -1, 8128, {}, nil )
	createEntry    ( 74367, -1, 8129, {}, nil )
	createEntry    ( 74367, -1, 10128, {}, nil )
	createEntry    ( 74367, -1, 16302, {}, nil )
	createEntry    ( 74367, -1, 16343, {}, nil )
	createEntry    ( 74367, -1, 16524, {}, nil )
	createEntry    ( 74367, -1, 16544, {}, nil )
	createEntry    ( 74367, -1, 16569, {}, nil )
	createEntry    ( 74367, -1, 20179, {}, nil )
	createEntry    ( 74367, -1, 20365, {}, nil )
	createEntry    ( 74367, -1, 20453, {}, nil )
	createEntry    ( 74367, -1, 23371, {}, nil )
	createEntry    ( 74367, -1, 23409, {}, nil )
	createQuest    ( 74368 )
	createEntry    ( 74368, -1, 6550, {}, nil )
	createEntry    ( 74368, -1, 6592, {}, nil )
	createEntry    ( 74368, -1, 7020, {}, nil )
	createEntry    ( 74368, -1, 7021, {}, nil )
	createEntry    ( 74368, -1, 7264, {}, nil )
	createEntry    ( 74368, -1, 10119, {}, nil )
	createEntry    ( 74368, -1, 10592, {}, nil )
	createEntry    ( 74368, -1, 10620, {}, nil )
	createQuest    ( 74369 )
	createEntry    ( 74369, -1, 6554, {}, nil )
	createEntry    ( 74369, -1, 10010, {}, nil )
	createEntry    ( 74369, -1, 10105, {}, nil )
	createEntry    ( 74369, -1, 15797, {}, nil )
	createEntry    ( 74369, -1, 62079, {}, nil )
	createQuest    ( 74370 )
	createEntry    ( 74370, -1, 6558, {}, nil )
	createQuest    ( 74371 )
	createEntry    ( 74371, -1, 6572, {}, nil )
	createEntry    ( 74371, -1, 6830, {}, nil )
	createEntry    ( 74371, -1, 9998, {}, nil )
	createEntry    ( 74371, -1, 20542, {}, nil )
	createQuest    ( 74372 )
	createEntry    ( 74372, -1, 6583, {}, nil )
	createEntry    ( 74372, -1, 6584, {}, nil )
	createEntry    ( 74372, -1, 6585, {}, nil )
	createEntry    ( 74372, -1, 10103, {}, nil )
	createEntry    ( 74372, -1, 10125, {}, nil )
	createEntry    ( 74372, -1, 11775, {}, nil )
	createEntry    ( 74372, -1, 16335, {}, nil )
	createEntry    ( 74372, -1, 23341, {}, nil )
	createQuest    ( 74373 )
	createEntry    ( 74373, -1, 6597, {}, nil )
	createEntry    ( 74373, -1, 7166, {}, nil )
	createQuest    ( 74374 )
	createEntry    ( 74374, -1, 6601, {}, nil )
	createQuest    ( 74375 )
	createEntry    ( 74375, -1, 6602, {}, nil )
	createQuest    ( 74376 )
	createEntry    ( 74376, -1, 6605, {}, nil )
	createEntry    ( 74376, -1, 22910, {}, nil )
	createEntry    ( 74376, -1, 34188, {}, nil )
	createEntry    ( 74376, -1, 34189, {}, nil )
	createQuest    ( 74377 )
	createEntry    ( 74377, -1, 6996, {}, nil )
	createEntry    ( 74377, -1, 7022, {}, nil )
	createEntry    ( 74377, -1, 7023, {}, nil )
	createEntry    ( 74377, -1, 7024, {}, nil )
	createEntry    ( 74377, -1, 7026, {}, nil )
	createEntry    ( 74377, -1, 10108, {}, nil )
	createEntry    ( 74377, -1, 15696, {}, nil )
	createEntry    ( 74377, -1, 15731, {}, nil )
	createEntry    ( 74377, -1, 15803, {}, nil )
	createEntry    ( 74377, -1, 15805, {}, nil )
	createEntry    ( 74377, -1, 15965, {}, nil )
	createEntry    ( 74377, -1, 16530, {}, nil )
	createEntry    ( 74377, -1, 20371, {}, nil )
	createEntry    ( 74377, -1, 20452, {}, nil )
	createEntry    ( 74377, -1, 22914, {}, nil )
	createEntry    ( 74377, -1, 37194, {}, nil )
	createQuest    ( 74378 )
	createEntry    ( 74378, -1, 7034, {}, nil )
	createEntry    ( 74378, -1, 32082, {}, nil )
	createEntry    ( 74378, -1, 32083, {}, nil )
	createEntry    ( 74378, -1, 34668, {}, nil )
	createEntry    ( 74378, -1, 34669, {}, nil )
	createQuest    ( 74379 )
	createEntry    ( 74379, -1, 7036, {}, nil )
	createEntry    ( 74379, -1, 16028, {}, nil )
	createQuest    ( 74380 )
	createEntry    ( 74380, -1, 7075, {}, nil )
	createEntry    ( 74380, -1, 7123, {}, nil )
	createEntry    ( 74380, -1, 15701, {}, nil )
	createEntry    ( 74380, -1, 16563, {}, nil )
	createEntry    ( 74380, -1, 20593, {}, nil )
	createQuest    ( 74381 )
	createEntry    ( 74381, -1, 7076, {}, nil )
	createQuest    ( 74382 )
	createEntry    ( 74382, -1, 7084, {}, nil )
	createEntry    ( 74382, -1, 23545, {}, nil )
	createEntry    ( 74382, -1, 23562, {}, nil )
	createQuest    ( 74383 )
	createEntry    ( 74383, -1, 7088, {}, nil )
	createQuest    ( 74384 )
	createEntry    ( 74384, -1, 7090, {}, nil )
	createEntry    ( 74384, -1, 7236, {}, nil )
	createEntry    ( 74384, -1, 7683, {}, nil )
	createEntry    ( 74384, -1, 7737, {}, nil )
	createEntry    ( 74384, -1, 8302, {}, nil )
	createEntry    ( 74384, -1, 10269, {}, nil )
	createEntry    ( 74384, -1, 11771, {}, nil )
	createQuest    ( 74385 )
	createEntry    ( 74385, -1, 7144, {}, nil )
	createEntry    ( 74385, -1, 16348, {}, nil )
	createQuest    ( 74386 )
	createEntry    ( 74386, -1, 7146, {}, nil )
	createEntry    ( 74386, -1, 10928, {}, nil )
	createEntry    ( 74386, -1, 11855, {}, nil )
	createEntry    ( 74386, -1, 20939, {}, nil )
	createEntry    ( 74386, -1, 20943, {}, nil )
	createQuest    ( 74387 )
	createEntry    ( 74387, -1, 7163, {}, nil )
	createEntry    ( 74387, -1, 22945, {}, nil )
	createQuest    ( 74388 )
	createEntry    ( 74388, -1, 7252, {}, nil )
	createEntry    ( 74388, -1, 7253, {}, nil )
	createEntry    ( 74388, -1, 7255, {}, nil )
	createEntry    ( 74388, -1, 22952, {}, nil )
	createEntry    ( 74388, -1, 23306, {}, nil )
	createQuest    ( 74389 )
	createEntry    ( 74389, -1, 7994, {}, nil )
	createEntry    ( 74389, -1, 8126, {}, nil )
	createQuest    ( 74390 )
	createEntry    ( 74390, -1, 8730, {}, nil )
	createEntry    ( 74390, -1, 23351, {}, nil )
	createQuest    ( 74391 )
	createEntry    ( 74391, -1, 9682, {}, nil )
	createEntry    ( 74391, -1, 15751, {}, nil )
	createEntry    ( 74391, -1, 15752, {}, nil )
	createEntry    ( 74391, -1, 16535, {}, nil )
	createEntry    ( 74391, -1, 23407, {}, nil )
	createQuest    ( 74392 )
	createEntry    ( 74392, -1, 9979, {}, nil )
	createEntry    ( 74392, -1, 10718, {}, nil )
	createEntry    ( 74392, -1, 15705, {}, nil )
	createEntry    ( 74392, -1, 16553, {}, nil )
	createEntry    ( 74392, -1, 34114, {}, nil )
	createQuest    ( 74393 )
	createEntry    ( 74393, -1, 10066, {}, nil )
	createQuest    ( 74394 )
	createEntry    ( 74394, -1, 10101, {}, nil )
	createEntry    ( 74394, -1, 16338, {}, nil )
	createQuest    ( 74395 )
	createEntry    ( 74395, -1, 10122, {}, nil )
	createEntry    ( 74395, -1, 10131, {}, nil )
	createEntry    ( 74395, -1, 11817, {}, nil )
	createEntry    ( 74395, -1, 22941, {}, nil )
	createEntry    ( 74395, -1, 23535, {}, nil )
	createQuest    ( 74396 )
	createEntry    ( 74396, -1, 10123, {}, nil )
	createEntry    ( 74396, -1, 15735, {}, nil )
	createEntry    ( 74396, -1, 15739, {}, nil )
	createEntry    ( 74396, -1, 23561, {}, nil )
	createQuest    ( 74397 )
	createEntry    ( 74397, -1, 10837, {}, nil )
	createEntry    ( 74397, -1, 53278, {}, nil )
	createEntry    ( 74397, -1, 54410, {}, nil )
	createEntry    ( 74397, -1, 54413, {}, nil )
	createEntry    ( 74397, -1, 57859, {}, nil )
	createEntry    ( 74397, -1, 57860, {}, nil )
	createEntry    ( 74397, -1, 57863, {}, nil )
	createEntry    ( 74397, -1, 57864, {}, nil )
	createEntry    ( 74397, -1, 57894, {}, nil )
	createQuest    ( 74398 )
	createEntry    ( 74398, -1, 10935, {}, nil )
	createEntry    ( 74398, -1, 16533, {}, nil )
	createQuest    ( 74399 )
	createEntry    ( 74399, -1, 10944, {}, nil )
	createQuest    ( 74400 )
	createEntry    ( 74400, -1, 11722, {}, nil )
	createQuest    ( 74401 )
	createEntry    ( 74401, -1, 15724, {}, nil )
	createEntry    ( 74401, -1, 22917, {}, nil )
	createQuest    ( 74402 )
	createEntry    ( 74402, -1, 15784, {}, nil )
	createQuest    ( 74403 )
	createEntry    ( 74403, -1, 16556, {}, nil )
	createEntry    ( 74403, -1, 47983, {}, nil )
	createEntry    ( 74403, -1, 47984, {}, nil )
	createQuest    ( 74404 )
	createEntry    ( 74404, -1, 19636, {}, nil )
	createEntry    ( 74404, -1, 19681, {}, nil )
	createQuest    ( 74405 )
	createEntry    ( 74405, -1, 19682, {}, nil )
	createEntry    ( 74405, -1, 19688, {}, nil )
	createEntry    ( 74405, -1, 47987, {}, nil )
	createEntry    ( 74405, -1, 47988, {}, nil )
	createEntry    ( 74405, -1, 47989, {}, nil )
	createEntry    ( 74405, -1, 47990, {}, nil )
	createQuest    ( 74406 )
	createEntry    ( 74406, -1, 20311, {}, nil )
	createQuest    ( 74407 )
	createEntry    ( 74407, -1, 20632, {}, nil )
	createEntry    ( 74407, -1, 20633, {}, nil )
	createQuest    ( 74408 )
	createEntry    ( 74408, -1, 20671, {}, nil )
	createEntry    ( 74408, -1, 22928, {}, nil )
	createEntry    ( 74408, -1, 34231, {}, nil )
	createEntry    ( 74408, -1, 47985, {}, nil )
	createQuest    ( 74409 )
	createEntry    ( 74409, -1, 20694, {}, nil )
	createQuest    ( 74410 )
	createEntry    ( 74410, -1, 21650, {}, nil )
	createQuest    ( 74411 )
	createEntry    ( 74411, -1, 21892, {}, nil )
	createEntry    ( 74411, -1, 34294, {}, nil )
	createQuest    ( 74412 )
	createEntry    ( 74412, -1, 23458, {}, nil )
	createQuest    ( 74413 )
	createEntry    ( 74413, -1, 23508, {}, nil )
	createQuest    ( 74414 )
	createEntry    ( 74414, -1, 34089, {}, nil )
	createQuest    ( 74415 )
	createEntry    ( 74415, -1, 34092, {}, nil )
	createEntry    ( 74415, -1, 34093, {}, nil )
	createEntry    ( 74415, -1, 47779, {}, nil )
	createQuest    ( 74416 )
	createEntry    ( 74416, -1, 34099, {}, nil )
	createEntry    ( 74416, -1, 47514, {}, nil )
	createEntry    ( 74416, -1, 47515, {}, nil )
	createQuest    ( 74417 )
	createEntry    ( 74417, -1, 34105, {}, nil )
	createEntry    ( 74417, -1, 47519, {}, nil )
	createQuest    ( 74418 )
	createEntry    ( 74418, -1, 34106, {}, nil )
	createEntry    ( 74418, -1, 47518, {}, nil )
	createQuest    ( 74419 )
	createEntry    ( 74419, -1, 34107, {}, nil )
	createEntry    ( 74419, -1, 47522, {}, nil )
	createQuest    ( 74420 )
	createEntry    ( 74420, -1, 34108, {}, nil )
	createEntry    ( 74420, -1, 47523, {}, nil )
	createQuest    ( 74421 )
	createEntry    ( 74421, -1, 34110, {}, nil )
	createEntry    ( 74421, -1, 34111, {}, nil )
	createEntry    ( 74421, -1, 47528, {}, nil )
	createQuest    ( 74422 )
	createEntry    ( 74422, -1, 34112, {}, nil )
	createEntry    ( 74422, -1, 34113, {}, nil )
	createEntry    ( 74422, -1, 47531, {}, nil )
	createQuest    ( 74423 )
	createEntry    ( 74423, -1, 34118, {}, nil )
	createEntry    ( 74423, -1, 34119, {}, nil )
	createEntry    ( 74423, -1, 47532, {}, nil )
	createQuest    ( 74424 )
	createEntry    ( 74424, -1, 34183, {}, nil )
	createEntry    ( 74424, -1, 34187, {}, nil )
	createEntry    ( 74424, -1, 47537, {}, nil )
	createQuest    ( 74425 )
	createEntry    ( 74425, -1, 34194, {}, nil )
	createEntry    ( 74425, -1, 34198, {}, nil )
	createEntry    ( 74425, -1, 34201, {}, nil )
	createEntry    ( 74425, -1, 34205, {}, nil )
	createEntry    ( 74425, -1, 34207, {}, nil )
	createEntry    ( 74425, -1, 34211, {}, nil )
	createEntry    ( 74425, -1, 34217, {}, nil )
	createEntry    ( 74425, -1, 34218, {}, nil )
	createEntry    ( 74425, -1, 34220, {}, nil )
	createEntry    ( 74425, -1, 34232, {}, nil )
	createEntry    ( 74425, -1, 34233, {}, nil )
	createEntry    ( 74425, -1, 34234, {}, nil )
	createEntry    ( 74425, -1, 34235, {}, nil )
	createEntry    ( 74425, -1, 34236, {}, nil )
	createEntry    ( 74425, -1, 34237, {}, nil )
	createEntry    ( 74425, -1, 34238, {}, nil )
	createEntry    ( 74425, -1, 34239, {}, nil )
	createEntry    ( 74425, -1, 34240, {}, nil )
	createEntry    ( 74425, -1, 34241, {}, nil )
	createEntry    ( 74425, -1, 34243, {}, nil )
	createEntry    ( 74425, -1, 47538, {}, nil )
	createEntry    ( 74425, -1, 47545, {}, nil )
	createQuest    ( 74426 )
	createEntry    ( 74426, -1, 34244, {}, nil )
	createEntry    ( 74426, -1, 34245, {}, nil )
	createEntry    ( 74426, -1, 34246, {}, nil )
	createEntry    ( 74426, -1, 47725, {}, nil )
	createQuest    ( 74427 )
	createEntry    ( 74427, -1, 34247, {}, nil )
	createEntry    ( 74427, -1, 34249, {}, nil )
	createEntry    ( 74427, -1, 34265, {}, nil )
	createEntry    ( 74427, -1, 34266, {}, nil )
	createEntry    ( 74427, -1, 34267, {}, nil )
	createEntry    ( 74427, -1, 34269, {}, nil )
	createEntry    ( 74427, -1, 34271, {}, nil )
	createEntry    ( 74427, -1, 34276, {}, nil )
	createEntry    ( 74427, -1, 34277, {}, nil )
	createEntry    ( 74427, -1, 34281, {}, nil )
	createEntry    ( 74427, -1, 34287, {}, nil )
	createEntry    ( 74427, -1, 47575, {}, nil )
	createEntry    ( 74427, -1, 47578, {}, nil )
	createQuest    ( 74428 )
	createEntry    ( 74428, -1, 34290, {}, nil )
	createEntry    ( 74428, -1, 47651, {}, nil )
	createEntry    ( 74428, -1, 47704, {}, nil )
	createQuest    ( 74429 )
	createEntry    ( 74429, -1, 34291, {}, nil )
	createEntry    ( 74429, -1, 34295, {}, nil )
	createEntry    ( 74429, -1, 34296, {}, nil )
	createEntry    ( 74429, -1, 34299, {}, nil )
	createEntry    ( 74429, -1, 34300, {}, nil )
	createEntry    ( 74429, -1, 47581, {}, nil )
	createQuest    ( 74430 )
	createEntry    ( 74430, -1, 34301, {}, nil )
	createEntry    ( 74430, -1, 34302, {}, nil )
	createEntry    ( 74430, -1, 34307, {}, nil )
	createEntry    ( 74430, -1, 34311, {}, nil )
	createEntry    ( 74430, -1, 34315, {}, nil )
	createEntry    ( 74430, -1, 34324, {}, nil )
	createQuest    ( 74431 )
	createEntry    ( 74431, -1, 34337, {}, nil )
	createEntry    ( 74431, -1, 47705, {}, nil )
	createQuest    ( 74432 )
	createEntry    ( 74432, -1, 34382, {}, nil )
	createEntry    ( 74432, -1, 34383, {}, nil )
	createEntry    ( 74432, -1, 34384, {}, nil )
	createEntry    ( 74432, -1, 47710, {}, nil )
	createQuest    ( 74433 )
	createEntry    ( 74433, -1, 34385, {}, nil )
	createQuest    ( 74434 )
	createEntry    ( 74434, -1, 34386, {}, nil )
	createQuest    ( 74435 )
	createEntry    ( 74435, -1, 34443, {}, nil )
	createEntry    ( 74435, -1, 34712, {}, nil )
	createEntry    ( 74435, -1, 34717, {}, nil )
	createEntry    ( 74435, -1, 34718, {}, nil )
	createEntry    ( 74435, -1, 34719, {}, nil )
	createEntry    ( 74435, -1, 34720, {}, nil )
	createEntry    ( 74435, -1, 34721, {}, nil )
	createEntry    ( 74435, -1, 34725, {}, nil )
	createEntry    ( 74435, -1, 34726, {}, nil )
	createEntry    ( 74435, -1, 47992, {}, nil )
	createEntry    ( 74435, -1, 47993, {}, nil )
	createEntry    ( 74435, -1, 47994, {}, nil )
	createEntry    ( 74435, -1, 47995, {}, nil )
	createEntry    ( 74435, -1, 47996, {}, nil )
	createEntry    ( 74435, -1, 47997, {}, nil )
	createEntry    ( 74435, -1, 47998, {}, nil )
	createEntry    ( 74435, -1, 47999, {}, nil )
	createEntry    ( 74435, -1, 48000, {}, nil )
	createQuest    ( 74436 )
	createEntry    ( 74436, -1, 34660, {}, nil )
	createEntry    ( 74436, -1, 34661, {}, nil )
	createEntry    ( 74436, -1, 34662, {}, nil )
	createEntry    ( 74436, -1, 34663, {}, nil )
	createEntry    ( 74436, -1, 34664, {}, nil )
	createEntry    ( 74436, -1, 34665, {}, nil )
	createEntry    ( 74436, -1, 34666, {}, nil )
	createEntry    ( 74436, -1, 34667, {}, nil )
	createEntry    ( 74436, -1, 48002, {}, nil )
	createEntry    ( 74436, -1, 48003, {}, nil )
	createEntry    ( 74436, -1, 48017, {}, nil )
	createEntry    ( 74436, -1, 48018, {}, nil )
	createQuest    ( 74437 )
	createEntry    ( 74437, -1, 34673, {}, nil )
	createEntry    ( 74437, -1, 34683, {}, nil )
	createEntry    ( 74437, -1, 34687, {}, nil )
	createEntry    ( 74437, -1, 34691, {}, nil )
	createEntry    ( 74437, -1, 34692, {}, nil )
	createEntry    ( 74437, -1, 34695, {}, nil )
	createEntry    ( 74437, -1, 34696, {}, nil )
	createQuest    ( 74438 )
	createEntry    ( 74438, -1, 43045, {}, nil )
	createQuest    ( 74439 )
	createEntry    ( 74439, -1, 45237, {}, nil )
	createEntry    ( 74439, -1, 55522, {}, nil )
	createEntry    ( 74439, -1, 55524, {}, nil )
	createEntry    ( 74439, -1, 55526, {}, nil )
	createEntry    ( 74439, -1, 55527, {}, nil )
	createEntry    ( 74439, -1, 55530, {}, nil )
	createEntry    ( 74439, -1, 55531, {}, nil )
	createEntry    ( 74439, -1, 55532, {}, nil )
	createEntry    ( 74439, -1, 55533, {}, nil )
	createEntry    ( 74439, -1, 55534, {}, nil )
	createEntry    ( 74439, -1, 55535, {}, nil )
	createEntry    ( 74439, -1, 55536, {}, nil )
	createEntry    ( 74439, -1, 55537, {}, nil )
	createEntry    ( 74439, -1, 55538, {}, nil )
	createEntry    ( 74439, -1, 55539, {}, nil )
	createEntry    ( 74439, -1, 55540, {}, nil )
	createEntry    ( 74439, -1, 55541, {}, nil )
	createEntry    ( 74439, -1, 55542, {}, nil )
	createEntry    ( 74439, -1, 55543, {}, nil )
	createQuest    ( 74440 )
	createEntry    ( 74440, -1, 46839, {}, nil )
	createEntry    ( 74440, -1, 47740, {}, nil )
	createQuest    ( 74441 )
	createEntry    ( 74441, -1, 46840, {}, nil )
	createEntry    ( 74441, -1, 47742, {}, nil )
	createQuest    ( 74442 )
	createEntry    ( 74442, -1, 46842, {}, nil )
	createQuest    ( 74443 )
	createEntry    ( 74443, -1, 47517, {}, nil )
	createQuest    ( 74444 )
	createEntry    ( 74444, -1, 47759, {}, nil )
	createEntry    ( 74444, -1, 51915, {}, nil )
	createEntry    ( 74444, -1, 51916, {}, nil )
	createQuest    ( 74445 )
	createEntry    ( 74445, -1, 47783, {}, nil )
	createEntry    ( 74445, -1, 47805, {}, nil )
	createEntry    ( 74445, -1, 47806, {}, nil )
	createEntry    ( 74445, -1, 47831, {}, nil )
	createEntry    ( 74445, -1, 47837, {}, nil )
	createEntry    ( 74445, -1, 47838, {}, nil )
	createEntry    ( 74445, -1, 47839, {}, nil )
	createQuest    ( 74446 )
	createEntry    ( 74446, -1, 47848, {}, nil )
	createEntry    ( 74446, -1, 47851, {}, nil )
	createEntry    ( 74446, -1, 47854, {}, nil )
	createQuest    ( 74447 )
	createEntry    ( 74447, -1, 47862, {}, nil )
	createEntry    ( 74447, -1, 47863, {}, nil )
	createEntry    ( 74447, -1, 47864, {}, nil )
	createEntry    ( 74447, -1, 47866, {}, nil )
	createEntry    ( 74447, -1, 47873, {}, nil )
	createEntry    ( 74447, -1, 47874, {}, nil )
	createQuest    ( 74448 )
	createEntry    ( 74448, -1, 47986, {}, nil )
	createQuest    ( 74449 )
	createEntry    ( 74449, -1, 47991, {}, nil )
	createQuest    ( 74450 )
	createEntry    ( 74450, -1, 48001, {}, nil )
	createQuest    ( 74451 )
	createEntry    ( 74451, -1, 48012, {}, nil )
	createEntry    ( 74451, -1, 48014, {}, nil )
	createEntry    ( 74451, -1, 48015, {}, nil )
	createEntry    ( 74451, -1, 48016, {}, nil )
	createQuest    ( 74452 )
	createEntry    ( 74452, -1, 48013, {}, nil )
	createQuest    ( 74453 )
	createEntry    ( 74453, -1, 48019, {}, nil )
	createQuest    ( 74454 )
	createEntry    ( 74454, -1, 49258, {}, nil )
	createEntry    ( 74454, -1, 50733, {}, nil )
	createEntry    ( 74454, -1, 50749, {}, nil )
	createEntry    ( 74454, -1, 54895, {}, nil )
	createEntry    ( 74454, -1, 54924, {}, nil )
	createEntry    ( 74454, -1, 54925, {}, nil )
	createEntry    ( 74454, -1, 54926, {}, nil )
	createEntry    ( 74454, -1, 54927, {}, nil )
	createEntry    ( 74454, -1, 54929, {}, nil )
	createEntry    ( 74454, -1, 54930, {}, nil )
	createEntry    ( 74454, -1, 54935, {}, nil )
	createEntry    ( 74454, -1, 54936, {}, nil )
	createEntry    ( 74454, -1, 54946, {}, nil )
	createEntry    ( 74454, -1, 54947, {}, nil )
	createEntry    ( 74454, -1, 54948, {}, nil )
	createEntry    ( 74454, -1, 54949, {}, nil )
	createEntry    ( 74454, -1, 54950, {}, nil )
	createEntry    ( 74454, -1, 54951, {}, nil )
	createEntry    ( 74454, -1, 54952, {}, nil )
	createEntry    ( 74454, -1, 55128, {}, nil )
	createEntry    ( 74454, -1, 55203, {}, nil )
	createEntry    ( 74454, -1, 55232, {}, nil )
	createEntry    ( 74454, -1, 55265, {}, nil )
	createEntry    ( 74454, -1, 55291, {}, nil )
	createEntry    ( 74454, -1, 55342, {}, nil )
	createEntry    ( 74454, -1, 55363, {}, nil )
	createEntry    ( 74454, -1, 55364, {}, nil )
	createEntry    ( 74454, -1, 55365, {}, nil )
	createEntry    ( 74454, -1, 55366, {}, nil )
	createEntry    ( 74454, -1, 55497, {}, nil )
	createEntry    ( 74454, -1, 55499, {}, nil )
	createEntry    ( 74454, -1, 55503, {}, nil )
	createEntry    ( 74454, -1, 55504, {}, nil )
	createEntry    ( 74454, -1, 55505, {}, nil )
	createEntry    ( 74454, -1, 55506, {}, nil )
	createEntry    ( 74454, -1, 55507, {}, nil )
	createEntry    ( 74454, -1, 55508, {}, nil )
	createEntry    ( 74454, -1, 55509, {}, nil )
	createEntry    ( 74454, -1, 55510, {}, nil )
	createEntry    ( 74454, -1, 55511, {}, nil )
	createEntry    ( 74454, -1, 55513, {}, nil )
	createQuest    ( 74455 )
	createEntry    ( 74455, -1, 49465, {}, nil )
	createEntry    ( 74455, -1, 49476, {}, nil )
	createQuest    ( 74456 )
	createEntry    ( 74456, -1, 49472, {}, nil )
	createQuest    ( 74457 )
	createEntry    ( 74457, -1, 51885, {}, nil )
	createEntry    ( 74457, -1, 51888, {}, nil )
	createEntry    ( 74457, -1, 53242, {}, nil )
	createEntry    ( 74457, -1, 54288, {}, nil )
	createEntry    ( 74457, -1, 54289, {}, nil )
	createEntry    ( 74457, -1, 54290, {}, nil )
	createEntry    ( 74457, -1, 54291, {}, nil )
	createQuest    ( 74458 )
	createEntry    ( 74458, -1, 54293, {}, nil )
	createEntry    ( 74458, -1, 54376, {}, nil )
	createQuest    ( 74459 )
	createEntry    ( 74459, -1, 54686, {}, nil )
	createEntry    ( 74459, -1, 57914, {}, nil )
	createEntry    ( 74459, -1, 57940, {}, nil )
	createEntry    ( 74459, -1, 57944, {}, nil )
	createEntry    ( 74459, -1, 57946, {}, nil )
	createEntry    ( 74459, -1, 57948, {}, nil )
	createEntry    ( 74459, -1, 57949, {}, nil )
	createEntry    ( 74459, -1, 57950, {}, nil )
	createEntry    ( 74459, -1, 57951, {}, nil )
	createEntry    ( 74459, -1, 57952, {}, nil )
	createEntry    ( 74459, -1, 57954, {}, nil )
	createEntry    ( 74459, -1, 57958, {}, nil )
	createQuest    ( 74460 )
	createEntry    ( 74460, -1, 54928, {}, nil )
	createQuest    ( 74461 )
	createEntry    ( 74461, -1, 55408, {}, nil )
	createEntry    ( 74461, -1, 55409, {}, nil )
	createQuest    ( 74462 )
	createEntry    ( 74462, -1, 55435, {}, nil )
	createEntry    ( 74462, -1, 55458, {}, nil )
	createEntry    ( 74462, -1, 55459, {}, nil )
	createQuest    ( 74463 )
	createEntry    ( 74463, -1, 55544, {}, nil )
	createEntry    ( 74463, -1, 55545, {}, nil )
	createEntry    ( 74463, -1, 55546, {}, nil )
	createEntry    ( 74463, -1, 55547, {}, nil )
	createEntry    ( 74463, -1, 55548, {}, nil )
	createEntry    ( 74463, -1, 55549, {}, nil )
	createEntry    ( 74463, -1, 55550, {}, nil )
	createEntry    ( 74463, -1, 55551, {}, nil )
	createEntry    ( 74463, -1, 55552, {}, nil )
	createEntry    ( 74463, -1, 55553, {}, nil )
	createEntry    ( 74463, -1, 55554, {}, nil )
	createEntry    ( 74463, -1, 55555, {}, nil )
	createEntry    ( 74463, -1, 55556, {}, nil )
	createEntry    ( 74463, -1, 55557, {}, nil )
	createEntry    ( 74463, -1, 55558, {}, nil )
	createEntry    ( 74463, -1, 55559, {}, nil )
	createEntry    ( 74463, -1, 55560, {}, nil )
	createEntry    ( 74463, -1, 55561, {}, nil )
	createEntry    ( 74463, -1, 55562, {}, nil )
	createEntry    ( 74463, -1, 55563, {}, nil )
	createEntry    ( 74463, -1, 55564, {}, nil )
	createEntry    ( 74463, -1, 55565, {}, nil )
	createEntry    ( 74463, -1, 55566, {}, nil )
	createEntry    ( 74463, -1, 61436, {}, nil )
	createEntry    ( 74463, -1, 61437, {}, nil )
	createEntry    ( 74463, -1, 61438, {}, nil )
	createQuest    ( 74464 )
	createEntry    ( 74464, -1, 55567, {}, nil )
	createEntry    ( 74464, -1, 55568, {}, nil )
	createEntry    ( 74464, -1, 55569, {}, nil )
	createEntry    ( 74464, -1, 55570, {}, nil )
	createEntry    ( 74464, -1, 55571, {}, nil )
	createEntry    ( 74464, -1, 55572, {}, nil )
	createEntry    ( 74464, -1, 55573, {}, nil )
	createEntry    ( 74464, -1, 55574, {}, nil )
	createEntry    ( 74464, -1, 55575, {}, nil )
	createEntry    ( 74464, -1, 55576, {}, nil )
	createEntry    ( 74464, -1, 55577, {}, nil )
	createEntry    ( 74464, -1, 55578, {}, nil )
	createEntry    ( 74464, -1, 55579, {}, nil )
	createEntry    ( 74464, -1, 55581, {}, nil )
	createEntry    ( 74464, -1, 55582, {}, nil )
	createEntry    ( 74464, -1, 55583, {}, nil )
	createEntry    ( 74464, -1, 55584, {}, nil )
	createEntry    ( 74464, -1, 55585, {}, nil )
	createEntry    ( 74464, -1, 55586, {}, nil )
	createEntry    ( 74464, -1, 55587, {}, nil )
	createEntry    ( 74464, -1, 55588, {}, nil )
	createEntry    ( 74464, -1, 55589, {}, nil )
	createEntry    ( 74464, -1, 55590, {}, nil )
	createEntry    ( 74464, -1, 55591, {}, nil )
	createEntry    ( 74464, -1, 55592, {}, nil )
	createEntry    ( 74464, -1, 55593, {}, nil )
	createEntry    ( 74464, -1, 55594, {}, nil )
	createEntry    ( 74464, -1, 55595, {}, nil )
	createEntry    ( 74464, -1, 55596, {}, nil )
	createEntry    ( 74464, -1, 55597, {}, nil )
	createEntry    ( 74464, -1, 55598, {}, nil )
	createEntry    ( 74464, -1, 55599, {}, nil )
	createEntry    ( 74464, -1, 55600, {}, nil )
	createEntry    ( 74464, -1, 55601, {}, nil )
	createEntry    ( 74464, -1, 55602, {}, nil )
	createEntry    ( 74464, -1, 55603, {}, nil )
	createEntry    ( 74464, -1, 55604, {}, nil )
	createEntry    ( 74464, -1, 55605, {}, nil )
	createEntry    ( 74464, -1, 55606, {}, nil )
	createEntry    ( 74464, -1, 55607, {}, nil )
	createEntry    ( 74464, -1, 55608, {}, nil )
	createEntry    ( 74464, -1, 55609, {}, nil )
	createEntry    ( 74464, -1, 55610, {}, nil )
	createEntry    ( 74464, -1, 55611, {}, nil )
	createEntry    ( 74464, -1, 55612, {}, nil )
	createEntry    ( 74464, -1, 55613, {}, nil )
	createEntry    ( 74464, -1, 55614, {}, nil )
	createEntry    ( 74464, -1, 55615, {}, nil )
	createEntry    ( 74464, -1, 55616, {}, nil )
	createEntry    ( 74464, -1, 55617, {}, nil )
	createEntry    ( 74464, -1, 55618, {}, nil )
	createEntry    ( 74464, -1, 55619, {}, nil )
	createEntry    ( 74464, -1, 55620, {}, nil )
	createEntry    ( 74464, -1, 55621, {}, nil )
	createEntry    ( 74464, -1, 55622, {}, nil )
	createEntry    ( 74464, -1, 55623, {}, nil )
	createEntry    ( 74464, -1, 55624, {}, nil )
	createQuest    ( 74465 )
	createEntry    ( 74465, -1, 55625, {}, nil )
	createEntry    ( 74465, -1, 55626, {}, nil )
	createEntry    ( 74465, -1, 55627, {}, nil )
	createEntry    ( 74465, -1, 55628, {}, nil )
	createEntry    ( 74465, -1, 55629, {}, nil )
	createEntry    ( 74465, -1, 55630, {}, nil )
	createEntry    ( 74465, -1, 55631, {}, nil )
	createEntry    ( 74465, -1, 55632, {}, nil )
	createEntry    ( 74465, -1, 55633, {}, nil )
	createEntry    ( 74465, -1, 55634, {}, nil )
	createEntry    ( 74465, -1, 55635, {}, nil )
	createEntry    ( 74465, -1, 55636, {}, nil )
	createEntry    ( 74465, -1, 55637, {}, nil )
	createEntry    ( 74465, -1, 55638, {}, nil )
	createEntry    ( 74465, -1, 55639, {}, nil )
	createEntry    ( 74465, -1, 55640, {}, nil )
	createEntry    ( 74465, -1, 55641, {}, nil )
	createEntry    ( 74465, -1, 55642, {}, nil )
	createEntry    ( 74465, -1, 55643, {}, nil )
	createEntry    ( 74465, -1, 55644, {}, nil )
	createQuest    ( 74467 )
	createEntry    ( 74467, -1, 57518, {}, nil )
	createQuest    ( 74468 )
	createEntry    ( 74468, -1, 57533, {}, nil )
	createEntry    ( 74468, -1, 57534, {}, nil )
	createEntry    ( 74468, -1, 57535, {}, nil )
	createEntry    ( 74468, -1, 57536, {}, nil )
	createEntry    ( 74468, -1, 57851, {}, nil )
	createEntry    ( 74468, -1, 57854, {}, nil )
	createEntry    ( 74468, -1, 57856, {}, nil )
	createQuest    ( 74469 )
	createEntry    ( 74469, -1, 57549, {}, nil )
	createEntry    ( 74469, -1, 57550, {}, nil )
	createQuest    ( 74470 )
	createEntry    ( 74470, -1, 57551, {}, nil )
	createEntry    ( 74470, -1, 57552, {}, nil )
	createEntry    ( 74470, -1, 57553, {}, nil )
	createEntry    ( 74470, -1, 57554, {}, nil )
	createEntry    ( 74470, -1, 57555, {}, nil )
	createEntry    ( 74470, -1, 57556, {}, nil )
	createEntry    ( 74470, -1, 57557, {}, nil )
	createQuest    ( 74471 )
	createEntry    ( 74471, -1, 57558, {}, nil )
	createEntry    ( 74471, -1, 57566, {}, nil )
	createEntry    ( 74471, -1, 57567, {}, nil )
	createEntry    ( 74471, -1, 57568, {}, nil )
	createEntry    ( 74471, -1, 57569, {}, nil )
	createEntry    ( 74471, -1, 57570, {}, nil )
	createEntry    ( 74471, -1, 57579, {}, nil )
	createQuest    ( 74472 )
	createEntry    ( 74472, -1, 57559, {}, nil )
	createQuest    ( 74473 )
	createEntry    ( 74473, -1, 57563, {}, nil )
	createQuest    ( 74474 )
	createEntry    ( 74474, -1, 57580, {}, nil )
	createQuest    ( 74475 )
	createEntry    ( 74475, -1, 57761, {}, nil )
	createQuest    ( 74476 )
	createEntry    ( 74476, -1, 57767, {}, nil )
	createEntry    ( 74476, -1, 57768, {}, nil )
	createEntry    ( 74476, -1, 57779, {}, nil )
	createEntry    ( 74476, -1, 57842, {}, nil )
	createEntry    ( 74476, -1, 57843, {}, nil )
	createQuest    ( 74477 )
	createEntry    ( 74477, -1, 57866, {}, nil )
	createEntry    ( 74477, -1, 57868, {}, nil )
	createQuest    ( 74478 )
	createEntry    ( 74478, -1, 61279, {}, nil )
	createEntry    ( 74478, -1, 61280, {}, nil )
	createQuest    ( 74479 )
	createEntry    ( 74479, -1, 61348, {}, nil )
	createEntry    ( 74479, -1, 61352, {}, nil )
	createQuest    ( 74480 )
	createEntry    ( 74480, -1, 61413, {}, nil )
	createEntry    ( 74480, -1, 61414, {}, nil )
	createQuest    ( 74481 )
	createEntry    ( 74481, -1, 62038, {}, nil )
	createQuest    ( 66122 )
	createEntry    ( 66122, -1, 62402, {}, nil )
	createEntry    ( 66122, -1, 62423, {}, nil )
	createEntry    ( 66122, -1, 62461, {}, nil )
	createEntry    ( 66122, -1, 62481, {}, nil )
	createEntry    ( 66122, -1, 62581, {}, nil )
	createEntry    ( 66122, -1, 62582, {}, nil )
	createEntry    ( 66122, -1, 62594, {}, nil )
	createEntry    ( 66122, -1, 62660, {}, nil )
	createEntry    ( 66122, -1, 62665, {}, nil )
	createEntry    ( 66122, -1, 62682, {}, nil )
	createEntry    ( 66122, -1, 62987, {}, nil )
	createEntry    ( 66122, -1, 63048, {}, nil )
	createEntry    ( 66122, -1, 63049, {}, nil )
	createEntry    ( 66122, -1, 63091, {}, nil )
	createEntry    ( 66122, -1, 71078, {}, nil )
	createQuest    ( 74482 )
	createEntry    ( 74482, -1, 63733, {}, nil )
	createEntry    ( 74482, -1, 63734, {}, nil )
	createEntry    ( 74482, -1, 63735, {}, nil )
	createQuest    ( 74483 )
	createEntry    ( 74483, -1, 63736, {}, nil )
	createEntry    ( 74483, -1, 63737, {}, nil )
	createEntry    ( 74483, -1, 63738, {}, nil )
	createEntry    ( 74483, -1, 63739, {}, nil )
	createQuest    ( 74484 )
	createEntry    ( 74484, -1, 63813, {}, nil )
	createEntry    ( 74484, -1, 63815, {}, nil )
	createEntry    ( 74484, -1, 63816, {}, nil )
	createEntry    ( 74484, -1, 63819, {}, nil )
	createEntry    ( 74484, -1, 71159, {}, nil )
	createQuest    ( 74485 )
	createEntry    ( 74485, -1, 63822, {}, nil )
	createEntry    ( 74485, -1, 63823, {}, nil )
	createQuest    ( 74486 )
	createEntry    ( 74486, -1, 63824, {}, nil )
	createEntry    ( 74486, -1, 63825, {}, nil )
	createQuest    ( 74487 )
	createEntry    ( 74487, -1, 63827, {}, nil )
	createEntry    ( 74487, -1, 63832, {}, nil )
	createEntry    ( 74487, -1, 63833, {}, nil )
	createEntry    ( 74487, -1, 63836, {}, nil )
	createEntry    ( 74487, -1, 63837, {}, nil )
	createQuest    ( 74488 )
	createEntry    ( 74488, -1, 64995, {}, nil )
	createEntry    ( 74488, -1, 65001, {}, nil )
	createEntry    ( 74488, -1, 65003, {}, nil )
	createEntry    ( 74488, -1, 65062, {}, nil )
	createEntry    ( 74488, -1, 73957, {}, nil )
	createEntry    ( 74488, -1, 73961, {}, nil )
	createQuest    ( 74489 )
	createEntry    ( 74489, -1, 64998, {}, nil )
	createEntry    ( 74489, -1, 65000, {}, nil )
	createEntry    ( 74489, -1, 65594, {}, nil )
	createQuest    ( 74490 )
	createEntry    ( 74490, -1, 65015, {}, nil )
	createEntry    ( 74490, -1, 65028, {}, nil )
	createEntry    ( 74490, -1, 65031, {}, nil )
	createEntry    ( 74490, -1, 65034, {}, nil )
	createEntry    ( 74490, -1, 65038, {}, nil )
	createEntry    ( 74490, -1, 65041, {}, nil )
	createEntry    ( 74490, -1, 65045, {}, nil )
	createEntry    ( 74490, -1, 65049, {}, nil )
	createEntry    ( 74490, -1, 65051, {}, nil )
	createEntry    ( 74490, -1, 65052, {}, nil )
	createQuest    ( 74491 )
	createEntry    ( 74491, -1, 65769, {}, nil )
	createEntry    ( 74491, -1, 66112, {}, nil )
	createEntry    ( 74491, -1, 66117, {}, nil )
	createEntry    ( 74491, -1, 66121, {}, nil )
	createEntry    ( 74491, -1, 66143, {}, nil )
	createEntry    ( 74491, -1, 66263, {}, nil )
	createQuest    ( 74492 )
	createEntry    ( 74492, -1, 66262, {}, nil )
	createQuest    ( 74493 )
	createEntry    ( 74493, -1, 66357, {}, nil )
	createEntry    ( 74493, -1, 67720, {}, nil )
	createEntry    ( 74493, -1, 67721, {}, nil )
	createEntry    ( 74493, -1, 67722, {}, nil )
	createEntry    ( 74493, -1, 67723, {}, nil )
	createEntry    ( 74493, -1, 67747, {}, nil )
	createQuest    ( 74494 )
	createEntry    ( 74494, -1, 67464, {}, nil )
	createEntry    ( 74494, -1, 67465, {}, nil )
	createEntry    ( 74494, -1, 67471, {}, nil )
	createQuest    ( 74495 )
	createEntry    ( 74495, -1, 67718, {}, nil )
	createEntry    ( 74495, -1, 67719, {}, nil )
	createEntry    ( 74495, -1, 72245, {}, nil )
	createQuest    ( 74496 )
	createEntry    ( 74496, -1, 70666, {}, nil )
	createQuest    ( 74497 )
	createEntry    ( 74497, -1, 71102, {}, nil )
	createQuest    ( 74498 )
	createEntry    ( 74498, -1, 72343, {}, nil )
	createEntry    ( 74498, -1, 73207, {}, nil )
	createEntry    ( 74498, -1, 73384, {}, nil )
	createQuest    ( 74499 )
	createEntry    ( 74499, -1, 73477, {}, nil )
	createEntry    ( 74499, -1, 73724, {}, nil )
	createEntry    ( 74499, -1, 73725, {}, nil )
	createEntry    ( 74499, -1, 73726, {}, nil )
	createEntry    ( 74499, -1, 73727, {}, nil )
	createEntry    ( 74499, -1, 73728, {}, nil )
	createEntry    ( 74499, -1, 73729, {}, nil )
	createEntry    ( 74499, -1, 73731, {}, nil )
	createEntry    ( 74499, -1, 73732, {}, nil )
	createEntry    ( 74499, -1, 73733, {}, nil )
	createQuest    ( 74500 )
	createEntry    ( 74500, -1, 73486, {}, nil )
	createEntry    ( 74500, -1, 73487, {}, nil )
	createEntry    ( 74500, -1, 73488, {}, nil )
	createEntry    ( 74500, -1, 73489, {}, nil )
	createEntry    ( 74500, -1, 73490, {}, nil )
	createEntry    ( 74500, -1, 73491, {}, nil )
	createQuest    ( 74501 )
	createEntry    ( 74501, -1, 73526, {}, nil )
--	createQuest    ( 74502 )
--	createEntry    ( 74502, -1, 73855, {}, nil )
--	createEntry    ( 74502, -1, 73856, {}, nil )
	createQuest    ( 74503 )
	createEntry    ( 74503, -1, 73857, {}, nil )
	createQuest    ( 74504 )
	createEntry    ( 74504, -1, 73858, {}, nil )
	createQuest    ( 74505 )
	createEntry    ( 74505, -1, 73859, {}, nil )
	createQuest    ( 74506 )
	createEntry    ( 74506, -1, 73861, {}, nil )
	createEntry    ( 74506, -1, 73863, {}, nil )
	createEntry    ( 74506, -1, 73864, {}, nil )
	createEntry    ( 74506, -1, 73865, {}, nil )
	createQuest    ( 74507 )
	createEntry    ( 74507, -1, 73958, {}, nil )
	createEntry    ( 74507, -1, 73959, {}, nil )
	createQuest    ( 93935 )
	createEntry    ( 93935, -1, 85016, {}, nil )
	createEntry    ( 93935, -1, 85023, {}, nil )
	createEntry    ( 93935, -1, 85025, {}, nil )
	createEntry    ( 93935, -1, 85034, {}, nil )
	createEntry    ( 93935, -1, 85056, {}, nil )
	createEntry    ( 93935, -1, 85058, {}, nil )
	createEntry    ( 93935, -1, 85066, {}, nil )
	createEntry    ( 93935, -1, 85067, {}, nil )
	createEntry    ( 93935, -1, 85068, {}, nil )
	createEntry    ( 93935, -1, 85069, {}, nil )
	createEntry    ( 93935, -1, 85086, {}, nil )
	createEntry    ( 93935, -1, 85091, {}, nil )
	createEntry    ( 93935, -1, 85092, {}, nil )
	createEntry    ( 93935, -1, 85093, {}, nil )
	createEntry    ( 93935, -1, 94024, {}, nil )
	createEntry    ( 93935, -1, 94025, {}, nil )
	createEntry    ( 93935, -1, 93943, {}, nil )
	createEntry    ( 93935, -1, 93946, {}, nil )
	createEntry    ( 93935, -1, 93979, {}, nil )
	createEntry    ( 93935, -1, 93980, {}, nil )
	createEntry    ( 93935, -1, 93981, {}, nil )
	createEntry    ( 93935, -1, 93984, {}, nil )
	createEntry    ( 93935, -1, 93985, {}, nil )
	createEntry    ( 93935, -1, 93988, {}, nil )
	createQuest    ( 94452 )
	createEntry    ( 94452, -1, 94453, {}, nil )
	createEntry    ( 94452, -1, 94454, {}, nil )
	createEntry    ( 94452, -1, 94455, {}, nil )
	createEntry    ( 94452, -1, 94456, {}, nil )
	createQuest    ( 94457 )
	createEntry    ( 94457, -1, 94458, {}, nil )
	createEntry    ( 94457, -1, 94459, {}, nil )
	createEntry    ( 94457, -1, 94460, {}, nil )
	createQuest    ( 94461 )
	createEntry    ( 94461, -1, 94462, {}, nil )
	createEntry    ( 94461, -1, 94463, {}, nil )
	createQuest    ( 94464 )
	createEntry    ( 94464, -1, 94465, {}, nil )
	createEntry    ( 94464, -1, 94466, {}, nil )
	createEntry    ( 94464, -1, 94467, {}, nil )
	createQuest    ( 94474 )
	createEntry    ( 94474, -1, 94475, {}, nil )
	createEntry    ( 94474, -1, 94476, {}, nil )
	createEntry    ( 94474, -1, 94477, {}, nil )
	createEntry    ( 94474, -1, 94478, {}, nil )
	createEntry    ( 94474, -1, 94479, {}, nil )
	createEntry    ( 94474, -1, 94480, {}, nil )
	createEntry    ( 94474, -1, 94481, {}, nil )
	createEntry    ( 94474, -1, 94482, {}, nil )
	createQuest    ( 94483 )
	createEntry    ( 94483, -1, 94484, {}, nil )
	createEntry    ( 94483, -1, 94485, {}, nil )
	createEntry    ( 94483, -1, 94486, {}, nil )
	createEntry    ( 94483, -1, 94487, {}, nil )
	createEntry    ( 94483, -1, 94488, {}, nil )
	createEntry    ( 94483, -1, 94489, {}, nil )
	createEntry    ( 94483, -1, 94490, {}, nil )
	createQuest    ( 94495 )
	createEntry    ( 94495, -1, 94496, {}, nil )
	createEntry    ( 94495, -1, 94497, {}, nil )
	createEntry    ( 94495, -1, 94498, {}, nil )
	createEntry    ( 94495, -1, 94499, {}, nil )
	createEntry    ( 94495, -1, 94500, {}, nil )
	createEntry    ( 94495, -1, 94501, {}, nil )
	createEntry    ( 94495, -1, 94502, {}, nil )
	createEntry    ( 94495, -1, 94503, {}, nil )
	createEntry    ( 94495, -1, 94504, {}, nil )
	createEntry    ( 94495, -1, 94505, {}, nil )
	createEntry    ( 94495, -1, 94506, {}, nil )
	createEntry    ( 94495, -1, 94507, {}, nil )
	createQuest    ( 96076 )
	createEntry    ( 96076, -1, 96068, {}, nil )
	createEntry    ( 96076, -1, 96069, {}, nil )
	createEntry    ( 96076, -1, 96070, {}, nil )
	createEntry    ( 96076, -1, 96071, {}, nil )
	createEntry    ( 96076, -1, 96072, {}, nil )
	createEntry    ( 96076, -1, 96073, {}, nil )
	createEntry    ( 96076, -1, 96074, {}, nil )
	createEntry    ( 96076, -1, 96075, {}, nil )
	createQuest    ( 96107 )
	createEntry    ( 96107, -1, 91214, {}, nil )
	createEntry    ( 96107, -1, 91248, {}, nil )
	createEntry    ( 96107, -1, 91277, {}, nil )
	createEntry    ( 96107, -1, 90354, {}, nil )
	createEntry    ( 96107, -1, 90351, {}, nil )
	createEntry    ( 96107, -1, 90346, {}, nil )
	createEntry    ( 96107, -1, 90347, {}, nil )
	createEntry    ( 96107, -1, 89660, {}, nil )
	createEntry    ( 96107, -1, 89677, {}, nil )
	createEntry    ( 96107, -1, 91528, {}, nil )
	createEntry    ( 96107, -1, 92067, {}, nil )
	createQuest    ( 96115 )
	createEntry    ( 96115, -1, 84943, {}, nil )
	createEntry    ( 96115, -1, 84942, {}, nil )
	createEntry    ( 96115, -1, 84945, {}, nil )
	createEntry    ( 96115, -1, 84972, {}, nil )
	createEntry    ( 96115, -1, 84948, {}, nil )
	createEntry    ( 96115, -1, 84950, {}, nil )
	createEntry    ( 96115, -1, 84949, {}, nil )
	createEntry    ( 96115, -1, 84953, {}, nil )
	createEntry    ( 96115, -1, 84955, {}, nil )
	createEntry    ( 96115, -1, 84958, {}, nil )
	createEntry    ( 96115, -1, 84964, {}, nil )
	createEntry    ( 96115, -1, 84967, {}, nil )
	createEntry    ( 96115, -1, 84971, {}, nil )
	createEntry    ( 96115, -1, 85120, {}, nil )
	createEntry    ( 96115, -1, 83513, {}, nil )
	createEntry    ( 96115, -1, 85169, {}, nil )
	createEntry    ( 96115, -1, 85172, {}, nil )
	createEntry    ( 96115, -1, 85175, {}, nil )
	createEntry    ( 96115, -1, 85290, {}, nil )
	createEntry    ( 96115, -1, 86500, {}, nil )
	createEntry    ( 96115, -1, 86506, {}, nil )
	createEntry    ( 96115, -1, 103116, {}, nil )
	createEntry    ( 96115, -1, 103140, {}, nil )
	createQuest    ( 100039 )
	createEntry    ( 100039, -1, 100040, {}, nil )
	createEntry    ( 100039, -1, 100041, {}, nil )
	createEntry    ( 100039, -1, 100042, {}, nil )
	createQuest    ( 94558 )
	createEntry    ( 94558, -1, 90956, {}, nil )
	createEntry    ( 94558, -1, 94553, {}, nil )
	createEntry    ( 94558, -1, 94554, {}, nil )
	createEntry    ( 94558, -1, 94555, {}, nil )
	createEntry    ( 94558, -1, 94556, {}, nil )
	createEntry    ( 94558, -1, 94557, {}, nil )
	createQuest    ( 94559 )
	createEntry    ( 94559, -1, 93847, {}, nil )
	createEntry    ( 94559, -1, 93848, {}, nil )
	createEntry    ( 94559, -1, 90957, {}, nil )
	createEntry    ( 94559, -1, 93849, {}, nil )
	createQuest    ( 94560 )
	createEntry    ( 94560, -1, 93912, {}, nil )
	createEntry    ( 94560, -1, 93913, {}, nil )
	createEntry    ( 94560, -1, 93914, {}, nil )
	createQuest    ( 102771 )
	createEntry    ( 102771, -1, 90952, {}, nil )
	createEntry    ( 102771, -1, 90953, {}, nil )
	createQuest    ( 94033 )
	createEntry    ( 94033, -1, 94032, {}, nil )
	createEntry    ( 94033, -1, 94034, {}, nil )
	createEntry    ( 94033, -1, 94035, {}, nil )
	createEntry    ( 94033, -1, 94036, {}, nil )
	createEntry    ( 94033, -1, 94037, {}, nil )
	createEntry    ( 94033, -1, 94038, {}, nil )
	createEntry    ( 94033, -1, 94039, {}, nil )
	createEntry    ( 94033, -1, 94040, {}, nil )
	createQuest    ( 88267 )
	createEntry    ( 88267, -1, 92593, {}, nil )
	createEntry    ( 88267, -1, 92594, {}, nil )
	createEntry    ( 88267, -1, 92595, {}, nil )
	createEntry    ( 88267, -1, 92596, {}, nil )
	createEntry    ( 88267, -1, 92597, {}, nil )
	createQuest    ( 95779 )
	createEntry    ( 95779, -1, 95780, {}, nil )
	createEntry    ( 95779, -1, 95781, {}, nil )
	createEntry    ( 95779, -1, 95782, {}, nil )
	createEntry    ( 95779, -1, 95783, {}, nil )
	createEntry    ( 95779, -1, 95784, {}, nil )
	createEntry    ( 95779, -1, 95785, {}, nil )
	createEntry    ( 95779, -1, 95786, {}, nil )
	createEntry    ( 95779, -1, 95787, {}, nil )
	createEntry    ( 95779, -1, 95788, {}, nil )
	createEntry    ( 95779, -1, 95789, {}, nil )
	createEntry    ( 95779, -1, 95790, {}, nil )
	createQuest    ( 95872 )
	createEntry    ( 95872, -1, 95873, {}, nil )
	createEntry    ( 95872, -1, 95874, {}, nil )
	createEntry    ( 95872, -1, 95875, {}, nil )
	createQuest    ( 96007 )
	createEntry    ( 96007, -1, 92699, {}, nil )
	createEntry    ( 96007, -1, 92700, {}, nil )
	createEntry    ( 96007, -1, 92701, {}, nil )
	createQuest    ( 96026 )
	createEntry    ( 96026, -1, 96027, {}, nil )
	createEntry    ( 96026, -1, 96028, {}, nil )
	createQuest    ( 102772 )
	createEntry    ( 102772, -1, 101238, {}, nil )
	createEntry    ( 102772, -1, 101239, {}, nil )
	createEntry    ( 102772, -1, 101240, {}, nil )
	createEntry    ( 102772, -1, 101241, {}, nil )
	createEntry    ( 102772, -1, 101242, {}, nil )
	createEntry    ( 102772, -1, 101243, {}, nil )
	createEntry    ( 102772, -1, 101244, {}, nil )
	createEntry    ( 102772, -1, 101245, {}, nil )
	createEntry    ( 102772, -1, 101246, {}, nil )
	createEntry    ( 102772, -1, 101247, {}, nil )
	createEntry    ( 102772, -1, 101248, {}, nil )
	createEntry    ( 102772, -1, 101249, {}, nil )
	createEntry    ( 102772, -1, 101250, {}, nil )
	createEntry    ( 102772, -1, 101251, {}, nil )
	createEntry    ( 102772, -1, 101252, {}, nil )
	createQuest    ( 94561 )
	createEntry    ( 94561, -1, 90954, {}, nil )
	createEntry    ( 94561, -1, 91264, {}, nil )
	createEntry    ( 94561, -1, 91265, {}, nil )
	createEntry    ( 94561, -1, 91576, {}, nil )
	createEntry    ( 94561, -1, 91578, {}, nil )
	createEntry    ( 94561, -1, 91579, {}, nil )
	createEntry    ( 94561, -1, 94815, {}, nil )
	createEntry    ( 94561, -1, 94816, {}, nil )
	createEntry    ( 94561, -1, 92450, {}, nil )
	createEntry    ( 94561, -1, 92451, {}, nil )
	createEntry    ( 94561, -1, 92452, {}, nil )
	createEntry    ( 94561, -1, 92859, {}, nil )
	createEntry    ( 94561, -1, 92860, {}, nil )
	createEntry    ( 94561, -1, 101266, {}, nil )
	createEntry    ( 94561, -1, 101267, {}, nil )
	createEntry    ( 94561, -1, 101268, {}, nil )
	createEntry    ( 94561, -1, 101269, {}, nil )
	createEntry    ( 94561, -1, 102773, {}, nil )
	createQuest    ( 95658 )
	createEntry    ( 95658, -1, 103096, {}, nil )
	createEntry    ( 95658, -1, 103099, {}, nil )
	createEntry    ( 74337, -1, 103855, {}, nil )
	createEntry    ( 74337, -1, 103865, {}, nil )
end
