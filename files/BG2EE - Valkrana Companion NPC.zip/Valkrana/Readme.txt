--------------------------------------------------------------------
--------------------------------------------------------------------
(u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/
Valkrana Companion NPC mod for Baldur's Gate II EE by Sailor Cat
Character art by Nyama https://www.pixiv.net/en/users/7499
Character website https://valkrana.moe

--------------------------------------------------------------------
--------------------------------------------------------------------
(u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/
Currently only supports the Enhanced Edition of BG2.
Installation:
1. Extract to your Baldur's Gate II root folder (ex: D:\Steam\steamapps\common\Baldur's Gate II Enhanced Edition\)
2. Run setup-valkrana.exe
3. Crack open a brewski and pry open a casket

--------------------------------------------------------------------
--------------------------------------------------------------------
Bring the multiverse's most awkward necromancer to your Baldur's Gate II party with the Valkrana Companion NPC mod. This full-fledged companion includes voiced lines, a character quest, world reactions, tailored scripts, and more. Character portraits by Nyama. Voiced by Sailor Cat.

At first, Valkrana appears a skeletal wizard detached from the world around her. Provided you don't succumb to your bloodline, she hardly raises an objection no matter how dumb or duplicitous your actions. But given time with her awkwardness, you'll come to find that despite her enduring pragmatism, she is anything but detached.

Background
----------
When asked about her past, VALKRANA speaks with gusto unusual to the skeleton about her service to and relationship with the great, mighty, unrivaled witch Ilyana Miraquinal. Until Ilyana, Valkrana was unfinished, incomplete. With a kiss, Ilyana brought out the best in her, filled a hole in Valkrana purpose-dug for lifelong obsession. What followed was adventure after adventure, travails shared as companions to further the renown of the hero Ilyana. Many of which, you're treated to in great detail. Currently, Valkrana serves as Ilyana's envoy in this corner of Realmspace.

Valkrana strikes an odd balance between a child's awkward bearing and the keen edge of an undead mastermind. Painfully out of her element in conversation, her selective filter and curt replies give the impression of a contempt that isn't there. Usually. In the city, there always seems to be an urchin within her line of sight.

Details
-------
Gender: Female
Class: Necromancer
Racial Features: As a skeleton, Valkrana has several undead traits: Cold resistance 25, poison immunity, immunity to level drain, and immunity to the Nature's Beauty spell.
Stats: STR 8, DEX 10, CON 14, INT 21, WIS 16, CHA 7
Alignment: Neutral
Bonuses: Valkrana's fascination with the arcane provides a boost to Lore. She also knows the Simulacrum spell despite her specialist limitation.
Bones Alive!: Valkrana's quest is freeform and progresses as you confront the Cowled Wizards and find magic items.
Spellcasting: A focus on defense, necromancy, divination, and countering other wizards.
Recruitment: Valkrana can be found above the Copper Coronet in the Slums district.
Starting Gear: Quarterstaff and three scrolls of Animate Dead.
Voice: Base dialogue set is fully voiced. Quest and other dialogue will come soon.

Notes
-----
Not romanceable.
Doesn't banter with other characters.
Crossmod content is fine.
Plan to add EET compatibility. 
Not yet compatible with classic BG2.

--------------------------------------------------------------------
--------------------------------------------------------------------
(u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/ (u_x)/
Many thanks to Weimer for his work on WeiDU, and all the members of the community whose posts, mods, and tutorials have been valuable references. Nuts to see PPG still around after visiting for Unfinished Business all those years ago. Thanks also to Lamei for input and info that helped in the process.

Not compatible with classic BG2. While I intend to add compatibility, I decided to put off digging out all the errant washers and springs from the bottom of the drawer until after the mod has found its footing with EE.
