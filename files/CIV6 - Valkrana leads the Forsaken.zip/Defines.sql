--///////////////////////////////////////////////////////
-- Valkrana (Valenwood) / Defines
--///////////////////////////////////////////////////////
DELETE FROM CivilizationLeaders WHERE CivilizationType = 'CIVILIZATION_RUSSIA' AND LeaderType = 'LEADER_SAILOR_VALKRANA';
INSERT INTO CivilizationLeaders	(CivilizationType, LeaderType, CapitalName)
VALUES	('CIVILIZATION_FORSAKEN', 'LEADER_SAILOR_VALKRANA', 'LOC_CITY_NAME_SAILOR_SSSRASHIENSTA');