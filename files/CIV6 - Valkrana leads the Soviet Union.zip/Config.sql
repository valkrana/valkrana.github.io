--///////////////////////////////////////////////////////
-- Valkrana (Soviet Union) / Config
--///////////////////////////////////////////////////////
DELETE FROM Players WHERE LeaderType = 'LEADER_SAILOR_VALKRANA' AND CivilizationType = 'CIVILIZATION_RUSSIA';
DELETE FROM PlayerItems WHERE LeaderType = 'LEADER_SAILOR_VALKRANA' AND CivilizationType = 'CIVILIZATION_RUSSIA';
-- // Players
INSERT INTO Players	(Domain, PortraitBackground, LeaderType, LeaderName, LeaderIcon, LeaderAbilityName, LeaderAbilityDescription, LeaderAbilityIcon, CivilizationType, CivilizationName, CivilizationIcon, CivilizationAbilityName, CivilizationAbilityDescription, CivilizationAbilityIcon)
SELECT DISTINCT Domain,
		'LEADER_SAILOR_VALKRANA_BACKGROUND', -- PortraitBackground
		'LEADER_SAILOR_VALKRANA', -- LeaderType
		'LOC_LEADER_SAILOR_VALKRANA_NAME', -- LeaderName
		'ICON_LEADER_SAILOR_VALKRANA', -- LeaderIcon
		'LOC_TRAIT_LEADER_SAILOR_VALKRANA_UA_NAME', -- LeaderAbilityName
		'LOC_TRAIT_LEADER_SAILOR_VALKRANA_UA_DESCRIPTION', -- LeaderAbilityDescription
		'ICON_LEADER_SAILOR_VALKRANA', -- LeaderAbilityIcon
		CivilizationType, CivilizationName, CivilizationIcon, CivilizationAbilityName, CivilizationAbilityDescription, CivilizationAbilityIcon
FROM Players WHERE CivilizationType = 'CIVILIZATION_JFD_USSR';

-- // PlayerItems
INSERT INTO PlayerItems	(Domain, LeaderType, CivilizationType, Type, Icon, Name, Description, SortIndex)
SELECT DISTINCT Domain,
		'LEADER_SAILOR_VALKRANA',
		'CIVILIZATION_JFD_USSR',
		'DISTRICT_JFD_NAUKOGRAD',
		'ICON_DISTRICT_JFD_NAUKOGRAD',
		'LOC_DISTRICT_JFD_NAUKOGRAD_NAME',
		'LOC_DISTRICT_JFD_NAUKOGRAD_DESCRIPTION',
		20
FROM PlayerItems WHERE CivilizationType = 'CIVILIZATION_JFD_USSR';

INSERT INTO PlayerItems	(Domain, LeaderType, CivilizationType, Type, Icon, Name, Description, SortIndex)
SELECT DISTINCT Domain,
		'LEADER_SAILOR_VALKRANA',
		'CIVILIZATION_JFD_USSR',
		'UNIT_JFD_RED_ARMY',
		'ICON_UNIT_JFD_RED_ARMY',
		'LOC_UNIT_JFD_RED_ARMY_NAME',
		'LOC_UNIT_JFD_RED_ARMY_DESCRIPTION',
		10
FROM PlayerItems WHERE CivilizationType = 'CIVILIZATION_JFD_USSR';

INSERT INTO PlayerItems	(Domain, LeaderType, CivilizationType, Type, Icon, Name, Description, SortIndex)
SELECT DISTINCT Domain,
		'LEADER_SAILOR_VALKRANA',
		'CIVILIZATION_JFD_USSR',
		'UNIT_SAILOR_VALKRANA_UU',
		'ICON_UNIT_SAILOR_VALKRANA_UU',
		'LOC_UNIT_SAILOR_VALKRANA_UU_NAME',
		'LOC_UNIT_SAILOR_VALKRANA_UU_DESCRIPTION',
		1
FROM PlayerItems WHERE CivilizationType = 'CIVILIZATION_JFD_USSR';