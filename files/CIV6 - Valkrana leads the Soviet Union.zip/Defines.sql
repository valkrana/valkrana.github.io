--///////////////////////////////////////////////////////
-- Valkrana (Soviet Union) / Defines
--///////////////////////////////////////////////////////
INSERT INTO CivilizationLeaders	(CivilizationType, LeaderType, CapitalName)
VALUES	('CIVILIZATION_JFD_USSR', 'LEADER_SAILOR_VALKRANA', 'LOC_CITY_NAME_SAILOR_SSSRASHIENSTA');

UPDATE AiFavoredItems SET Item = 'DISTRICT_JFD_NAUKOGRAD' WHERE ListType = 'SAILOR_VALKRANA_Districts' AND Item = 'DISTRICT_CAMPUS';
INSERT OR REPLACE INTO AiFavoredItems	
		(ListType,							Favored,	Item,							Value)
VALUES	('SAILOR_VALKRANA_Districts',		1,			'DISTRICT_INDUSTRIAL_ZONE',		0);

INSERT OR REPLACE INTO AiFavoredItems (ListType, Favored, Item, Value) SELECT 'SAILOR_VALKRANA_Buildings', 1, BuildingType, 0    
FROM Buildings WHERE PrereqDistrict = 'DISTRICT_INDUSTRIAL_ZONE' AND TraitType IS NULL;

-- YtMND
CREATE TABLE IF NOT EXISTS StartPosition
	(	MapName TEXT,
		MapScript TEXT,
		Civilization TEXT,
		Leader TEXT,
		DisabledByCivilization TEXT,
		DisabledByLeader TEXT,
		AlternateStart INT default 0,		
		X INT default 0,
		Y INT default 0);

INSERT OR IGNORE INTO StartPosition
				(MapName,	Civilization,				X, Y, AlternateStart)
SELECT DISTINCT MapName,	'CIVILIZATION_JFD_USSR',	X, Y, AlternateStart
FROM StartPosition WHERE Civilization = 'CIVILIZATION_RUSSIA' AND Leader IS NULL;

INSERT OR IGNORE INTO StartPosition
		(MapName,				Civilization,				X, Y,	AlternateStart)
VALUES	('GreatestEarthMap',	'CIVILIZATION_JFD_USSR',	70, 56, 1);