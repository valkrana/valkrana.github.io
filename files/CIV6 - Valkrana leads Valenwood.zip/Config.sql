--///////////////////////////////////////////////////////
-- Valkrana (Valenwood) / Config
--///////////////////////////////////////////////////////
DELETE FROM Players WHERE LeaderType = 'LEADER_SAILOR_VALKRANA' AND CivilizationType = 'CIVILIZATION_RUSSIA';
DELETE FROM PlayerItems WHERE LeaderType = 'LEADER_SAILOR_VALKRANA' AND CivilizationType = 'CIVILIZATION_RUSSIA';
-- // Players
INSERT INTO Players	(Domain, PortraitBackground, LeaderType, LeaderName, LeaderIcon, LeaderAbilityName, LeaderAbilityDescription, LeaderAbilityIcon, CivilizationType, CivilizationName, CivilizationIcon, CivilizationAbilityName, CivilizationAbilityDescription, CivilizationAbilityIcon)
SELECT DISTINCT Domain,
		'LEADER_SAILOR_VALKRANA_BACKGROUND', -- PortraitBackground
		'LEADER_SAILOR_VALKRANA', -- LeaderType
		'LOC_LEADER_SAILOR_VALKRANA_NAME', -- LeaderName
		'ICON_LEADER_SAILOR_VALKRANA', -- LeaderIcon
		'LOC_TRAIT_LEADER_SAILOR_VALKRANA_UA_NAME', -- LeaderAbilityName
		'LOC_TRAIT_LEADER_SAILOR_VALKRANA_UA_DESCRIPTION', -- LeaderAbilityDescription
		'ICON_LEADER_SAILOR_VALKRANA', -- LeaderAbilityIcon
		CivilizationType, CivilizationName, CivilizationIcon, CivilizationAbilityName, CivilizationAbilityDescription, CivilizationAbilityIcon
FROM Players WHERE CivilizationType = 'CIVILIZATION_KC20_TES_VALENWOOD';

-- // PlayerItems
INSERT INTO PlayerItems	(Domain, LeaderType, CivilizationType, Type, Icon, Name, Description, SortIndex)
SELECT DISTINCT Domain, 'LEADER_SAILOR_VALKRANA', CivilizationType, Type, Icon, Name, Description, SortIndex
FROM PlayerItems WHERE CivilizationType = 'CIVILIZATION_KC20_TES_VALENWOOD';

INSERT INTO PlayerItems	(Domain, LeaderType, CivilizationType, Type, Icon, Name, Description, SortIndex)
SELECT DISTINCT Domain,
		'LEADER_SAILOR_VALKRANA',
		'CIVILIZATION_KC20_TES_VALENWOOD',
		'UNIT_SAILOR_VALKRANA_UU',
		'ICON_UNIT_SAILOR_VALKRANA_UU',
		'LOC_UNIT_SAILOR_VALKRANA_UU_NAME',
		'LOC_UNIT_SAILOR_VALKRANA_UU_DESCRIPTION',
		30
FROM PlayerItems WHERE CivilizationType = 'CIVILIZATION_KC20_TES_VALENWOOD';